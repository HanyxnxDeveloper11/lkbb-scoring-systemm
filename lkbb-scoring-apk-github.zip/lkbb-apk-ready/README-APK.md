# Build APK LKBB Scoring

Workflow GitHub Actions tersedia di `.github/workflows/build-apk.yml`.

1. Upload seluruh isi folder project ini ke root repository GitHub (jangan membuat folder bersarang).
2. Pastikan branch utama bernama `main` atau `master`.
3. Buka tab **Actions** di repository.
4. Pilih **Build LKBB Scoring APK** lalu tekan **Run workflow** (atau tunggu build otomatis setelah push).
5. Setelah status hijau **Success**, buka hasil run dan unduh artifact `lkbb-scoring-debug-apk`.
6. Ekstrak ZIP artifact, lalu install file APK di Android.

Ini adalah **debug APK** untuk uji coba/distribusi terbatas, bukan APK release bertanda tangan permanen untuk Google Play. Untuk backend Supabase, pastikan konfigurasi URL dan publishable key tersedia pada konfigurasi project; ZIP sumber menyediakan `.env.example` dengan nilai placeholder.
