package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.AuthSession
import com.example.data.model.UserRole
import com.example.ui.components.StatusPill
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.ArchiveDetailScreen
import com.example.ui.screens.CompetitionSettingsScreen
import com.example.ui.screens.CreateEventDialog
import com.example.ui.screens.EventArchiveScreen
import com.example.ui.screens.FiveJudgesDashboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.RankingDashboardScreen
import com.example.ui.screens.ScoringFormScreen
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySurface

object LkbbRoutes {
    const val ADMIN = "admin"
    const val FIVE_JUDGES = "five_judges"
    const val SCORING = "scoring"
    const val RANKING = "ranking"
    const val SETTINGS = "settings"
    const val ARCHIVE = "archive"
    const val ARCHIVE_DETAIL = "archive_detail/{eventId}"

    fun archiveDetail(eventId: String): String = "archive_detail/$eventId"
}

private data class NavDestinationItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun LkbbApp(viewModel: LkbbViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        val msg = uiState.snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val session = uiState.session
    if (session == null) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                LoginScreen(
                    uiState = uiState,
                    onLogin = viewModel::login,
                    onQuickDemoLogin = viewModel::quickDemoLogin,
                    onClearError = viewModel::clearAuthError
                )
            }
        }
        return
    }

    key(session.userId, session.role, session.judgeNumber) {
        AuthenticatedLkbbShell(
            session = session,
            uiState = uiState,
            snackbarHostState = snackbarHostState,
            viewModel = viewModel
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedLkbbShell(
    session: AuthSession,
    uiState: LkbbUiState,
    snackbarHostState: SnackbarHostState,
    viewModel: LkbbViewModel
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val startRoute = if (session.role == UserRole.ADMIN) LkbbRoutes.ADMIN else LkbbRoutes.FIVE_JUDGES
    val currentRoute = backStackEntry?.destination?.route ?: startRoute
    var showCreateEventDialog by remember { mutableStateOf(false) }

    val bottomDestinations = remember(session.role) {
        if (session.role == UserRole.ADMIN) {
            listOf(
                NavDestinationItem(LkbbRoutes.ADMIN, "Admin", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings),
                NavDestinationItem(LkbbRoutes.FIVE_JUDGES, "5 Juri", Icons.Filled.Gavel, Icons.Outlined.Gavel),
                NavDestinationItem(LkbbRoutes.SCORING, "Nilai", Icons.Filled.EditNote, Icons.Outlined.EditNote),
                NavDestinationItem(LkbbRoutes.RANKING, "Ranking", Icons.Filled.EmojiEvents, Icons.Outlined.EmojiEvents),
                NavDestinationItem(LkbbRoutes.SETTINGS, "Atur", Icons.Filled.Settings, Icons.Outlined.Settings)
            )
        } else {
            listOf(
                NavDestinationItem(LkbbRoutes.FIVE_JUDGES, "5 Juri", Icons.Filled.Gavel, Icons.Outlined.Gavel),
                NavDestinationItem(LkbbRoutes.SCORING, "Formulir", Icons.Filled.EditNote, Icons.Outlined.EditNote),
                NavDestinationItem(LkbbRoutes.RANKING, "Ranking", Icons.Filled.EmojiEvents, Icons.Outlined.EmojiEvents)
            )
        }
    }

    val railDestinations = remember(session.role, bottomDestinations) {
        if (session.role == UserRole.ADMIN) {
            bottomDestinations + NavDestinationItem(
                LkbbRoutes.ARCHIVE,
                "Arsip",
                Icons.Filled.Archive,
                Icons.Outlined.Archive
            )
        } else {
            bottomDestinations
        }
    }

    val navigateToTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val openArchiveDetailScreen: (String) -> Unit = { eventId ->
        viewModel.loadArchiveDetail(eventId)
        navController.navigate(LkbbRoutes.archiveDetail(eventId)) {
            launchSingleTop = true
        }
    }

    val currentTitle = when {
        currentRoute == LkbbRoutes.ADMIN -> "Dashboard Admin"
        currentRoute == LkbbRoutes.FIVE_JUDGES -> "Dashboard Lima Juri"
        currentRoute == LkbbRoutes.SCORING -> "Formulir Penilaian LKBB"
        currentRoute == LkbbRoutes.RANKING -> "Dashboard Ranking"
        currentRoute == LkbbRoutes.SETTINGS -> "Pengaturan Perlombaan"
        currentRoute == LkbbRoutes.ARCHIVE -> "Arsip Perlombaan"
        currentRoute.startsWith("archive_detail") -> "Detail Arsip Event"
        else -> "LKBB Scoring"
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 720.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = currentTitle,
                                style = MaterialTheme.typography.titleLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${session.displayName} • ${uiState.competitionConfig.name}",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldChampionship,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    actions = {
                        if (session.role == UserRole.ADMIN) {
                            IconButton(
                                onClick = { navigateToTab(LkbbRoutes.ARCHIVE) },
                                modifier = Modifier.testTag("topbar_archive_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Archive,
                                    contentDescription = "Buka Arsip Perlombaan",
                                    tint = GoldChampionship
                                )
                            }
                        }
                        StatusPill(
                            text = if (session.role == UserRole.ADMIN) "ADMIN" else "JURI ${session.judgeNumber ?: 1}",
                            containerColor = CrimsonRed,
                            contentColor = CrispWhite,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        IconButton(
                            onClick = viewModel::logout,
                            modifier = Modifier.testTag("topbar_logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Keluar akun",
                                tint = CrispWhite
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = NavyPrimary,
                        titleContentColor = CrispWhite
                    )
                )
            },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = NavyPrimary,
                        contentColor = CrispWhite
                    ) {
                        bottomDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.label,
                                        maxLines = 1,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NavyDeep,
                                    selectedTextColor = GoldChampionship,
                                    indicatorColor = GoldChampionship,
                                    unselectedIconColor = CrispWhite.copy(alpha = 0.72f),
                                    unselectedTextColor = CrispWhite.copy(alpha = 0.72f)
                                ),
                                modifier = Modifier.testTag("bottom_nav_${dest.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = NavySurface,
                        contentColor = CrispWhite,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.size(12.dp))
                        railDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = NavyDeep,
                                    selectedTextColor = GoldChampionship,
                                    indicatorColor = GoldChampionship,
                                    unselectedIconColor = CrispWhite.copy(alpha = 0.75f),
                                    unselectedTextColor = CrispWhite.copy(alpha = 0.75f)
                                ),
                                modifier = Modifier.testTag("rail_nav_${dest.route}")
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = startRoute,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                ) {
                    composable(LkbbRoutes.ADMIN) {
                        AdminDashboardScreen(
                            uiState = uiState,
                            onOpenJudges = { navigateToTab(LkbbRoutes.FIVE_JUDGES) },
                            onOpenSettings = { navigateToTab(LkbbRoutes.SETTINGS) },
                            onOpenRanking = { navigateToTab(LkbbRoutes.RANKING) },
                            onOpenArchive = { navigateToTab(LkbbRoutes.ARCHIVE) },
                            onOpenArchiveDetail = openArchiveDetailScreen,
                            onCreateNewEvent = { showCreateEventDialog = true },
                            onScoreTeam = { teamId ->
                                viewModel.selectScoringTarget(teamId, null)
                                navigateToTab(LkbbRoutes.SCORING)
                            },
                            onSaveTeam = viewModel::addOrUpdateTeam,
                            onUpdateTeamStatus = viewModel::updateTeamStatus,
                            onDeleteTeam = viewModel::deleteTeam,
                            onToggleGlobalLock = viewModel::toggleGlobalScoringLock,
                            onSyncSupabase = viewModel::syncWithSupabase
                        )
                    }

                    composable(LkbbRoutes.FIVE_JUDGES) {
                        FiveJudgesDashboardScreen(
                            uiState = uiState,
                            onOpenJudgeScoring = { judgeNo, teamId ->
                                viewModel.selectScoringTarget(teamId, judgeNo)
                                navigateToTab(LkbbRoutes.SCORING)
                            },
                            onUnlockScoreSheet = viewModel::unlockScoreSheet
                        )
                    }

                    composable(LkbbRoutes.SCORING) {
                        ScoringFormScreen(
                            uiState = uiState,
                            onSelectTarget = viewModel::selectScoringTarget,
                            onSaveScoreSheet = viewModel::saveScoreSheet,
                            onUnlockScoreSheet = viewModel::unlockScoreSheet
                        )
                    }

                    composable(LkbbRoutes.RANKING) {
                        RankingDashboardScreen(
                            uiState = uiState,
                            shareText = viewModel.buildRankingShareText()
                        )
                    }

                    composable(LkbbRoutes.SETTINGS) {
                        CompetitionSettingsScreen(
                            uiState = uiState,
                            onSaveConfig = viewModel::updateCompetitionConfig,
                            onPickBrandImage = viewModel::updateBrandImageFromPicker,
                            onUpdateRankingSettings = viewModel::updateRankingSettings,
                            onSaveCriterion = viewModel::saveCriterion,
                            onDeleteCriterion = viewModel::deleteCriterion,
                            onNormalizeWeights = viewModel::normalizeCriteriaWeights,
                            onSavePenalty = viewModel::savePenaltyPreset,
                            onDeletePenalty = viewModel::deletePenaltyPreset,
                            onSaveJudge = viewModel::saveJudgeAccount,
                            onSaveTeam = viewModel::addOrUpdateTeam,
                            onDeleteTeam = viewModel::deleteTeam,
                            onPushSupabase = viewModel::syncWithSupabase,
                            onPullSupabase = viewModel::pullFromSupabase,
                            onResetDemoData = viewModel::resetDemoData
                        )
                    }

                    composable(LkbbRoutes.ARCHIVE) {
                        EventArchiveScreen(
                            uiState = uiState,
                            onBack = { navigateToTab(LkbbRoutes.ADMIN) },
                            onCreateNewEvent = { showCreateEventDialog = true },
                            onOpenArchiveDetail = openArchiveDetailScreen,
                            onActivateEvent = { eventId ->
                                viewModel.switchActiveEvent(eventId)
                                navigateToTab(LkbbRoutes.ADMIN)
                            }
                        )
                    }

                    composable(
                        route = LkbbRoutes.ARCHIVE_DETAIL,
                        arguments = listOf(navArgument("eventId") { type = NavType.StringType })
                    ) { entry ->
                        val eventId = entry.arguments?.getString("eventId")
                        LaunchedEffect(eventId) {
                            if (eventId != null && uiState.selectedArchiveDetail?.config?.id != eventId) {
                                viewModel.loadArchiveDetail(eventId)
                            }
                        }
                        ArchiveDetailScreen(
                            bundle = uiState.selectedArchiveDetail,
                            userRole = session.role,
                            totalEventsCount = uiState.archiveSummaries.size,
                            onBack = { navController.popBackStack() },
                            onFinalizeAndLock = viewModel::finalizeAndLockEvent,
                            onReopenArchive = viewModel::reopenArchivedEvent,
                            onDeleteEvent = { targetId ->
                                viewModel.deleteEventPermanently(targetId) {
                                    navController.popBackStack()
                                }
                            },
                            onExportPdf = { targetId ->
                                viewModel.exportArchivePdf(context, targetId)
                            },
                            onExportExcelCsv = { targetId ->
                                viewModel.exportArchiveExcelCsv(context, targetId)
                            },
                            onExportBackupJson = { targetId ->
                                viewModel.exportEventBackupJson(context, targetId)
                            },
                            onActivateEvent = { targetId ->
                                viewModel.switchActiveEvent(targetId)
                                navigateToTab(LkbbRoutes.ADMIN)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCreateEventDialog) {
        CreateEventDialog(
            existingEvents = uiState.archiveSummaries,
            onFetchSourceBundle = viewModel::fetchEventConfigBundleForDuplication,
            onPickLogoImage = { uri, onSaved ->
                viewModel.copyImageUriToAppStorage(uri, "lkbb_event_logo", onSaved)
            },
            onDismiss = { showCreateEventDialog = false },
            onSubmit = { req ->
                viewModel.createNewEvent(req) { newEventId ->
                    showCreateEventDialog = false
                    openArchiveDetailScreen(newEventId)
                }
            }
        )
    }
}

