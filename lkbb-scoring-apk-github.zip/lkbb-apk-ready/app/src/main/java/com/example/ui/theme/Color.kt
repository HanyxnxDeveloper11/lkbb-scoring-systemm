package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Official LKBB Brand Palette: Navy Blue, White, Crimson Red, Championship Gold
val NavyDeep = Color(0xFF07162B)
val NavyPrimary = Color(0xFF0B1F3A)
val NavySurface = Color(0xFF132E53)
val NavyElevated = Color(0xFF1C3E6E)
val NavySoft = Color(0xFFE6ECF5)

val CrispWhite = Color(0xFFFFFFFF)
val OffWhiteBackground = Color(0xFFF5F7FB)
val SurfaceMuted = Color(0xFFEDF1F8)
val OutlineSubtle = Color(0xFFD0DAE8)
val TextNavy = Color(0xFF0B1F3A)
val TextSlate = Color(0xFF4B5E7A)

val CrimsonRed = Color(0xFFC81E2B)
val CrimsonBright = Color(0xFFE12D39)
val CrimsonSoft = Color(0xFFFCE8EA)
val CrimsonDark = Color(0xFF8C111B)

val GoldChampionship = Color(0xFFD4AF37)
val GoldBright = Color(0xFFE9C75B)
val GoldSoft = Color(0xFFFCF4D9)
val GoldOnContainer = Color(0xFF5A4300)

val EmeraldSuccess = Color(0xFF15803D)
val EmeraldSoft = Color(0xFFDCFCE7)
val AmberWarning = Color(0xFFB45309)
val AmberSoft = Color(0xFFFEF3C7)
