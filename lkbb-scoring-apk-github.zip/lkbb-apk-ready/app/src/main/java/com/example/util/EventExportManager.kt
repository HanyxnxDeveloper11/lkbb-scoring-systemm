package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.EventDetailBundle
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EventExportManager {
    private fun sanitizeFileName(raw: String): String =
        raw.lowercase(Locale.getDefault())
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "lkbb_event" }

    private fun exportsDir(context: Context): File =
        File(context.cacheDir, "exports").apply { mkdirs() }

    fun generatePdfReport(context: Context, bundle: EventDetailBundle): Result<File> = runCatching {
        val config = bundle.config
        val file = File(exportsDir(context), "LKBB_Hasil_${sanitizeFileName(config.name)}.pdf")
        val nativeWorked = runCatching {
            val doc = PdfDocument()
            val pageWidth = 595 // A4 width at 72dpi
            val pageHeight = 842 // A4 height at 72dpi

            val titlePaint = Paint().apply {
                color = Color.rgb(15, 37, 68)
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val subtitlePaint = Paint().apply {
                color = Color.rgb(70, 80, 95)
                textSize = 10f
            }
            val sectionPaint = Paint().apply {
                color = Color.rgb(184, 29, 36)
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val headerBgPaint = Paint().apply {
                color = Color.rgb(15, 37, 68)
            }
            val headerTextPaint = Paint().apply {
                color = Color.WHITE
                textSize = 9f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val rowTextPaint = Paint().apply {
                color = Color.rgb(25, 30, 38)
                textSize = 9f
            }
            val rowBoldPaint = Paint().apply {
                color = Color.rgb(15, 37, 68)
                textSize = 9f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val dividerPaint = Paint().apply {
                color = Color.rgb(215, 222, 232)
                strokeWidth = 1f
            }

            var pageNumber = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            var canvas = page.canvas
            var y = 42f

            fun startNextPageIfNeeded(requiredSpace: Float) {
                if (y + requiredSpace > pageHeight - 40f) {
                    doc.finishPage(page)
                    pageNumber++
                    page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                    canvas = page.canvas
                    y = 42f
                }
            }

            canvas.drawText("LAPORAN RESMI HASIL LKBB PASKIBRA", 36f, y, titlePaint)
            y += 18f
            canvas.drawText("${config.name} (${config.status.badgeText}) • ${config.theme}", 36f, y, rowBoldPaint)
            y += 14f
            canvas.drawText("Lokasi: ${config.location} | Tanggal: ${config.eventDate} | Penyelenggara: ${config.organizer}", 36f, y, subtitlePaint)
            y += 14f
            val dateStr = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date())
            canvas.drawText("Dicetak: $dateStr • Peserta: ${bundle.teams.size} • Juri: ${bundle.judges.size} • Publikasi: ${if (config.isRankingPublished) "Publik" else "Internal"}", 36f, y, subtitlePaint)
            y += 16f
            canvas.drawLine(36f, y, pageWidth - 36f, y, dividerPaint)
            y += 20f

            canvas.drawText("REKAPITULASI RANKING & NILAI AKHIR", 36f, y, sectionPaint)
            y += 14f

            canvas.drawRect(36f, y, pageWidth - 36f, y + 20f, headerBgPaint)
            val headerY = y + 13f
            canvas.drawText("Rank", 42f, headerY, headerTextPaint)
            canvas.drawText("Sekolah / Regu", 74f, headerY, headerTextPaint)
            canvas.drawText("Kat", 232f, headerY, headerTextPaint)
            canvas.drawText("J1..J5", 272f, headerY, headerTextPaint)
            canvas.drawText("Kotor", 408f, headerY, headerTextPaint)
            canvas.drawText("Pen", 450f, headerY, headerTextPaint)
            canvas.drawText("Akhir", 482f, headerY, headerTextPaint)
            canvas.drawText("Predikat", 522f, headerY, headerTextPaint)
            y += 28f

            bundle.rankings.forEach { r ->
                startNextPageIfNeeded(24f)
                val squadSuffix = if (r.team.squadName.isNotBlank()) " (${r.team.squadName})" else ""
                val schoolLabel = ("#${r.team.orderNumber} ${r.team.name}$squadSuffix").take(28)
                val jScores = (1..5).joinToString(" ") { j ->
                    r.judgeWeightedTotals[j]?.let { String.format(Locale.US, "%.0f", it) } ?: "-"
                }
                canvas.drawText("#${r.rank}", 42f, y, rowBoldPaint)
                canvas.drawText(schoolLabel, 74f, y, rowTextPaint)
                canvas.drawText(r.team.category.name, 232f, y, rowTextPaint)
                canvas.drawText(jScores, 272f, y, rowTextPaint)
                canvas.drawText(String.format(Locale.US, "%.1f", r.grossScore), 408f, y, rowTextPaint)
                canvas.drawText("-${r.totalPenalty}", 450f, y, rowTextPaint)
                canvas.drawText(String.format(Locale.US, "%.2f", r.finalScore), 482f, y, rowBoldPaint)
                canvas.drawText(r.predicate.take(11), 522f, y, rowTextPaint)
                y += 14f
                canvas.drawLine(36f, y - 4f, pageWidth - 36f, y - 4f, dividerPaint)
                y += 6f
            }

            y += 12f
            startNextPageIfNeeded(90f)
            canvas.drawText("DEWAN JURI BERTUGAS", 36f, y, sectionPaint)
            y += 16f
            bundle.judges.forEach { j ->
                startNextPageIfNeeded(18f)
                canvas.drawText("Juri ${j.judgeNumber}: ${j.name} — ${j.specialty}", 42f, y, rowTextPaint)
                y += 14f
            }

            doc.finishPage(page)
            file.outputStream().use { out -> doc.writeTo(out) }
            doc.close()
            true
        }.getOrDefault(false)

        if (!nativeWorked) {
            writeFallbackTextPdf(file, bundle)
        }
        file
    }

    private fun writeFallbackTextPdf(file: File, bundle: EventDetailBundle) {
        val c = bundle.config
        val lines = buildList {
            add("LAPORAN RESMI HASIL LKBB PASKIBRA")
            add("${c.name} (${c.status.badgeText}) - ${c.location} (${c.eventDate})")
            add("Peserta: ${bundle.teams.size} | Juri: ${bundle.judges.size}")
            bundle.rankings.forEach { r ->
                add("#${r.rank} ${r.team.name} | Akhir: ${String.format(Locale.US, "%.2f", r.finalScore)} | Pen: -${r.totalPenalty} | ${r.predicate}")
            }
        }
        val streamContent = buildString {
            append("BT\n/F1 11 Tf\n40 800 Td\n15 TL\n")
            lines.forEachIndexed { idx, line ->
                val escaped = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
                if (idx == 0) append("($escaped) Tj\n") else append("T* ($escaped) Tj\n")
            }
            append("ET")
        }
        val pdfBytes = buildString {
            append("%PDF-1.4\n")
            append("1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n")
            append("2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n")
            append("3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj\n")
            append("4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n")
            append("5 0 obj << /Length ${streamContent.length} >> stream\n$streamContent\nendstream endobj\n")
            append("trailer << /Root 1 0 R >>\n%%EOF\n")
        }
        file.writeText(pdfBytes, Charsets.UTF_8)
    }

    fun generateExcelCsv(context: Context, bundle: EventDetailBundle): Result<File> = runCatching {
        val config = bundle.config
        val sb = StringBuilder()
        // UTF-8 BOM for Microsoft Excel compatibility
        sb.append('\uFEFF')
        sb.appendLine("LKBB SCORING SYSTEM - ARSIP REKAPITULASI NILAI")
        sb.appendLine("Event,\"${csvEsc(config.name)}\"")
        sb.appendLine("Tema,\"${csvEsc(config.theme)}\"")
        sb.appendLine("Tanggal,\"${csvEsc(config.eventDate)}\"")
        sb.appendLine("Lokasi,\"${csvEsc(config.location)}\"")
        sb.appendLine("Status,\"${config.status.label}\"")
        sb.appendLine()
        sb.appendLine("Peringkat,No Urut,Nama Sekolah,Nama Regu,Kategori,Danton,Juri 1,Juri 2,Juri 3,Juri 4,Juri 5,Skor Kotor,Total Penalti,Skor Akhir,Predikat")

        bundle.rankings.forEach { r ->
            val jCols = (1..5).joinToString(",") { j ->
                r.judgeWeightedTotals[j]?.let { String.format(Locale.US, "%.2f", it) } ?: "0.00"
            }
            sb.appendLine(
                "${r.rank},${r.team.orderNumber},\"${csvEsc(r.team.name)}\",\"${csvEsc(r.team.squadName)}\",\"${csvEsc(r.team.category.displayName)}\",\"${csvEsc(r.team.dantonName)}\",$jCols,${String.format(Locale.US, "%.2f", r.grossScore)},${r.totalPenalty},${String.format(Locale.US, "%.2f", r.finalScore)},\"${csvEsc(r.predicate)}\""
            )
        }

        sb.appendLine()
        sb.appendLine("ASPEK & BOBOT PENILAIAN")
        sb.appendLine("Aspek,Kelompok,Skor Maks,Bobot (%),Aktif")
        bundle.criteria.forEach { c ->
            sb.appendLine("\"${csvEsc(c.name)}\",\"${csvEsc(c.categoryGroup)}\",${c.maxScore},${c.weightPercent},${if (c.isActive) "Ya" else "Tidak"}")
        }

        val file = File(exportsDir(context), "LKBB_Excel_${sanitizeFileName(config.name)}.csv")
        file.writeText(sb.toString(), Charsets.UTF_8)
        file
    }

    fun generateBackupJsonFile(context: Context, eventName: String, jsonContent: String): Result<File> = runCatching {
        val file = File(exportsDir(context), "LKBB_Backup_${sanitizeFileName(eventName)}.json")
        file.writeText(jsonContent, Charsets.UTF_8)
        file
    }

    fun shareExportedFile(context: Context, file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    private fun csvEsc(raw: String): String = raw.replace("\"", "\"\"")
}
