package com.example.data.model

enum class UserRole(val label: String) {
    ADMIN("Admin / Panitia"),
    JUDGE("Juri Lapangan")
}

enum class CompetitionCategory(val displayName: String) {
    SMP("SMP/MTs"),
    SMA("SMA/SMK/MA"),
    UMUM("Purna/Umum")
}

enum class TeamPerformanceStatus(val label: String) {
    WAITING("Menunggu"),
    PERFORMING("Tampil"),
    FINISHED("Selesai")
}

enum class RankingMode(val label: String, val description: String) {
    LIVE(
        label = "Live Ranking",
        description = "Peringkat diperbarui real-time termasuk nilai draft maupun terkunci."
    ),
    FINAL(
        label = "Final Ranking",
        description = "Peringkat resmi kejuaraan dengan opsi kunci penuh dan verifikasi juri."
    )
}

enum class EventStatus(val label: String, val badgeText: String) {
    DRAFT("Draft", "DRAFT"),
    ACTIVE("Aktif", "AKTIF"),
    FINISHED("Selesai", "SELESAI")
}

enum class AuditActionType(val label: String) {
    SYSTEM("Sistem"),
    EVENT_CREATE("Buat Event"),
    EVENT_LOCK("Kunci Arsip"),
    EVENT_REOPEN("Buka Arsip"),
    SETTINGS("Pengaturan"),
    SCORE_EDIT("Perubahan Nilai"),
    EXPORT("Ekspor / Backup")
}

data class AuthSession(
    val userId: String,
    val displayName: String,
    val email: String,
    val role: UserRole,
    val judgeNumber: Int? = null,
    val isSupabaseAuthenticated: Boolean = false
)

data class CompetitionConfig(
    val id: String = "lkbb-2026-main",
    val name: String = "LKBB Nusantara Cup 2026",
    val theme: String = "Langkah Tegap Pemuda Berkarakter",
    val organizer: String = "Paskibra & Panitia Pelaksana Daerah",
    val location: String = "GOR Gelanggang Pemuda",
    val eventDate: String = "18 November 2026",
    val year: Int = 2026,
    val maxDurationMinutes: Int = 10,
    val logoUrl: String = "",
    val bannerUrl: String = "",
    val rankingMode: RankingMode = RankingMode.LIVE,
    val isRankingPublished: Boolean = true,
    val onlyCountLockedInFinal: Boolean = true,
    val isScoringLocked: Boolean = false,
    val status: EventStatus = EventStatus.ACTIVE,
    val isArchivedLocked: Boolean = false,
    val createdAtMillis: Long = 1763452800000L,
    val reopenReason: String = "",
    val lastReopenedAtMillis: Long? = null,
    val lastSyncedAtMillis: Long? = null
)

data class EventCategoryConfig(
    val id: String,
    val eventId: String,
    val code: String,
    val displayName: String,
    val isEnabled: Boolean = true,
    val sortOrder: Int = 0
)

data class JudgeAccount(
    val judgeNumber: Int,
    val name: String,
    val specialty: String,
    val email: String,
    val pinCode: String,
    val isActive: Boolean = true,
    val eventId: String = "lkbb-2026-main"
)

data class ScoringCriterion(
    val id: String,
    val name: String,
    val categoryGroup: String,
    val maxScore: Int,
    val weightPercent: Int,
    val description: String,
    val isActive: Boolean = true,
    val sortOrder: Int = 0,
    val eventId: String = "lkbb-2026-main"
)

data class Team(
    val id: String,
    val orderNumber: Int,
    val name: String,
    val squadName: String = "",
    val contingentCode: String,
    val category: CompetitionCategory,
    val dantonName: String,
    val status: TeamPerformanceStatus = TeamPerformanceStatus.WAITING,
    val eventId: String = "lkbb-2026-main"
)

data class JudgeScoreSheet(
    val id: String,
    val teamId: String,
    val judgeNumber: Int,
    val criterionScores: Map<String, Int>,
    val penaltyPoints: Int = 0,
    val penaltyNotes: String = "",
    val evaluatorNotes: String = "",
    val isLocked: Boolean = false,
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val eventId: String = "lkbb-2026-main"
)

data class PenaltyPreset(
    val id: String,
    val label: String,
    val points: Int,
    val description: String = "",
    val isActive: Boolean = true,
    val sortOrder: Int = 0,
    val eventId: String = "lkbb-2026-main"
)

data class TeamRankingSummary(
    val rank: Int,
    val team: Team,
    val judgeWeightedTotals: Map<Int, Double>,
    val judgeLockedStates: Map<Int, Boolean>,
    val grossScore: Double,
    val totalPenalty: Int,
    val finalScore: Double,
    val submittedJudgeCount: Int,
    val predicate: String
)

data class ActivityLogEntry(
    val id: String,
    val actor: String,
    val message: String,
    val timestampMillis: Long,
    val eventId: String = "lkbb-2026-main",
    val actionType: AuditActionType = AuditActionType.SYSTEM,
    val reason: String = ""
)

data class JudgeStationSummary(
    val judge: JudgeAccount,
    val totalTeams: Int,
    val completedTeams: Int,
    val draftTeams: Int,
    val averageScoreGiven: Double,
    val lastUpdatedAtMillis: Long?
)

data class ArchiveResultSnapshot(
    val eventId: String,
    val snapshotJson: String,
    val totalParticipants: Int,
    val totalJudges: Int,
    val winnerSummary: String,
    val lockedAtMillis: Long,
    val lockedBy: String
)

data class EventArchiveSummary(
    val config: CompetitionConfig,
    val teamCount: Int,
    val judgeCount: Int,
    val lockedSheetCount: Int,
    val snapshot: ArchiveResultSnapshot? = null
)

data class GlobalArchiveStats(
    val totalEvents: Int = 0,
    val activeEvents: Int = 0,
    val finishedEvents: Int = 0,
    val draftEvents: Int = 0,
    val totalParticipantsAllEvents: Int = 0,
    val totalJudgesAllEvents: Int = 0
)

data class EventDetailBundle(
    val config: CompetitionConfig,
    val categories: List<EventCategoryConfig>,
    val judges: List<JudgeAccount>,
    val criteria: List<ScoringCriterion>,
    val penaltyPresets: List<PenaltyPreset>,
    val teams: List<Team>,
    val scoreSheets: List<JudgeScoreSheet>,
    val rankings: List<TeamRankingSummary>,
    val snapshot: ArchiveResultSnapshot?,
    val auditLogs: List<ActivityLogEntry>
)

data class CreateEventRequest(
    val name: String,
    val theme: String,
    val logoUrl: String,
    val bannerUrl: String,
    val eventDate: String,
    val year: Int,
    val location: String,
    val organizer: String,
    val maxDurationMinutes: Int,
    val status: EventStatus,
    val enabledCategories: Set<CompetitionCategory>,
    val teams: List<Team>,
    val judges: List<JudgeAccount>,
    val criteria: List<ScoringCriterion>,
    val penaltyPresets: List<PenaltyPreset>,
    val sourceEventIdForDuplication: String? = null,
    val activateImmediately: Boolean = true
)

object LkbbConstants {
    val defaultPenaltyPresets = listOf(
        PenaltyPreset("over_time", "Melebihi Batas Waktu (>10 mnt)", 10, "Kelebihan durasi tampil di arena.", true, 1),
        PenaltyPreset("step_line", "Menginjak/Melewati Garis Arena", 5, "Pelanggaran batas garis lapangan per kejadian.", true, 2),
        PenaltyPreset("drop_attr", "Atribut / Perlengkapan Jatuh", 5, "Topi, selempang, atau perlengkapan jatuh.", true, 3),
        PenaltyPreset("incomplete", "Anggota Pleton Kurang / Pingsan", 15, "Formasi tidak lengkap selama penilaian.", true, 4),
        PenaltyPreset("late_report", "Keterlambatan Laporan Danton", 5, "Prosedur laporan awal/akhir tidak sesuai.", true, 5)
    )
}
