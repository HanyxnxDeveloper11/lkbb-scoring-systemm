package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LkbbDatabase
import com.example.data.model.ActivityLogEntry
import com.example.data.model.AuthSession
import com.example.data.model.CompetitionCategory
import com.example.data.model.CompetitionConfig
import com.example.data.model.CreateEventRequest
import com.example.data.model.EventArchiveSummary
import com.example.data.model.EventCategoryConfig
import com.example.data.model.EventDetailBundle
import com.example.data.model.EventStatus
import com.example.data.model.GlobalArchiveStats
import com.example.data.model.JudgeAccount
import com.example.data.model.JudgeScoreSheet
import com.example.data.model.JudgeStationSummary
import com.example.data.model.PenaltyPreset
import com.example.data.model.RankingMode
import com.example.data.model.ScoringCriterion
import com.example.data.model.Team
import com.example.data.model.TeamPerformanceStatus
import com.example.data.model.TeamRankingSummary
import com.example.data.model.UserRole
import com.example.data.remote.SupabaseConfig
import com.example.data.repository.AuthResult
import com.example.data.repository.LkbbScoringRepository
import com.example.data.repository.SyncResult
import com.example.util.EventExportManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID

data class LkbbUiState(
    val isInitialized: Boolean = false,
    val session: AuthSession? = null,
    val authError: String? = null,
    val isAuthenticating: Boolean = false,
    val competitionConfig: CompetitionConfig = CompetitionConfig(),
    val eventCategories: List<EventCategoryConfig> = emptyList(),
    val judges: List<JudgeAccount> = emptyList(),
    val criteria: List<ScoringCriterion> = emptyList(),
    val penaltyPresets: List<PenaltyPreset> = emptyList(),
    val teams: List<Team> = emptyList(),
    val scoreSheets: List<JudgeScoreSheet> = emptyList(),
    val rankings: List<TeamRankingSummary> = emptyList(),
    val judgeStations: List<JudgeStationSummary> = emptyList(),
    val activityLogs: List<ActivityLogEntry> = emptyList(),
    val archiveSummaries: List<EventArchiveSummary> = emptyList(),
    val globalArchiveStats: GlobalArchiveStats = GlobalArchiveStats(),
    val selectedArchiveDetail: EventDetailBundle? = null,
    val selectedTeamIdForScoring: String? = null,
    val selectedJudgeNumberForScoring: Int = 1,
    val isSupabaseConfigured: Boolean = SupabaseConfig.isConfigured,
    val isSyncing: Boolean = false,
    val snackbarMessage: String? = null
) {
    val activeCriteria: List<ScoringCriterion>
        get() = criteria.filter { it.isActive }.sortedBy { it.sortOrder }

    val activePenalties: List<PenaltyPreset>
        get() = penaltyPresets.filter { it.isActive }.sortedBy { it.sortOrder }

    val totalWeightPercent: Int
        get() = activeCriteria.sumOf { it.weightPercent }

    val completedSheetCount: Int
        get() = scoreSheets.count { it.isLocked }

    val totalExpectedSheets: Int
        get() = (teams.size * 5).coerceAtLeast(1)

    val isCurrentEventLockedForEditing: Boolean
        get() = competitionConfig.isArchivedLocked || competitionConfig.status == EventStatus.FINISHED
}

private data class LocalSessionUiState(
    val session: AuthSession? = null,
    val authError: String? = null,
    val isAuthenticating: Boolean = false,
    val selectedTeamId: String? = null,
    val selectedJudgeNumber: Int = 1,
    val selectedArchiveDetail: EventDetailBundle? = null,
    val isSyncing: Boolean = false,
    val snackbarMessage: String? = null,
    val isInitialized: Boolean = false
)

class LkbbViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: LkbbScoringRepository
    private val localState = MutableStateFlow(LocalSessionUiState())

    init {
        val db = LkbbDatabase.getInstance(application)
        repository = LkbbScoringRepository(db)
        viewModelScope.launch {
            repository.ensureSeeded()
            localState.update { it.copy(isInitialized = true) }
        }
    }

    private val coreDataFlow = combine(
        repository.competitionConfig,
        repository.judges,
        repository.criteria,
        repository.teams,
        repository.scoreSheets
    ) { config, judges, criteria, teams, sheets ->
        CoreDataBundle(config, judges, criteria, teams, sheets)
    }

    private val extraDataFlow = combine(
        repository.penaltyPresets,
        repository.activityLogs,
        repository.categories
    ) { penalties, logs, categories ->
        ExtraDataBundle(penalties, logs, categories)
    }

    private val archiveDataFlow = combine(
        repository.archiveSummaries,
        repository.globalArchiveStats
    ) { summaries, stats ->
        summaries to stats
    }

    val uiState: StateFlow<LkbbUiState> = combine(
        coreDataFlow,
        extraDataFlow,
        archiveDataFlow,
        localState
    ) { core, extra, archiveData, local ->
        val (summaries, globalStats) = archiveData
        val rankings = LkbbScoringRepository.computeRankings(
            teams = core.teams,
            criteria = core.criteria,
            scoreSheets = core.scoreSheets,
            rankingMode = core.config.rankingMode,
            onlyCountLockedInFinal = core.config.onlyCountLockedInFinal
        )

        val judgeStations = core.judges.map { judge ->
            val sheetsForJudge = core.scoreSheets.filter { it.judgeNumber == judge.judgeNumber }
            val completed = sheetsForJudge.count { it.isLocked }
            val drafts = sheetsForJudge.count { !it.isLocked }
            val avg = if (sheetsForJudge.isEmpty()) 0.0 else {
                sheetsForJudge.map {
                    LkbbScoringRepository.calculateWeightedJudgeScore(it.criterionScores, core.criteria)
                }.average()
            }
            val lastUpdated = sheetsForJudge.maxOfOrNull { it.updatedAtMillis }
            JudgeStationSummary(
                judge = judge,
                totalTeams = core.teams.size,
                completedTeams = completed,
                draftTeams = drafts,
                averageScoreGiven = avg,
                lastUpdatedAtMillis = lastUpdated
            )
        }

        val resolvedTeamId = local.selectedTeamId
            ?.takeIf { id -> core.teams.any { it.id == id } }
            ?: core.teams.firstOrNull { it.status == TeamPerformanceStatus.PERFORMING }?.id
            ?: core.teams.firstOrNull()?.id

        val resolvedJudgeNumber = if (local.session?.role == UserRole.JUDGE) {
            local.session.judgeNumber ?: local.selectedJudgeNumber
        } else {
            local.selectedJudgeNumber
        }

        LkbbUiState(
            isInitialized = local.isInitialized,
            session = local.session,
            authError = local.authError,
            isAuthenticating = local.isAuthenticating,
            competitionConfig = core.config,
            eventCategories = extra.categories,
            judges = core.judges,
            criteria = core.criteria,
            penaltyPresets = extra.penalties,
            teams = core.teams,
            scoreSheets = core.scoreSheets,
            rankings = rankings,
            judgeStations = judgeStations,
            activityLogs = extra.logs,
            archiveSummaries = summaries,
            globalArchiveStats = globalStats,
            selectedArchiveDetail = local.selectedArchiveDetail,
            selectedTeamIdForScoring = resolvedTeamId,
            selectedJudgeNumberForScoring = resolvedJudgeNumber,
            isSupabaseConfigured = SupabaseConfig.isConfigured,
            isSyncing = local.isSyncing,
            snackbarMessage = local.snackbarMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LkbbUiState()
    )

    fun login(role: UserRole, identifier: String, secret: String, judgeNumber: Int?) {
        viewModelScope.launch {
            localState.update { it.copy(isAuthenticating = true, authError = null) }
            when (val result = repository.authenticate(role, identifier, secret, judgeNumber)) {
                is AuthResult.Success -> {
                    localState.update {
                        it.copy(
                            isAuthenticating = false,
                            session = result.session,
                            authError = null,
                            selectedJudgeNumber = result.session.judgeNumber ?: 1,
                            snackbarMessage = "Selamat datang, ${result.session.displayName}"
                        )
                    }
                }
                is AuthResult.Error -> {
                    localState.update {
                        it.copy(
                            isAuthenticating = false,
                            authError = result.message
                        )
                    }
                }
            }
        }
    }

    fun quickDemoLogin(role: UserRole, judgeNumber: Int = 1) {
        val identifier = if (role == UserRole.ADMIN) "admin@lkbb.id" else "juri$judgeNumber@lkbb.id"
        val secret = if (role == UserRole.ADMIN) "admin123" else {
            uiState.value.judges.find { it.judgeNumber == judgeNumber }?.pinCode ?: "${judgeNumber}".repeat(4)
        }
        login(role, identifier, secret, judgeNumber)
    }

    fun logout() {
        localState.update {
            it.copy(
                session = null,
                authError = null,
                selectedArchiveDetail = null,
                snackbarMessage = "Sesi diakhiri."
            )
        }
    }

    fun clearAuthError() {
        localState.update { it.copy(authError = null) }
    }

    fun clearSnackbar() {
        localState.update { it.copy(snackbarMessage = null) }
    }

    fun selectScoringTarget(teamId: String?, judgeNumber: Int?) {
        localState.update {
            it.copy(
                selectedTeamId = teamId ?: it.selectedTeamId,
                selectedJudgeNumber = judgeNumber ?: it.selectedJudgeNumber
            )
        }
    }

    // --- MULTI-EVENT & ARCHIVE MANAGEMENT ---

    fun switchActiveEvent(eventId: String) {
        viewModelScope.launch {
            val actor = uiState.value.session?.displayName ?: "Admin"
            val ok = repository.setActiveEvent(eventId, actor)
            if (ok) {
                val targetName = uiState.value.archiveSummaries.find { it.config.id == eventId }?.config?.name ?: eventId
                localState.update {
                    it.copy(
                        selectedTeamId = null,
                        snackbarMessage = "Event aktif dialihkan ke '$targetName'."
                    )
                }
            }
        }
    }

    fun loadArchiveDetail(eventId: String) {
        viewModelScope.launch {
            val bundle = repository.getEventDetailBundle(eventId)
            localState.update { it.copy(selectedArchiveDetail = bundle) }
        }
    }

    suspend fun fetchEventConfigBundleForDuplication(eventId: String): EventDetailBundle? {
        return repository.getEventDetailBundle(eventId)
    }

    fun createNewEvent(request: CreateEventRequest, onCreated: (String) -> Unit = {}) {
        viewModelScope.launch {
            val actor = uiState.value.session?.displayName ?: "Admin"
            val newId = repository.createNewEvent(request, actor)
            val bundle = repository.getEventDetailBundle(newId)
            localState.update {
                it.copy(
                    selectedTeamId = null,
                    selectedArchiveDetail = bundle,
                    snackbarMessage = "Perlombaan baru '${request.name}' berhasil dibuat & diisolasi."
                )
            }
            onCreated(newId)
        }
    }

    fun finalizeAndLockEvent(eventId: String) {
        viewModelScope.launch {
            val actor = uiState.value.session?.displayName ?: "Admin"
            val ok = repository.finalizeAndLockEvent(eventId, actor)
            val updatedBundle = repository.getEventDetailBundle(eventId)
            localState.update {
                it.copy(
                    selectedArchiveDetail = updatedBundle,
                    snackbarMessage = if (ok) {
                        "Perlombaan ditandai SELESAI. Snapshot final disimpan & seluruh nilai dikunci."
                    } else {
                        "Gagal mengunci arsip perlombaan."
                    }
                )
            }
        }
    }

    fun reopenArchivedEvent(eventId: String, reason: String) {
        if (uiState.value.session?.role != UserRole.ADMIN) {
            localState.update { it.copy(snackbarMessage = "Hanya Admin yang dapat membuka kembali arsip.") }
            return
        }
        if (reason.trim().isEmpty()) {
            localState.update { it.copy(snackbarMessage = "Alasan pembukaan kembali arsip wajib diisi.") }
            return
        }
        viewModelScope.launch {
            val actor = uiState.value.session?.displayName ?: "Admin"
            val ok = repository.reopenArchivedEvent(eventId, actor, reason)
            val updatedBundle = repository.getEventDetailBundle(eventId)
            localState.update {
                it.copy(
                    selectedArchiveDetail = updatedBundle,
                    snackbarMessage = if (ok) "Arsip dibuka kembali & alasan dicatat dalam audit log." else "Gagal membuka kembali arsip."
                )
            }
        }
    }

    fun deleteEventPermanently(eventId: String, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            val actor = uiState.value.session?.displayName ?: "Admin"
            val res = repository.deleteEventPermanently(eventId, actor)
            res.onSuccess { msg ->
                localState.update {
                    it.copy(
                        selectedArchiveDetail = null,
                        selectedTeamId = null,
                        snackbarMessage = msg
                    )
                }
                onDeleted()
            }.onFailure { err ->
                localState.update {
                    it.copy(snackbarMessage = err.message ?: "Tidak dapat menghapus event.")
                }
            }
        }
    }

    fun exportArchivePdf(context: Context, eventId: String) {
        viewModelScope.launch {
            val bundle = repository.getEventDetailBundle(eventId)
            if (bundle == null) {
                localState.update { it.copy(snackbarMessage = "Data arsip tidak ditemukan.") }
                return@launch
            }
            val result = withContext(Dispatchers.IO) {
                EventExportManager.generatePdfReport(context, bundle)
            }
            result.onSuccess { file ->
                runCatching {
                    EventExportManager.shareExportedFile(context, file, "application/pdf", "Laporan PDF ${bundle.config.name}")
                }
                localState.update { it.copy(snackbarMessage = "Laporan PDF berhasil dibuat: ${file.name}") }
            }.onFailure { err ->
                localState.update { it.copy(snackbarMessage = "Gagal membuat PDF: ${err.localizedMessage}") }
            }
        }
    }

    fun exportArchiveExcelCsv(context: Context, eventId: String) {
        viewModelScope.launch {
            val bundle = repository.getEventDetailBundle(eventId)
            if (bundle == null) {
                localState.update { it.copy(snackbarMessage = "Data arsip tidak ditemukan.") }
                return@launch
            }
            val result = withContext(Dispatchers.IO) {
                EventExportManager.generateExcelCsv(context, bundle)
            }
            result.onSuccess { file ->
                runCatching {
                    EventExportManager.shareExportedFile(context, file, "text/csv", "Rekap Excel (CSV) ${bundle.config.name}")
                }
                localState.update { it.copy(snackbarMessage = "File Excel (CSV) berhasil dibuat: ${file.name}") }
            }.onFailure { err ->
                localState.update { it.copy(snackbarMessage = "Gagal mengekspor CSV: ${err.localizedMessage}") }
            }
        }
    }

    fun exportEventBackupJson(context: Context, eventId: String) {
        viewModelScope.launch {
            val bundle = repository.getEventDetailBundle(eventId)
            if (bundle == null) {
                localState.update { it.copy(snackbarMessage = "Data event tidak ditemukan.") }
                return@launch
            }
            val result = withContext(Dispatchers.IO) {
                val json = repository.buildEventBackupJson(eventId)
                EventExportManager.generateBackupJsonFile(context, bundle.config.name, json)
            }
            result.onSuccess { file ->
                runCatching {
                    EventExportManager.shareExportedFile(context, file, "application/json", "Backup JSON ${bundle.config.name}")
                }
                localState.update { it.copy(snackbarMessage = "Backup JSON tersimpan: ${file.name}") }
            }.onFailure { err ->
                localState.update { it.copy(snackbarMessage = "Gagal membuat backup JSON: ${err.localizedMessage}") }
            }
        }
    }

    fun copyImageUriToAppStorage(uri: Uri, prefix: String, onSaved: (String) -> Unit) {
        viewModelScope.launch {
            val fileName = "${prefix}_${System.currentTimeMillis()}.jpg"
            val savedUri = withContext(Dispatchers.IO) {
                runCatching {
                    val app = getApplication<Application>()
                    val destFile = File(app.filesDir, fileName)
                    app.contentResolver.openInputStream(uri)?.use { input ->
                        destFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    Uri.fromFile(destFile).toString()
                }.getOrNull()
            }
            if (savedUri != null) {
                onSaved(savedUri)
            } else {
                localState.update { it.copy(snackbarMessage = "Gagal memproses file gambar.") }
            }
        }
    }

    // --- EXISTING ACTIVE EVENT CRUD ---

    fun addOrUpdateTeam(
        existingId: String?,
        orderNumber: Int,
        name: String,
        squadName: String,
        contingentCode: String,
        category: CompetitionCategory,
        dantonName: String
    ) {
        if (name.isBlank()) return
        val eventId = uiState.value.competitionConfig.id
        viewModelScope.launch {
            val existing = existingId?.let { id -> uiState.value.teams.find { it.id == id } }
            val team = Team(
                id = existingId ?: "${eventId}_team_${UUID.randomUUID().toString().take(8)}",
                orderNumber = orderNumber,
                name = name.trim(),
                squadName = squadName.trim(),
                contingentCode = contingentCode.trim().ifEmpty { "${category.name}-$orderNumber" },
                category = category,
                dantonName = dantonName.trim().ifEmpty { "-" },
                status = existing?.status ?: TeamPerformanceStatus.WAITING,
                eventId = eventId
            )
            repository.saveTeam(team)
            localState.update { it.copy(snackbarMessage = "Peserta #${team.orderNumber} ${team.name} tersimpan.") }
        }
    }

    fun updateTeamStatus(team: Team, status: TeamPerformanceStatus) {
        viewModelScope.launch {
            repository.updateTeamStatus(team, status)
        }
    }

    fun deleteTeam(team: Team) {
        viewModelScope.launch {
            repository.deleteTeam(team)
            localState.update { it.copy(snackbarMessage = "Peserta ${team.name} dihapus.") }
        }
    }

    fun updateCompetitionConfig(config: CompetitionConfig) {
        viewModelScope.launch {
            repository.saveCompetitionConfig(config)
            localState.update { it.copy(snackbarMessage = "Pengaturan perlombaan tersimpan.") }
        }
    }

    fun updateBrandImageFromPicker(uri: Uri, isLogo: Boolean) {
        val prefix = if (isLogo) "lkbb_custom_logo" else "lkbb_custom_banner"
        copyImageUriToAppStorage(uri, prefix) { savedUri ->
            viewModelScope.launch {
                val current = uiState.value.competitionConfig
                val updated = if (isLogo) current.copy(logoUrl = savedUri) else current.copy(bannerUrl = savedUri)
                repository.saveCompetitionConfig(updated)
                localState.update {
                    it.copy(snackbarMessage = if (isLogo) "Logo perlombaan diperbarui." else "Banner perlombaan diperbarui.")
                }
            }
        }
    }

    fun updateRankingSettings(
        rankingMode: RankingMode,
        isRankingPublished: Boolean,
        onlyCountLockedInFinal: Boolean,
        isScoringLocked: Boolean
    ) {
        val current = uiState.value.competitionConfig
        val updated = current.copy(
            rankingMode = rankingMode,
            isRankingPublished = isRankingPublished,
            onlyCountLockedInFinal = onlyCountLockedInFinal,
            isScoringLocked = isScoringLocked
        )
        viewModelScope.launch {
            repository.saveCompetitionConfig(updated)
            localState.update {
                it.copy(snackbarMessage = "Mode ${rankingMode.label} berhasil diterapkan.")
            }
        }
    }

    fun toggleGlobalScoringLock() {
        val current = uiState.value.competitionConfig
        if (current.isArchivedLocked) {
            localState.update { it.copy(snackbarMessage = "Arsip ini sudah dikunci permanen. Buka dari menu Detail Arsip dengan alasan resmi.") }
            return
        }
        val updated = current.copy(isScoringLocked = !current.isScoringLocked)
        viewModelScope.launch {
            repository.saveCompetitionConfig(updated)
            val msg = if (updated.isScoringLocked) {
                "Seluruh penilaian resmi DIKUNCI."
            } else {
                "Kunci global penilaian dibuka."
            }
            localState.update { it.copy(snackbarMessage = msg) }
        }
    }

    fun saveJudgeAccount(judge: JudgeAccount) {
        val eventId = uiState.value.competitionConfig.id
        viewModelScope.launch {
            repository.saveJudgeAccount(judge.copy(eventId = eventId))
            localState.update { it.copy(snackbarMessage = "Profil Juri ${judge.judgeNumber} (${judge.name}) diperbarui.") }
        }
    }

    fun saveCriterion(criterion: ScoringCriterion) {
        val eventId = uiState.value.competitionConfig.id
        viewModelScope.launch {
            repository.saveCriterion(criterion.copy(eventId = eventId))
            localState.update { it.copy(snackbarMessage = "Aspek '${criterion.name}' disimpan.") }
        }
    }

    fun deleteCriterion(criterion: ScoringCriterion) {
        viewModelScope.launch {
            repository.deleteCriterion(criterion.id, criterion.name)
            localState.update { it.copy(snackbarMessage = "Aspek '${criterion.name}' dihapus.") }
        }
    }

    fun normalizeCriteriaWeights() {
        viewModelScope.launch {
            repository.normalizeCriteriaWeights()
            localState.update { it.copy(snackbarMessage = "Bobot aspek dinormalisasi menjadi 100%.") }
        }
    }

    fun savePenaltyPreset(preset: PenaltyPreset) {
        val eventId = uiState.value.competitionConfig.id
        viewModelScope.launch {
            repository.savePenaltyPreset(preset.copy(eventId = eventId))
            localState.update { it.copy(snackbarMessage = "Penalti '${preset.label}' (-${preset.points}) disimpan.") }
        }
    }

    fun deletePenaltyPreset(preset: PenaltyPreset) {
        viewModelScope.launch {
            repository.deletePenaltyPreset(preset)
            localState.update { it.copy(snackbarMessage = "Aturan penalti '${preset.label}' dihapus.") }
        }
    }

    fun saveScoreSheet(
        teamId: String,
        judgeNumber: Int,
        criterionScores: Map<String, Int>,
        penaltyPoints: Int,
        penaltyNotes: String,
        evaluatorNotes: String,
        lockAfterSave: Boolean
    ) {
        val eventId = uiState.value.competitionConfig.id
        viewModelScope.launch {
            val actor = uiState.value.session?.displayName ?: "Juri $judgeNumber"
            val sheet = JudgeScoreSheet(
                id = "${teamId}_j${judgeNumber}",
                teamId = teamId,
                judgeNumber = judgeNumber,
                criterionScores = criterionScores,
                penaltyPoints = penaltyPoints.coerceAtLeast(0),
                penaltyNotes = penaltyNotes.trim(),
                evaluatorNotes = evaluatorNotes.trim(),
                isLocked = lockAfterSave,
                updatedAtMillis = System.currentTimeMillis(),
                eventId = eventId
            )
            val saved = repository.saveScoreSheet(sheet, actor)
            val msg = when {
                !saved -> "Event sudah berstatus SELESAI & dikunci permanen. Nilai tidak dapat diubah."
                lockAfterSave -> "Nilai Juri $judgeNumber berhasil dikunci & dikirim!"
                else -> "Draft nilai Juri $judgeNumber tersimpan."
            }
            localState.update { it.copy(snackbarMessage = msg) }
        }
    }

    fun unlockScoreSheet(teamId: String, judgeNumber: Int) {
        viewModelScope.launch {
            val unlocked = repository.unlockScoreSheet(teamId, judgeNumber)
            val msg = if (unlocked) {
                "Kunci nilai Juri $judgeNumber dibuka oleh Admin."
            } else {
                "Arsip event sudah SELESAI & dikunci. Buka arsip terlebih dahulu dengan alasan resmi."
            }
            localState.update { it.copy(snackbarMessage = msg) }
        }
    }

    fun syncWithSupabase() {
        viewModelScope.launch {
            localState.update { it.copy(isSyncing = true) }
            val msg = when (val result = repository.syncWithSupabase()) {
                is SyncResult.Success -> result.summary
                is SyncResult.LocalOnly -> result.message
                is SyncResult.Failure -> result.error
            }
            localState.update { it.copy(isSyncing = false, snackbarMessage = msg) }
        }
    }

    fun pullFromSupabase() {
        viewModelScope.launch {
            localState.update { it.copy(isSyncing = true) }
            val msg = when (val result = repository.pullFromSupabase()) {
                is SyncResult.Success -> result.summary
                is SyncResult.LocalOnly -> result.message
                is SyncResult.Failure -> result.error
            }
            localState.update { it.copy(isSyncing = false, snackbarMessage = msg) }
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetDemoData()
            localState.update { it.copy(snackbarMessage = "Data event aktif berhasil direset (arsip event lain tetap aman).") }
        }
    }

    fun buildRankingShareText(): String {
        val state = uiState.value
        val modeLabel = state.competitionConfig.rankingMode.label.uppercase(Locale.getDefault())
        val sb = StringBuilder()
        sb.appendLine("[$modeLabel] ${state.competitionConfig.name}")
        sb.appendLine("${state.competitionConfig.location} | ${state.competitionConfig.eventDate}")
        sb.appendLine("----------------------------------------")
        state.rankings.forEach { r ->
            val scoreStr = String.format(Locale.US, "%.2f", r.finalScore)
            val squad = if (r.team.squadName.isNotBlank()) " (${r.team.squadName})" else ""
            sb.appendLine("#${r.rank} [${r.team.category.displayName}] No.${r.team.orderNumber} ${r.team.name}$squad -> $scoreStr (${r.predicate})")
        }
        return sb.toString()
    }

    private data class CoreDataBundle(
        val config: CompetitionConfig,
        val judges: List<JudgeAccount>,
        val criteria: List<ScoringCriterion>,
        val teams: List<Team>,
        val scoreSheets: List<JudgeScoreSheet>
    )

    private data class ExtraDataBundle(
        val penalties: List<PenaltyPreset>,
        val logs: List<ActivityLogEntry>,
        val categories: List<EventCategoryConfig>
    )
}
