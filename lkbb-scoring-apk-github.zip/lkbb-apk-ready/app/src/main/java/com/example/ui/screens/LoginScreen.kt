package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.UserRole
import com.example.ui.LkbbUiState
import com.example.ui.components.CompetitionBannerImage
import com.example.ui.components.CompetitionLogoBadge
import com.example.ui.components.StatusPill
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySurface

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LoginScreen(
    uiState: LkbbUiState,
    onLogin: (UserRole, String, String, Int?) -> Unit,
    onQuickDemoLogin: (UserRole, Int) -> Unit,
    onClearError: () -> Unit
) {
    var selectedRole by remember { mutableStateOf(UserRole.ADMIN) }
    var selectedJudgeNumber by remember { mutableIntStateOf(1) }
    var identifier by remember { mutableStateOf("admin@lkbb.id") }
    var secret by remember { mutableStateOf("admin123") }
    var showPassword by remember { mutableStateOf(false) }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(NavyDeep, NavyPrimary, MaterialTheme.colorScheme.background)
                )
            )
    ) {
        val isWide = maxWidth >= 800.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (isWide) {
                Row(
                    modifier = Modifier
                        .widthIn(max = 1040.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HeroBrandPanel(
                        competitionName = uiState.competitionConfig.name,
                        location = "${uiState.competitionConfig.location} • ${uiState.competitionConfig.eventDate}",
                        logoUrl = uiState.competitionConfig.logoUrl,
                        bannerUrl = uiState.competitionConfig.bannerUrl,
                        isSupabaseConfigured = uiState.isSupabaseConfigured,
                        modifier = Modifier.weight(1f)
                    )
                    LoginFormCard(
                        uiState = uiState,
                        selectedRole = selectedRole,
                        selectedJudgeNumber = selectedJudgeNumber,
                        identifier = identifier,
                        secret = secret,
                        showPassword = showPassword,
                        onRoleChange = { role ->
                            selectedRole = role
                            onClearError()
                            if (role == UserRole.ADMIN) {
                                identifier = "admin@lkbb.id"
                                secret = "admin123"
                            } else {
                                val j = uiState.judges.find { it.judgeNumber == selectedJudgeNumber }
                                identifier = j?.email ?: "juri$selectedJudgeNumber@lkbb.id"
                                secret = j?.pinCode ?: "$selectedJudgeNumber".repeat(4)
                            }
                        },
                        onJudgeNumberChange = { num ->
                            selectedJudgeNumber = num
                            onClearError()
                            val j = uiState.judges.find { it.judgeNumber == num }
                            identifier = j?.email ?: "juri$num@lkbb.id"
                            secret = j?.pinCode ?: "$num".repeat(4)
                        },
                        onIdentifierChange = { identifier = it; onClearError() },
                        onSecretChange = { secret = it; onClearError() },
                        onTogglePassword = { showPassword = !showPassword },
                        onLogin = {
                            onLogin(
                                selectedRole,
                                identifier,
                                secret,
                                if (selectedRole == UserRole.JUDGE) selectedJudgeNumber else null
                            )
                        },
                        onQuickDemoLogin = onQuickDemoLogin,
                        modifier = Modifier.weight(1f)
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .widthIn(max = 520.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    HeroBrandPanel(
                        competitionName = uiState.competitionConfig.name,
                        location = "${uiState.competitionConfig.location} • ${uiState.competitionConfig.eventDate}",
                        logoUrl = uiState.competitionConfig.logoUrl,
                        bannerUrl = uiState.competitionConfig.bannerUrl,
                        isSupabaseConfigured = uiState.isSupabaseConfigured,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LoginFormCard(
                        uiState = uiState,
                        selectedRole = selectedRole,
                        selectedJudgeNumber = selectedJudgeNumber,
                        identifier = identifier,
                        secret = secret,
                        showPassword = showPassword,
                        onRoleChange = { role ->
                            selectedRole = role
                            onClearError()
                            if (role == UserRole.ADMIN) {
                                identifier = "admin@lkbb.id"
                                secret = "admin123"
                            } else {
                                val j = uiState.judges.find { it.judgeNumber == selectedJudgeNumber }
                                identifier = j?.email ?: "juri$selectedJudgeNumber@lkbb.id"
                                secret = j?.pinCode ?: "$selectedJudgeNumber".repeat(4)
                            }
                        },
                        onJudgeNumberChange = { num ->
                            selectedJudgeNumber = num
                            onClearError()
                            val j = uiState.judges.find { it.judgeNumber == num }
                            identifier = j?.email ?: "juri$num@lkbb.id"
                            secret = j?.pinCode ?: "$num".repeat(4)
                        },
                        onIdentifierChange = { identifier = it; onClearError() },
                        onSecretChange = { secret = it; onClearError() },
                        onTogglePassword = { showPassword = !showPassword },
                        onLogin = {
                            onLogin(
                                selectedRole,
                                identifier,
                                secret,
                                if (selectedRole == UserRole.JUDGE) selectedJudgeNumber else null
                            )
                        },
                        onQuickDemoLogin = onQuickDemoLogin,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroBrandPanel(
    competitionName: String,
    location: String,
    logoUrl: String,
    bannerUrl: String,
    isSupabaseConfigured: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.55f))
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            CompetitionBannerImage(
                bannerUrl = bannerUrl,
                contentDescription = "Spanduk utama LKBB Scoring System",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                NavyDeep.copy(alpha = 0.94f),
                                NavyPrimary.copy(alpha = 0.72f),
                                NavyPrimary.copy(alpha = 0.35f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CompetitionLogoBadge(
                        logoUrl = logoUrl,
                        contentDescription = "Lambang LKBB",
                        modifier = Modifier.size(44.dp)
                    )
                    Column {
                        Text(
                            text = "LKBB SCORING SYSTEM",
                            style = MaterialTheme.typography.titleLarge,
                            color = CrispWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = competitionName,
                            style = MaterialTheme.typography.labelMedium,
                            color = GoldChampionship
                        )
                    }
                }
                Text(
                    text = "Sistem Penilaian Digital 5 Juri, Rekapitulasi Otomatis & Peringkat Real-Time.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CrispWhite.copy(alpha = 0.88f)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusPill(
                        text = if (isSupabaseConfigured) "Supabase Cloud Aktif" else "Siap Integrasi Supabase",
                        containerColor = if (isSupabaseConfigured) GoldSoft else CrispWhite.copy(alpha = 0.14f),
                        contentColor = if (isSupabaseConfigured) NavyDeep else CrispWhite,
                        icon = if (isSupabaseConfigured) Icons.Default.CloudDone else Icons.Default.CloudQueue
                    )
                    StatusPill(
                        text = location,
                        containerColor = CrimsonRed,
                        contentColor = CrispWhite
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LoginFormCard(
    uiState: LkbbUiState,
    selectedRole: UserRole,
    selectedJudgeNumber: Int,
    identifier: String,
    secret: String,
    showPassword: Boolean,
    onRoleChange: (UserRole) -> Unit,
    onJudgeNumberChange: (Int) -> Unit,
    onIdentifierChange: (String) -> Unit,
    onSecretChange: (String) -> Unit,
    onTogglePassword: () -> Unit,
    onLogin: () -> Unit,
    onQuickDemoLogin: (UserRole, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Masuk Portal Penilaian",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface
            )

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                UserRole.entries.forEachIndexed { index, role ->
                    SegmentedButton(
                        selected = selectedRole == role,
                        onClick = { onRoleChange(role) },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = UserRole.entries.size),
                        colors = SegmentedButtonDefaults.colors(
                            activeContainerColor = NavyPrimary,
                            activeContentColor = CrispWhite
                        ),
                        icon = {
                            Icon(
                                imageVector = if (role == UserRole.ADMIN) Icons.Default.AdminPanelSettings else Icons.Default.Gavel,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        modifier = Modifier.testTag("role_tab_${role.name.lowercase()}")
                    ) {
                        Text(if (role == UserRole.ADMIN) "Admin" else "Juri (1–5)")
                    }
                }
            }

            if (selectedRole == UserRole.JUDGE) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Pilih Meja Juri",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (1..5).forEach { num ->
                            FilterChip(
                                selected = selectedJudgeNumber == num,
                                onClick = { onJudgeNumberChange(num) },
                                label = { Text("Juri $num") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldChampionship,
                                    selectedLabelColor = NavyDeep
                                ),
                                modifier = Modifier.testTag("login_judge_chip_$num")
                            )
                        }
                    }
                    val activeJudge = uiState.judges.find { it.judgeNumber == selectedJudgeNumber }
                    if (activeJudge != null) {
                        Text(
                            text = "${activeJudge.name} • ${activeJudge.specialty}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            OutlinedTextField(
                value = identifier,
                onValueChange = onIdentifierChange,
                label = { Text("Email / Username") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier.fillMaxWidth().testTag("login_identifier_input")
            )

            OutlinedTextField(
                value = secret,
                onValueChange = onSecretChange,
                label = { Text(if (selectedRole == UserRole.ADMIN) "Password Admin" else "PIN / Password Juri") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                trailingIcon = {
                    IconButton(onClick = onTogglePassword) {
                        Icon(
                            imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Tampilkan atau sembunyikan password"
                        )
                    }
                },
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                modifier = Modifier.fillMaxWidth().testTag("login_secret_input")
            )

            if (uiState.authError != null) {
                Surface(
                    color = CrimsonSoft,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = uiState.authError,
                        color = CrimsonRed,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Button(
                onClick = onLogin,
                enabled = !uiState.isAuthenticating,
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonRed,
                    contentColor = CrispWhite
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("login_submit_button")
            ) {
                if (uiState.isAuthenticating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = CrispWhite,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedRole == UserRole.ADMIN) "Masuk Dashboard Admin" else "Masuk Meja Juri $selectedJudgeNumber",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            HorizontalDivider()

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Akses Cepat Demo (1-Ketuk)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AssistChip(
                        onClick = { onQuickDemoLogin(UserRole.ADMIN, 1) },
                        label = { Text("Admin") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = NavyPrimary,
                            labelColor = CrispWhite,
                            leadingIconContentColor = GoldChampionship
                        ),
                        modifier = Modifier.testTag("quick_login_admin")
                    )
                    (1..5).forEach { num ->
                        AssistChip(
                            onClick = { onQuickDemoLogin(UserRole.JUDGE, num) },
                            label = { Text("Juri $num") },
                            modifier = Modifier.testTag("quick_login_judge_$num")
                        )
                    }
                }
            }
        }
    }
}
