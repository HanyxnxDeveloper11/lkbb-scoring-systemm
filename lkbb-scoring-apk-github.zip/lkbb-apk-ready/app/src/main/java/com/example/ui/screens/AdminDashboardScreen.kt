package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CompetitionCategory
import com.example.data.model.EventStatus
import com.example.data.model.Team
import com.example.data.model.TeamPerformanceStatus
import com.example.ui.LkbbUiState
import com.example.ui.components.CompetitionBannerImage
import com.example.ui.components.CompetitionLogoBadge
import com.example.ui.components.GlobalLockBanner
import com.example.ui.components.MetricStatCard
import com.example.ui.components.StatusPill
import com.example.ui.components.SupabaseConnectionCard
import com.example.ui.components.TeamEditorDialog
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySoft
import com.example.ui.theme.NavySurface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class AdminKpiItem(
    val title: String,
    val value: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val accent: androidx.compose.ui.graphics.Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminDashboardScreen(
    uiState: LkbbUiState,
    onOpenJudges: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenRanking: () -> Unit,
    onOpenArchive: () -> Unit,
    onOpenArchiveDetail: (String) -> Unit,
    onCreateNewEvent: () -> Unit,
    onScoreTeam: (String) -> Unit,
    onSaveTeam: (String?, Int, String, String, String, CompetitionCategory, String) -> Unit,
    onUpdateTeamStatus: (Team, TeamPerformanceStatus) -> Unit,
    onDeleteTeam: (Team) -> Unit,
    onToggleGlobalLock: () -> Unit,
    onSyncSupabase: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var editingTeam by remember { mutableStateOf<Team?>(null) }

    val leader = uiState.rankings.firstOrNull { it.finalScore > 0.0 }
    val completionRatio = (uiState.completedSheetCount.toFloat() / uiState.totalExpectedSheets.toFloat()).coerceIn(0f, 1f)
    val completionPercent = (completionRatio * 100).toInt()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = CrimsonRed,
                contentColor = CrispWhite,
                modifier = Modifier.testTag("admin_add_team_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Tambah Pleton")
            }
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWide = maxWidth >= 720.dp

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (uiState.isCurrentEventLockedForEditing) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = CrimsonSoft),
                            border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = CrimsonRed)
                                    Text(
                                        text = "Event ini berstatus SELESAI & dikunci permanen. Buka arsip di Detail Arsip jika perlu koreksi.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = NavyDeep,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                OutlinedButton(onClick = { onOpenArchiveDetail(uiState.competitionConfig.id) }) {
                                    Text("Detail")
                                }
                            }
                        }
                    }
                } else {
                    item {
                        GlobalLockBanner(
                            isLocked = uiState.competitionConfig.isScoringLocked,
                            onToggle = onToggleGlobalLock
                        )
                    }
                }

                // Hero Command Header
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                        border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.5f))
                    ) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            CompetitionBannerImage(
                                bannerUrl = uiState.competitionConfig.bannerUrl,
                                contentDescription = "Header Command Center Admin",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(145.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(145.dp)
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                NavyDeep.copy(alpha = 0.94f),
                                                NavyPrimary.copy(alpha = 0.78f),
                                                NavySurface.copy(alpha = 0.35f)
                                            )
                                        )
                                    )
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CompetitionLogoBadge(
                                    logoUrl = uiState.competitionConfig.logoUrl,
                                    contentDescription = "Logo Perlombaan",
                                    modifier = Modifier.size(48.dp)
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    StatusPill(
                                        text = "COMMAND CENTER ADMIN • ${uiState.competitionConfig.rankingMode.label.uppercase(Locale.getDefault())}",
                                        containerColor = GoldChampionship,
                                        contentColor = NavyDeep
                                    )
                                    Text(
                                        text = uiState.competitionConfig.name,
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = CrispWhite
                                    )
                                    Text(
                                        text = "${uiState.competitionConfig.location} • ${uiState.competitionConfig.eventDate}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CrispWhite.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }
                }

                // KPI Grid
                item {
                    val columns = if (isWide) 4 else 2
                    val cards = listOf(
                        AdminKpiItem("Total Pleton", "${uiState.teams.size}", "Peserta terdaftar", Icons.Default.Groups, NavyPrimary),
                        AdminKpiItem("Progress 5 Juri", "$completionPercent%", "${uiState.completedSheetCount}/${uiState.totalExpectedSheets} lembar kunci", Icons.Default.TaskAlt, EmeraldSuccess),
                        AdminKpiItem("Pimpinan Skor", leader?.let { String.format(Locale.US, "%.1f", it.finalScore) } ?: "0.0", leader?.team?.name ?: "Belum ada nilai", Icons.Default.EmojiEvents, GoldChampionship),
                        AdminKpiItem("Kriteria Aktif", "${uiState.activeCriteria.size}", "Total bobot ${uiState.totalWeightPercent}%", Icons.Default.Assessment, CrimsonRed)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        cards.chunked(columns).forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                rowItems.forEach { item ->
                                    MetricStatCard(
                                        title = item.title,
                                        value = item.value,
                                        subtitle = item.subtitle,
                                        icon = item.icon,
                                        accentColor = item.accent,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                // Quick Navigation Shortcuts (including ARSIP PERLOMBAAN)
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Navigasi Modul Utama",
                                style = MaterialTheme.typography.titleMedium
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = onOpenArchive,
                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = CrispWhite),
                                    modifier = Modifier.testTag("admin_nav_archive")
                                ) {
                                    Icon(Icons.Default.Archive, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("ARSIP PERLOMBAAN", fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = onCreateNewEvent,
                                    colors = ButtonDefaults.buttonColors(containerColor = NavySurface, contentColor = CrispWhite),
                                    modifier = Modifier.testTag("admin_create_event_button")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Buat Event Baru")
                                }
                                Button(
                                    onClick = onOpenJudges,
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = CrispWhite),
                                    modifier = Modifier.testTag("admin_nav_judges")
                                ) {
                                    Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Monitor 5 Juri")
                                }
                                Button(
                                    onClick = onOpenRanking,
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldChampionship, contentColor = NavyDeep),
                                    modifier = Modifier.testTag("admin_nav_ranking")
                                ) {
                                    Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Dashboard Ranking", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = onOpenSettings,
                                    modifier = Modifier.testTag("admin_nav_settings")
                                ) {
                                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Pengaturan Lomba")
                                }
                            }
                        }
                    }
                }

                // Multi-Event Global Statistics & Recent History (Section G)
                item {
                    val stats = uiState.globalArchiveStats
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.55f)),
                        modifier = Modifier.testTag("admin_global_stats_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.EventNote, contentDescription = null, tint = NavyPrimary)
                                    Column {
                                        Text("Statistik Multi-Event & Arsip", style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            text = "Ringkasan seluruh perlombaan lintas periode",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                OutlinedButton(onClick = onOpenArchive) {
                                    Text("Semua Arsip")
                                }
                            }

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                GlobalStatChip("Total Perlombaan", "${stats.totalEvents}", NavyPrimary)
                                GlobalStatChip("Event Aktif", "${stats.activeEvents}", EmeraldSuccess)
                                GlobalStatChip("Event Selesai", "${stats.finishedEvents}", GoldChampionship, NavyDeep)
                                GlobalStatChip("Total Peserta", "${stats.totalParticipantsAllEvents}", NavySurface)
                                GlobalStatChip("Total Juri", "${stats.totalJudgesAllEvents}", CrimsonRed)
                            }

                            if (uiState.archiveSummaries.isNotEmpty()) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                                Text("Riwayat Event Terbaru", style = MaterialTheme.typography.labelLarge)
                                val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
                                uiState.archiveSummaries.take(4).forEach { summary ->
                                    val c = summary.config
                                    val (stBg, stFg) = when (c.status) {
                                        EventStatus.ACTIVE -> EmeraldSoft to EmeraldSuccess
                                        EventStatus.DRAFT -> AmberSoft to AmberWarning
                                        EventStatus.FINISHED -> NavySoft to NavyPrimary
                                    }
                                    Surface(
                                        onClick = { onOpenArchiveDetail(c.id) },
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        border = BorderStroke(
                                            width = if (c.id == uiState.competitionConfig.id) 1.5.dp else 1.dp,
                                            color = if (c.id == uiState.competitionConfig.id) GoldChampionship else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("admin_recent_event_${c.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            CompetitionLogoBadge(
                                                logoUrl = c.logoUrl,
                                                contentDescription = "Logo ${c.name}",
                                                modifier = Modifier.size(34.dp)
                                            )
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = c.name,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${c.eventDate} • ${summary.teamCount} Peserta • ${summary.judgeCount} Juri • Dibuat ${dateFormat.format(Date(c.createdAtMillis))}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            StatusPill(text = c.status.label, containerColor = stBg, contentColor = stFg)
                                            Icon(Icons.Default.FolderOpen, contentDescription = "Buka arsip", tint = NavyPrimary, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Supabase Cloud Readiness Card
                item {
                    SupabaseConnectionCard(
                        isConfigured = uiState.isSupabaseConfigured,
                        isSyncing = uiState.isSyncing,
                        onSyncClick = onSyncSupabase
                    )
                }

                // Team Roster Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Daftar Pleton Peserta",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "Kelola urutan tampil dan pantau jumlah juri yang sudah menilai.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(
                            onClick = { showAddDialog = true },
                            modifier = Modifier.testTag("admin_add_team_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Tambah")
                        }
                    }
                }

                items(uiState.teams, key = { it.id }) { team ->
                    val teamSheets = uiState.scoreSheets.filter { it.teamId == team.id }
                    val lockedCount = teamSheets.count { it.isLocked }
                    AdminTeamRowCard(
                        team = team,
                        lockedJudgeCount = lockedCount,
                        onScoreClick = { onScoreTeam(team.id) },
                        onEditClick = { editingTeam = team },
                        onStatusChange = { status -> onUpdateTeamStatus(team, status) },
                        onDeleteClick = { onDeleteTeam(team) }
                    )
                }

                // Recent Activity Logs
                if (uiState.activityLogs.isNotEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.History, contentDescription = null, tint = NavyPrimary)
                                    Text("Log Aktivitas Terkini", style = MaterialTheme.typography.titleMedium)
                                }
                                val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
                                uiState.activityLogs.take(6).forEach { log ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${log.actor}: ${log.message}",
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = formatter.format(Date(log.timestampMillis)),
                                            style = MonoTextStyles.BadgeCode,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    if (showAddDialog) {
        val nextNum = (uiState.teams.maxOfOrNull { it.orderNumber } ?: 0) + 1
        TeamEditorDialog(
            suggestedOrderNumber = nextNum,
            onDismiss = { showAddDialog = false },
            onConfirm = { order, name, squad, code, cat, danton ->
                onSaveTeam(null, order, name, squad, code, cat, danton)
                showAddDialog = false
            }
        )
    }

    editingTeam?.let { teamToEdit ->
        TeamEditorDialog(
            initialTeam = teamToEdit,
            suggestedOrderNumber = teamToEdit.orderNumber,
            onDismiss = { editingTeam = null },
            onConfirm = { order, name, squad, code, cat, danton ->
                onSaveTeam(teamToEdit.id, order, name, squad, code, cat, danton)
                editingTeam = null
            }
        )
    }
}

@Composable
private fun AdminTeamRowCard(
    team: Team,
    lockedJudgeCount: Int,
    onScoreClick: () -> Unit,
    onEditClick: () -> Unit,
    onStatusChange: (TeamPerformanceStatus) -> Unit,
    onDeleteClick: () -> Unit
) {
    var statusMenuExpanded by remember { mutableStateOf(false) }
    val (statusBg, statusFg) = when (team.status) {
        TeamPerformanceStatus.FINISHED -> EmeraldSoft to EmeraldSuccess
        TeamPerformanceStatus.PERFORMING -> AmberSoft to AmberWarning
        TeamPerformanceStatus.WAITING -> NavySoft to NavyPrimary
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(NavyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "%02d".format(team.orderNumber),
                            style = MonoTextStyles.TableCell,
                            color = GoldChampionship,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = team.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val squadPart = if (team.squadName.isNotBlank()) "${team.squadName} • " else ""
                        Text(
                            text = "$squadPart${team.category.displayName} • Danton: ${team.dantonName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Box {
                    Surface(
                        onClick = { statusMenuExpanded = true },
                        color = statusBg,
                        contentColor = statusFg,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.testTag("team_status_pill_${team.id}")
                    ) {
                        Text(
                            text = team.status.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = statusMenuExpanded,
                        onDismissRequest = { statusMenuExpanded = false }
                    ) {
                        TeamPerformanceStatus.entries.forEach { st ->
                            DropdownMenuItem(
                                text = { Text(st.label) },
                                onClick = {
                                    onStatusChange(st)
                                    statusMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Juri Terkunci: $lockedJudgeCount / 5",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { lockedJudgeCount / 5f },
                        color = if (lockedJudgeCount == 5) EmeraldSuccess else GoldChampionship,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                }
                Spacer(Modifier.width(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier.testTag("edit_team_${team.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit ${team.name}")
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.testTag("delete_team_${team.id}")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus ${team.name}", tint = CrimsonRed)
                    }
                    Button(
                        onClick = onScoreClick,
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = CrispWhite),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("score_team_${team.id}")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Nilai", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun GlobalStatChip(
    label: String,
    value: String,
    containerColor: androidx.compose.ui.graphics.Color,
    contentColor: androidx.compose.ui.graphics.Color = CrispWhite
) {
    Surface(
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = value,
                style = MonoTextStyles.CardScore,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = contentColor.copy(alpha = 0.88f)
            )
        }
    }
}

