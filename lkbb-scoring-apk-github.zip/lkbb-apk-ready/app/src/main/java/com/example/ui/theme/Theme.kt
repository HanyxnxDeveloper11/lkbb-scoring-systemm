package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LkbbDarkColorScheme = darkColorScheme(
    primary = GoldBright,
    onPrimary = NavyDeep,
    primaryContainer = NavySurface,
    onPrimaryContainer = CrispWhite,
    secondary = CrimsonBright,
    onSecondary = CrispWhite,
    secondaryContainer = CrimsonDark,
    onSecondaryContainer = CrimsonSoft,
    tertiary = GoldChampionship,
    onTertiary = NavyDeep,
    tertiaryContainer = GoldOnContainer,
    onTertiaryContainer = GoldSoft,
    background = NavyDeep,
    onBackground = CrispWhite,
    surface = NavyPrimary,
    onSurface = CrispWhite,
    surfaceVariant = NavySurface,
    onSurfaceVariant = Color(0xFFB7C5DA),
    outline = Color(0xFF2D4B77),
    error = CrimsonBright,
    onError = CrispWhite
)

private val LkbbLightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = CrispWhite,
    primaryContainer = NavySoft,
    onPrimaryContainer = NavyPrimary,
    secondary = CrimsonRed,
    onSecondary = CrispWhite,
    secondaryContainer = CrimsonSoft,
    onSecondaryContainer = CrimsonDark,
    tertiary = GoldChampionship,
    onTertiary = NavyDeep,
    tertiaryContainer = GoldSoft,
    onTertiaryContainer = GoldOnContainer,
    background = OffWhiteBackground,
    onBackground = TextNavy,
    surface = CrispWhite,
    onSurface = TextNavy,
    surfaceVariant = SurfaceMuted,
    onSurfaceVariant = TextSlate,
    outline = OutlineSubtle,
    error = CrimsonRed,
    onError = CrispWhite
)

@Composable
fun LkbbScoringTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) LkbbDarkColorScheme else LkbbLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = LkbbTypography,
        content = content
    )
}
