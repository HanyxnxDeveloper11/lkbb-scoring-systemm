package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CompetitionCategory
import com.example.data.model.RankingMode
import com.example.data.model.TeamRankingSummary
import com.example.data.model.UserRole
import com.example.ui.LkbbUiState
import com.example.ui.components.CompetitionLogoBadge
import com.example.ui.components.GoldRankBadge
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySurface
import java.util.Locale

@Composable
fun RankingDashboardScreen(
    uiState: LkbbUiState,
    shareText: String
) {
    val context = LocalContext.current
    val config = uiState.competitionConfig
    val isAdmin = uiState.session?.role == UserRole.ADMIN
    var selectedCategory by remember { mutableStateOf<CompetitionCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    if (!config.isRankingPublished && !isAdmin) {
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, GoldChampionship)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = GoldChampionship,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "Klasemen Sementara Disembunyikan",
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Admin menonaktifkan publikasi ranking sementara hingga pengumuman resmi.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        return
    }

    val filteredRankings = remember(uiState.rankings, selectedCategory, searchQuery) {
        uiState.rankings
            .filter { summary ->
                (selectedCategory == null || summary.team.category == selectedCategory) &&
                    (searchQuery.isBlank() ||
                        summary.team.name.contains(searchQuery, ignoreCase = true) ||
                        summary.team.squadName.contains(searchQuery, ignoreCase = true) ||
                        summary.team.orderNumber.toString().contains(searchQuery))
            }
            .mapIndexed { idx, summary -> summary.copy(rank = idx + 1) }
    }

    val topThree = filteredRankings.take(3).filter { it.finalScore > 0.0 }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Championship Header Banner
            item {
                Card(
                    modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(NavyDeep, NavySurface)))
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (config.logoUrl.isNotBlank()) {
                            CompetitionLogoBadge(
                                logoUrl = config.logoUrl,
                                contentDescription = "Logo Kejuaraan LKBB",
                                modifier = Modifier.size(64.dp)
                            )
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.img_podium_crest),
                                contentDescription = "Piala Kejuaraan LKBB",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                StatusPill(
                                    text = if (config.rankingMode == RankingMode.FINAL) "FINAL RANKING RESMI" else "LIVE RANKING",
                                    containerColor = if (config.rankingMode == RankingMode.FINAL) GoldChampionship else EmeraldSoft,
                                    contentColor = if (config.rankingMode == RankingMode.FINAL) NavyDeep else EmeraldSuccess
                                )
                                if (!config.isRankingPublished) {
                                    StatusPill(
                                        text = "Pratinjau Admin",
                                        containerColor = AmberSoft,
                                        contentColor = AmberWarning
                                    )
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = config.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = CrispWhite
                            )
                            Text(
                                text = if (config.rankingMode == RankingMode.FINAL && config.onlyCountLockedInFinal) {
                                    "Menghitung nilai juri yang telah dikunci dikurangi penalti resmi."
                                } else {
                                    "Akumulasi real-time nilai 5 Juri dikurangi penalti."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = CrispWhite.copy(alpha = 0.82f)
                            )
                        }
                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Hasil Peringkat ${uiState.competitionConfig.name}")
                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                }
                                context.startActivity(Intent.createChooser(intent, "Bagikan Peringkat LKBB"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = CrispWhite),
                            modifier = Modifier.testTag("ranking_share_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Bagikan hasil peringkat", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // Podium Top 3
            if (topThree.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        val podiumOrder = when (topThree.size) {
                            3 -> listOf(topThree[1], topThree[0], topThree[2])
                            2 -> listOf(topThree[1], topThree[0])
                            else -> listOf(topThree[0])
                        }
                        podiumOrder.forEach { item ->
                            PodiumSpotCard(
                                summary = item,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Search & Category Filters
            item {
                Column(
                    modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Cari nama sekolah atau nomor urut...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("ranking_search_input")
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedCategory == null,
                                onClick = { selectedCategory = null },
                                label = { Text("Semua Kategori") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NavyPrimary,
                                    selectedLabelColor = CrispWhite
                                ),
                                modifier = Modifier.testTag("ranking_filter_all")
                            )
                        }
                        items(CompetitionCategory.entries) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldChampionship,
                                    selectedLabelColor = NavyDeep
                                ),
                                modifier = Modifier.testTag("ranking_filter_${cat.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Full Ranking Cards
            if (filteredRankings.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Tidak ada peserta yang cocok dengan filter.")
                    }
                }
            } else {
                items(filteredRankings, key = { it.team.id }) { summary ->
                    ExpandableRankingCard(
                        summary = summary,
                        modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth()
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun PodiumSpotCard(
    summary: TeamRankingSummary,
    modifier: Modifier = Modifier
) {
    val isChampion = summary.rank == 1
    val cardColor = when (summary.rank) {
        1 -> GoldSoft
        2 -> NavyPrimary
        else -> CrimsonSoft
    }
    val textColor = when (summary.rank) {
        1 -> NavyDeep
        2 -> CrispWhite
        else -> CrimsonRed
    }
    val borderColor = when (summary.rank) {
        1 -> GoldChampionship
        2 -> NavyPrimary
        else -> CrimsonRed
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        border = BorderStroke(if (isChampion) 2.dp else 1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isChampion) 6.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = if (isChampion) 16.dp else 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            GoldRankBadge(rank = summary.rank)
            Text(
                text = summary.team.name,
                style = MaterialTheme.typography.titleSmall,
                color = textColor,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = String.format(Locale.US, "%.2f", summary.finalScore),
                style = MonoTextStyles.CardScore,
                color = textColor
            )
            Text(
                text = summary.team.category.displayName,
                style = MaterialTheme.typography.labelSmall,
                color = textColor.copy(alpha = 0.78f)
            )
        }
    }
}

@Composable
private fun ExpandableRankingCard(
    summary: TeamRankingSummary,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .clickable { expanded = !expanded }
            .testTag("ranking_card_${summary.team.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (summary.rank == 1) 1.5.dp else 1.dp,
            color = if (summary.rank == 1) GoldChampionship else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                GoldRankBadge(rank = summary.rank)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = summary.team.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    val squadText = if (summary.team.squadName.isNotBlank()) "${summary.team.squadName} • " else ""
                    Text(
                        text = "No. ${summary.team.orderNumber} • $squadText${summary.team.category.displayName} • ${summary.predicate}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = String.format(Locale.US, "%.2f", summary.finalScore),
                        style = MonoTextStyles.CardScore,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${summary.submittedJudgeCount}/5 Juri",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (summary.submittedJudgeCount == 5) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (expanded) "Tutup rincian" else "Lihat rincian",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HorizontalDivider()
                    Text(
                        text = "Rincian Nilai per Juri",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (1..5).forEach { j ->
                            val score = summary.judgeWeightedTotals[j]
                            val locked = summary.judgeLockedStates[j] == true
                            Surface(
                                color = if (locked) EmeraldSoft else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "J$j",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = score?.let { String.format(Locale.US, "%.1f", it) } ?: "—",
                                        style = MonoTextStyles.TableCell,
                                        color = if (locked) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Nilai Kotor: ${String.format(Locale.US, "%.2f", summary.grossScore)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Total Penalti: -${summary.totalPenalty}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (summary.totalPenalty > 0) CrimsonRed else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
