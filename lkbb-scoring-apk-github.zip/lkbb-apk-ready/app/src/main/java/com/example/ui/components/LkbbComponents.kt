package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.CompetitionCategory
import com.example.data.model.JudgeAccount
import com.example.data.model.PenaltyPreset
import com.example.data.model.ScoringCriterion
import com.example.data.model.Team
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldOnContainer
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySurface

@Composable
fun StatusPill(
    text: String,
    containerColor: Color,
    contentColor: Color,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(13.dp)
                )
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MetricStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color = GoldChampionship,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MonoTextStyles.CardScore,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SupabaseConnectionCard(
    isConfigured: Boolean,
    isSyncing: Boolean,
    onSyncClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyPrimary),
        border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(NavyDeep, NavySurface)
                    )
                )
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(GoldChampionship.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isConfigured) Icons.Default.CloudDone else Icons.Default.CloudQueue,
                        contentDescription = "Status Supabase",
                        tint = GoldChampionship,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = if (isConfigured) "Supabase Cloud Terkonfigurasi" else "Arsitektur Siap Supabase (Mode Lokal)",
                        style = MaterialTheme.typography.titleSmall,
                        color = CrispWhite
                    )
                    Text(
                        text = if (isConfigured) {
                            "Auth & PostgreSQL siap (${com.example.data.remote.SupabaseConfig.maskedKeyLabel})."
                        } else {
                            "Data tersimpan di Room DB lokal. Tambahkan SUPABASE_URL & SUPABASE_ANON (sb_publishable_...) di Secrets."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = CrispWhite.copy(alpha = 0.78f)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onSyncClick,
                enabled = !isSyncing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldChampionship,
                    contentColor = NavyDeep
                ),
                modifier = Modifier.testTag("supabase_sync_button")
            ) {
                if (isSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = NavyDeep
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Sinkronkan Supabase",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Sync", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamEditorDialog(
    initialTeam: Team? = null,
    suggestedOrderNumber: Int,
    onDismiss: () -> Unit,
    onConfirm: (orderNumber: Int, name: String, squadName: String, contingentCode: String, category: CompetitionCategory, dantonName: String) -> Unit
) {
    var orderText by remember { mutableStateOf((initialTeam?.orderNumber ?: suggestedOrderNumber).toString()) }
    var name by remember { mutableStateOf(initialTeam?.name ?: "") }
    var squadName by remember { mutableStateOf(initialTeam?.squadName ?: "") }
    var code by remember { mutableStateOf(initialTeam?.contingentCode ?: "") }
    var danton by remember { mutableStateOf(initialTeam?.dantonName ?: "") }
    var selectedCategory by remember { mutableStateOf(initialTeam?.category ?: CompetitionCategory.SMA) }
    var categoryExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialTeam == null) "Tambah Peserta LKBB" else "Edit Peserta #${initialTeam.orderNumber}",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = orderText,
                    onValueChange = { orderText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Nomor Urut Tampil") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_team_order")
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Sekolah / Satuan") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_team_name")
                )
                OutlinedTextField(
                    value = squadName,
                    onValueChange = { squadName = it },
                    label = { Text("Nama Regu / Pleton") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_team_squad")
                )
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("Kode Kontingen (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = danton,
                    onValueChange = { danton = it },
                    label = { Text("Nama Danton (Komandan)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = !categoryExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedCategory.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Kategori Lomba") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false }
                    ) {
                        CompetitionCategory.entries.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.displayName) },
                                onClick = {
                                    selectedCategory = cat
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val num = orderText.toIntOrNull() ?: suggestedOrderNumber
                    onConfirm(num, name, squadName, code, selectedCategory, danton)
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("dialog_team_save_button")
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun CriterionEditorDialog(
    initialCriterion: ScoringCriterion? = null,
    nextSortOrder: Int,
    onDismiss: () -> Unit,
    onConfirm: (ScoringCriterion) -> Unit
) {
    var name by remember { mutableStateOf(initialCriterion?.name ?: "") }
    var group by remember { mutableStateOf(initialCriterion?.categoryGroup ?: "Ketangkasan") }
    var maxScoreText by remember { mutableStateOf((initialCriterion?.maxScore ?: 100).toString()) }
    var weightText by remember { mutableStateOf((initialCriterion?.weightPercent ?: 10).toString()) }
    var description by remember { mutableStateOf(initialCriterion?.description ?: "") }
    var isActive by remember { mutableStateOf(initialCriterion?.isActive ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialCriterion == null) "Tambah Kriteria Penilaian" else "Edit Kriteria",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Aspek Penilaian") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = group,
                    onValueChange = { group = it },
                    label = { Text("Kelompok Aspek") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = maxScoreText,
                        onValueChange = { maxScoreText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Skor Maks") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = weightText,
                        onValueChange = { weightText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Bobot (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Panduan Penilaian") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Aktif dalam Penilaian", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isActive, onCheckedChange = { isActive = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val criterion = ScoringCriterion(
                        id = initialCriterion?.id ?: "crit_${System.currentTimeMillis()}",
                        name = name.trim(),
                        categoryGroup = group.trim().ifEmpty { "Umum" },
                        maxScore = (maxScoreText.toIntOrNull() ?: 100).coerceIn(10, 1000),
                        weightPercent = (weightText.toIntOrNull() ?: 10).coerceIn(1, 100),
                        description = description.trim(),
                        isActive = isActive,
                        sortOrder = initialCriterion?.sortOrder ?: nextSortOrder
                    )
                    onConfirm(criterion)
                },
                enabled = name.isNotBlank()
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun JudgeEditorDialog(
    judge: JudgeAccount,
    onDismiss: () -> Unit,
    onConfirm: (JudgeAccount) -> Unit
) {
    var name by remember { mutableStateOf(judge.name) }
    var specialty by remember { mutableStateOf(judge.specialty) }
    var email by remember { mutableStateOf(judge.email) }
    var pinCode by remember { mutableStateOf(judge.pinCode) }
    var isActive by remember { mutableStateOf(judge.isActive) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengaturan Juri ${judge.judgeNumber}") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Lengkap Juri") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = specialty,
                    onValueChange = { specialty = it },
                    label = { Text("Bidang Fokus Penilaian") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Login / Supabase") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = pinCode,
                    onValueChange = { pinCode = it.take(12) },
                    label = { Text("PIN / Password Akses") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Akun Juri Aktif", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isActive, onCheckedChange = { isActive = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        judge.copy(
                            name = name.trim().ifEmpty { judge.name },
                            specialty = specialty.trim().ifEmpty { judge.specialty },
                            email = email.trim().ifEmpty { judge.email },
                            pinCode = pinCode.trim().ifEmpty { judge.pinCode },
                            isActive = isActive
                        )
                    )
                }
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun JudgeStatusBadge(isLocked: Boolean, hasDraft: Boolean) {
    when {
        isLocked -> StatusPill(
            text = "Terkunci",
            containerColor = EmeraldSoft,
            contentColor = EmeraldSuccess,
            icon = Icons.Default.Lock
        )
        hasDraft -> StatusPill(
            text = "Draft",
            containerColor = AmberSoft,
            contentColor = AmberWarning
        )
        else -> StatusPill(
            text = "Belum",
            containerColor = CrimsonSoft,
            contentColor = CrimsonRed
        )
    }
}

@Composable
fun GoldRankBadge(rank: Int, modifier: Modifier = Modifier) {
    val (bg, fg) = when (rank) {
        1 -> GoldChampionship to NavyDeep
        2 -> NavyPrimary to CrispWhite
        3 -> CrimsonRed to CrispWhite
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Box(
        modifier = modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(bg),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "#$rank",
            style = MonoTextStyles.BadgeCode,
            color = fg
        )
    }
}

@Composable
fun GlobalLockBanner(isLocked: Boolean, onToggle: (() -> Unit)? = null) {
    if (!isLocked) return
    Surface(
        color = CrimsonSoft,
        border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Lock, contentDescription = "Penilaian Terkunci", tint = CrimsonRed)
                Text(
                    text = "Penilaian Resmi Dikunci oleh Admin. Hanya mode baca yang aktif.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CrimsonRed,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (onToggle != null) {
                OutlinedButton(
                    onClick = onToggle,
                    border = BorderStroke(1.dp, CrimsonRed)
                ) {
                    Text("Buka Kunci", color = CrimsonRed, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun PenaltyEditorDialog(
    initialPenalty: PenaltyPreset? = null,
    nextSortOrder: Int,
    onDismiss: () -> Unit,
    onConfirm: (PenaltyPreset) -> Unit
) {
    var label by remember { mutableStateOf(initialPenalty?.label ?: "") }
    var pointsText by remember { mutableStateOf((initialPenalty?.points ?: 5).toString()) }
    var description by remember { mutableStateOf(initialPenalty?.description ?: "") }
    var isActive by remember { mutableStateOf(initialPenalty?.isActive ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialPenalty == null) "Tambah Aturan Penalti" else "Edit Aturan Penalti",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Nama Pelanggaran / Penalti") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_penalty_label")
                )
                OutlinedTextField(
                    value = pointsText,
                    onValueChange = { pointsText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Poin Pengurangan") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_penalty_points")
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Keterangan (opsional)") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Aktif di Formulir Juri", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isActive, onCheckedChange = { isActive = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val preset = PenaltyPreset(
                        id = initialPenalty?.id ?: "pen_${System.currentTimeMillis()}",
                        label = label.trim(),
                        points = (pointsText.toIntOrNull() ?: 5).coerceIn(1, 200),
                        description = description.trim(),
                        isActive = isActive,
                        sortOrder = initialPenalty?.sortOrder ?: nextSortOrder
                    )
                    onConfirm(preset)
                },
                enabled = label.isNotBlank(),
                modifier = Modifier.testTag("dialog_penalty_save_button")
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun CompetitionBannerImage(
    bannerUrl: String,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    if (bannerUrl.isNotBlank()) {
        AsyncImage(
            model = bannerUrl,
            contentDescription = contentDescription,
            placeholder = painterResource(id = R.drawable.img_lkbb_hero_banner),
            error = painterResource(id = R.drawable.img_lkbb_hero_banner),
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Image(
            painter = painterResource(id = R.drawable.img_lkbb_hero_banner),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    }
}

@Composable
fun CompetitionLogoBadge(
    logoUrl: String,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    var loadFailed by remember(logoUrl) { mutableStateOf(false) }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(GoldChampionship),
        contentAlignment = Alignment.Center
    ) {
        if (logoUrl.isNotBlank() && !loadFailed) {
            AsyncImage(
                model = logoUrl,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                onError = { loadFailed = true },
                modifier = Modifier
                    .matchParentSize()
                    .clip(CircleShape)
            )
        } else {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = contentDescription,
                tint = NavyDeep,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

