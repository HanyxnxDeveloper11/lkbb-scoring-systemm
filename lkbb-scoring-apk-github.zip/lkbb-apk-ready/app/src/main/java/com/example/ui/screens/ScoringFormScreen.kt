package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.LkbbConstants
import com.example.data.model.ScoringCriterion
import com.example.data.model.UserRole
import com.example.data.repository.LkbbScoringRepository
import com.example.ui.LkbbUiState
import com.example.ui.components.GlobalLockBanner
import com.example.ui.components.JudgeStatusBadge
import com.example.ui.components.StatusPill
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ScoringFormScreen(
    uiState: LkbbUiState,
    onSelectTarget: (teamId: String?, judgeNumber: Int?) -> Unit,
    onSaveScoreSheet: (
        teamId: String,
        judgeNumber: Int,
        criterionScores: Map<String, Int>,
        penaltyPoints: Int,
        penaltyNotes: String,
        evaluatorNotes: String,
        lockAfterSave: Boolean
    ) -> Unit,
    onUnlockScoreSheet: (teamId: String, judgeNumber: Int) -> Unit
) {
    val teams = uiState.teams
    val activeCriteria = uiState.activeCriteria
    val isAdmin = uiState.session?.role == UserRole.ADMIN
    val activeTeamId = uiState.selectedTeamIdForScoring ?: teams.firstOrNull()?.id
    val activeTeam = teams.find { it.id == activeTeamId }
    val activeJudgeNumber = uiState.selectedJudgeNumberForScoring

    val existingSheet = remember(uiState.scoreSheets, activeTeamId, activeJudgeNumber) {
        uiState.scoreSheets.find { it.teamId == activeTeamId && it.judgeNumber == activeJudgeNumber }
    }

    val scoreMap = remember { mutableStateMapOf<String, Int>() }
    var selectedPenalties by remember { mutableStateOf(setOf<String>()) }
    var extraPenalty by remember { mutableIntStateOf(0) }
    var evaluatorNotes by remember { mutableStateOf("") }

    val activePenalties = uiState.activePenalties

    LaunchedEffect(activeTeamId, activeJudgeNumber, existingSheet, activeCriteria, activePenalties) {
        scoreMap.clear()
        activeCriteria.forEach { crit ->
            scoreMap[crit.id] = existingSheet?.criterionScores?.get(crit.id) ?: (crit.maxScore * 0.85).roundToInt()
        }
        val notes = existingSheet?.penaltyNotes.orEmpty()
        val matched = activePenalties
            .filter { notes.contains(it.label, ignoreCase = true) }
            .map { it.id }
            .toSet()
        selectedPenalties = matched
        val matchedSum = activePenalties
            .filter { it.id in matched }
            .sumOf { it.points }
        extraPenalty = ((existingSheet?.penaltyPoints ?: 0) - matchedSum).coerceAtLeast(0)
        evaluatorNotes = existingSheet?.evaluatorNotes.orEmpty()
    }

    val isArchivedLocked = uiState.isCurrentEventLockedForEditing
    val isGloballyLocked = uiState.competitionConfig.isScoringLocked || isArchivedLocked
    val isSheetLocked = existingSheet?.isLocked == true
    val isReadOnly = isGloballyLocked || isSheetLocked

    val weightedGross = LkbbScoringRepository.calculateWeightedJudgeScore(scoreMap, activeCriteria)
    val presetPenaltyTotal = activePenalties
        .filter { it.id in selectedPenalties }
        .sumOf { it.points }
    val totalPenalty = presetPenaltyTotal + extraPenalty
    val netJudgeScore = (weightedGross - totalPenalty).coerceAtLeast(0.0)

    var teamDropdownExpanded by remember { mutableStateOf(false) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        if (teams.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada pleton peserta. Tambahkan pleton di Dashboard Admin.")
            }
            return@BoxWithConstraints
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(
                    modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GlobalLockBanner(isLocked = isGloballyLocked)
                    if (isArchivedLocked) {
                        Text(
                            text = "Status Event SELESAI & Arsip Terkunci: Nilai final tidak dapat diubah. Pembukaan arsip hanya dapat dilakukan Admin di Detail Arsip.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonRed,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Target Selection & Live Score Banner
            item {
                Card(
                    modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "FORMULIR PENILAIAN LKBB",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = GoldChampionship
                                )
                                Text(
                                    text = activeTeam?.let { "#${it.orderNumber} ${it.name}" } ?: "Pilih Pleton",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = CrispWhite
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = String.format(Locale.US, "%.2f", netJudgeScore),
                                    style = MonoTextStyles.HeroScore,
                                    color = GoldChampionship
                                )
                                Text(
                                    text = if (totalPenalty > 0) "Gross ${String.format(Locale.US, "%.1f", weightedGross)} (-$totalPenalty)" else "Skor Terbobot /100",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CrispWhite.copy(alpha = 0.8f)
                                )
                            }
                        }

                        // Team Dropdown Selector
                        ExposedDropdownMenuBox(
                            expanded = teamDropdownExpanded,
                            onExpandedChange = { teamDropdownExpanded = !teamDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                value = activeTeam?.let { "#${it.orderNumber} • ${it.name} (${it.category.displayName})" } ?: "",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Pilih Pleton Peserta", color = GoldChampionship) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = teamDropdownExpanded) },
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                                    focusedTextColor = CrispWhite,
                                    unfocusedTextColor = CrispWhite,
                                    focusedBorderColor = GoldChampionship,
                                    unfocusedBorderColor = CrispWhite.copy(alpha = 0.45f)
                                ),
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                                    .testTag("scoring_team_selector")
                            )
                            ExposedDropdownMenu(
                                expanded = teamDropdownExpanded,
                                onDismissRequest = { teamDropdownExpanded = false }
                            ) {
                                teams.forEach { t ->
                                    DropdownMenuItem(
                                        text = { Text("#${t.orderNumber} ${t.name} (${t.category.displayName})") },
                                        onClick = {
                                            onSelectTarget(t.id, null)
                                            teamDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Judge selector (interactive for Admin, locked badge for Judge)
                        if (isAdmin) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Pilih Meja Juri (Mode Admin):",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CrispWhite.copy(alpha = 0.8f)
                                )
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(uiState.judges, key = { it.judgeNumber }) { j ->
                                        FilterChip(
                                            selected = activeJudgeNumber == j.judgeNumber,
                                            onClick = { onSelectTarget(null, j.judgeNumber) },
                                            label = { Text("Juri ${j.judgeNumber}") },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = GoldChampionship,
                                                selectedLabelColor = NavyDeep,
                                                containerColor = CrispWhite.copy(alpha = 0.12f),
                                                labelColor = CrispWhite
                                            ),
                                            modifier = Modifier.testTag("scoring_judge_chip_${j.judgeNumber}")
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val judgeObj = uiState.judges.find { it.judgeNumber == activeJudgeNumber }
                            Text(
                                text = "Penilai: Juri $activeJudgeNumber (${judgeObj?.specialty ?: ""})",
                                style = MaterialTheme.typography.bodySmall,
                                color = CrispWhite.copy(alpha = 0.9f)
                            )
                            JudgeStatusBadge(
                                isLocked = isSheetLocked,
                                hasDraft = existingSheet != null && !isSheetLocked
                            )
                        }

                        if (isSheetLocked && isAdmin && activeTeamId != null && !isArchivedLocked) {
                            OutlinedButton(
                                onClick = { onUnlockScoreSheet(activeTeamId, activeJudgeNumber) },
                                border = BorderStroke(1.dp, GoldChampionship),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldChampionship),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Admin: Buka Kunci Lembar Nilai untuk Koreksi")
                            }
                        }
                    }
                }
            }

            // Criteria Scoring Cards
            items(activeCriteria, key = { it.id }) { criterion ->
                val currentValue = scoreMap[criterion.id] ?: (criterion.maxScore * 0.85).roundToInt()
                CriterionScoringCard(
                    criterion = criterion,
                    value = currentValue,
                    isReadOnly = isReadOnly,
                    onValueChange = { newVal ->
                        scoreMap[criterion.id] = newVal.coerceIn(0, criterion.maxScore)
                    },
                    modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth()
                )
            }

            // Penalty / Deduction Card
            item {
                Card(
                    modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.WarningAmber, contentDescription = null, tint = CrimsonRed)
                            Text("Pengurangan Nilai / Penalti", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.weight(1f))
                            StatusPill(
                                text = "-$totalPenalty poin",
                                containerColor = CrimsonSoft,
                                contentColor = CrimsonRed
                            )
                        }

                        activePenalties.forEach { preset ->
                            val checked = preset.id in selectedPenalties
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    enabled = !isReadOnly,
                                    onCheckedChange = { isChecked ->
                                        selectedPenalties = if (isChecked) {
                                            selectedPenalties + preset.id
                                        } else {
                                            selectedPenalties - preset.id
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = CrimsonRed)
                                )
                                Text(
                                    text = preset.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "-${preset.points}",
                                    style = MonoTextStyles.TableCell,
                                    color = CrimsonRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Penalti Tambahan Manual:", style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { extraPenalty = (extraPenalty - 5).coerceAtLeast(0) },
                                    enabled = !isReadOnly && extraPenalty > 0
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Kurangi penalti")
                                }
                                Text(
                                    text = "$extraPenalty",
                                    style = MonoTextStyles.TableCell,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                IconButton(
                                    onClick = { extraPenalty += 5 },
                                    enabled = !isReadOnly
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Tambah penalti")
                                }
                            }
                        }
                    }
                }
            }

            // Evaluator Notes & Action Buttons
            item {
                Card(
                    modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = evaluatorNotes,
                            onValueChange = { evaluatorNotes = it },
                            enabled = !isReadOnly,
                            label = { Text("Catatan Evaluasi Juri untuk Pleton") },
                            minLines = 2,
                            maxLines = 4,
                            modifier = Modifier.fillMaxWidth().testTag("scoring_notes_input")
                        )

                        if (!isReadOnly && activeTeamId != null) {
                            val penaltyDesc = activePenalties
                                .filter { it.id in selectedPenalties }
                                .joinToString("; ") { it.label }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        onSaveScoreSheet(
                                            activeTeamId,
                                            activeJudgeNumber,
                                            scoreMap.toMap(),
                                            totalPenalty,
                                            penaltyDesc,
                                            evaluatorNotes,
                                            false
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp)
                                        .testTag("scoring_save_draft_button")
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Simpan Draft")
                                }
                                Button(
                                    onClick = {
                                        onSaveScoreSheet(
                                            activeTeamId,
                                            activeJudgeNumber,
                                            scoreMap.toMap(),
                                            totalPenalty,
                                            penaltyDesc,
                                            evaluatorNotes,
                                            true
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CrimsonRed,
                                        contentColor = CrispWhite
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp)
                                        .testTag("scoring_lock_submit_button")
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Kunci & Kirim")
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(GoldSoft)
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NavyDeep)
                                Text(
                                    text = "Lembar nilai ini sudah dikunci. Hubungi Admin jika perlu pembukaan kunci.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NavyDeep,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CriterionScoringCard(
    criterion: ScoringCriterion,
    value: Int,
    isReadOnly: Boolean,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatusPill(
                            text = criterion.categoryGroup,
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        StatusPill(
                            text = "Bobot ${criterion.weightPercent}%",
                            containerColor = GoldSoft,
                            contentColor = NavyDeep
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(criterion.name, style = MaterialTheme.typography.titleMedium)
                    if (criterion.description.isNotBlank()) {
                        Text(
                            text = criterion.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Surface(
                    color = NavyPrimary,
                    contentColor = GoldChampionship,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "$value / ${criterion.maxScore}",
                        style = MonoTextStyles.CardScore,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onValueChange(value - 1) },
                    enabled = !isReadOnly && value > 0
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Kurangi skor ${criterion.name}")
                }
                Slider(
                    value = value.coerceIn(0, criterion.maxScore.coerceAtLeast(1)).toFloat(),
                    onValueChange = { onValueChange(it.roundToInt()) },
                    valueRange = 0f..criterion.maxScore.coerceAtLeast(1).toFloat(),
                    enabled = !isReadOnly,
                    colors = SliderDefaults.colors(
                        thumbColor = CrimsonRed,
                        activeTrackColor = NavyPrimary
                    ),
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { onValueChange(value + 1) },
                    enabled = !isReadOnly && value < criterion.maxScore
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah skor ${criterion.name}")
                }
            }

            if (!isReadOnly) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "Kurang" to (criterion.maxScore * 0.65).roundToInt(),
                        "Cukup" to (criterion.maxScore * 0.75).roundToInt(),
                        "Baik" to (criterion.maxScore * 0.85).roundToInt(),
                        "Istimewa" to (criterion.maxScore * 0.95).roundToInt()
                    ).forEach { (label, presetScore) ->
                        FilterChip(
                            selected = value == presetScore,
                            onClick = { onValueChange(presetScore) },
                            label = { Text("$label ($presetScore)") }
                        )
                    }
                }
            }
        }
    }
}
