package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

object SupabaseConfig {
    private fun isValidValue(raw: String): Boolean {
        val cleaned = raw.trim()
        return cleaned.isNotEmpty() &&
            !cleaned.startsWith("YOUR_SUPABASE_") &&
            cleaned != "null"
    }

    val url: String
        get() = BuildConfig.SUPABASE_URL.trim().trimEnd('/')

    val anonKey: String
        get() {
            val candidates = listOf(
                BuildConfig.SUPABASE_ANON.trim(),
                BuildConfig.SUPABASE_ANON_KEY.trim()
            ).filter(::isValidValue)
            return candidates.firstOrNull { it.startsWith("sb_publishable_") }
                ?: candidates.firstOrNull()
                ?: ""
        }

    val isPublishableKey: Boolean
        get() = anonKey.startsWith("sb_publishable_")

    val isConfigured: Boolean
        get() = isValidValue(url) &&
            url.startsWith("https://") &&
            isValidValue(anonKey)

    val maskedKeyLabel: String
        get() = when {
            !isConfigured -> "Belum dikonfigurasi"
            isPublishableKey -> "Publishable Key (${anonKey.take(18)}...)"
            else -> "Anon Key (${anonKey.take(12)}...)"
        }
}

data class SupabaseAuthRequest(
    val email: String,
    val password: String
)

data class SupabaseUserDto(
    val id: String? = null,
    val email: String? = null
)

data class SupabaseAuthResponse(
    @Json(name = "access_token") val accessToken: String? = null,
    @Json(name = "token_type") val tokenType: String? = null,
    val user: SupabaseUserDto? = null
)

data class SupabaseCompetitionDto(
    val id: String,
    val name: String,
    val theme: String = "",
    val organizer: String,
    val location: String,
    @Json(name = "event_date") val eventDate: String,
    val year: Int = 2026,
    @Json(name = "max_duration_minutes") val maxDurationMinutes: Int,
    @Json(name = "logo_url") val logoUrl: String = "",
    @Json(name = "banner_url") val bannerUrl: String = "",
    @Json(name = "ranking_mode") val rankingMode: String = "LIVE",
    @Json(name = "is_ranking_published") val isRankingPublished: Boolean = true,
    @Json(name = "only_count_locked_in_final") val onlyCountLockedInFinal: Boolean = true,
    @Json(name = "is_scoring_locked") val isScoringLocked: Boolean = false,
    val status: String = "ACTIVE",
    @Json(name = "is_archived_locked") val isArchivedLocked: Boolean = false,
    @Json(name = "created_at_millis") val createdAtMillis: Long = System.currentTimeMillis(),
    @Json(name = "reopen_reason") val reopenReason: String = "",
    @Json(name = "last_reopened_at_millis") val lastReopenedAtMillis: Long? = null
)

data class SupabaseCategoryDto(
    val id: String,
    @Json(name = "event_id") val eventId: String,
    val code: String,
    @Json(name = "display_name") val displayName: String,
    @Json(name = "is_enabled") val isEnabled: Boolean,
    @Json(name = "sort_order") val sortOrder: Int
)

data class SupabaseJudgeAccountDto(
    val id: String = "",
    @Json(name = "event_id") val eventId: String,
    @Json(name = "judge_number") val judgeNumber: Int,
    val name: String,
    val specialty: String,
    val email: String,
    @Json(name = "pin_code") val pinCode: String,
    @Json(name = "is_active") val isActive: Boolean
)

data class SupabaseCriterionDto(
    val id: String,
    @Json(name = "event_id") val eventId: String,
    val name: String,
    @Json(name = "category_group") val categoryGroup: String,
    @Json(name = "max_score") val maxScore: Int,
    @Json(name = "weight_percent") val weightPercent: Int,
    val description: String,
    @Json(name = "is_active") val isActive: Boolean,
    @Json(name = "sort_order") val sortOrder: Int
)

data class SupabasePenaltyPresetDto(
    val id: String,
    @Json(name = "event_id") val eventId: String,
    val label: String,
    val points: Int,
    val description: String,
    @Json(name = "is_active") val isActive: Boolean,
    @Json(name = "sort_order") val sortOrder: Int
)

data class SupabaseTeamDto(
    val id: String,
    @Json(name = "event_id") val eventId: String,
    @Json(name = "order_number") val orderNumber: Int,
    val name: String,
    @Json(name = "squad_name") val squadName: String = "",
    @Json(name = "contingent_code") val contingentCode: String,
    val category: String,
    @Json(name = "danton_name") val dantonName: String,
    val status: String
)

data class SupabaseScoreSheetDto(
    val id: String,
    @Json(name = "event_id") val eventId: String,
    @Json(name = "team_id") val teamId: String,
    @Json(name = "judge_number") val judgeNumber: Int,
    @Json(name = "criterion_scores_json") val criterionScoresJson: String,
    @Json(name = "penalty_points") val penaltyPoints: Int,
    @Json(name = "penalty_notes") val penaltyNotes: String,
    @Json(name = "evaluator_notes") val evaluatorNotes: String,
    @Json(name = "is_locked") val isLocked: Boolean,
    @Json(name = "updated_at_millis") val updatedAtMillis: Long
)

data class SupabaseArchiveResultDto(
    @Json(name = "event_id") val eventId: String,
    @Json(name = "snapshot_json") val snapshotJson: String,
    @Json(name = "total_participants") val totalParticipants: Int,
    @Json(name = "total_judges") val totalJudges: Int,
    @Json(name = "winner_summary") val winnerSummary: String,
    @Json(name = "locked_at_millis") val lockedAtMillis: Long,
    @Json(name = "locked_by") val lockedBy: String
)

data class SupabaseAuditLogDto(
    val id: String,
    @Json(name = "event_id") val eventId: String,
    val actor: String,
    @Json(name = "action_type") val actionType: String,
    val message: String,
    val reason: String,
    @Json(name = "timestamp_millis") val timestampMillis: Long
)

interface SupabaseRestApi {
    @POST("auth/v1/token?grant_type=password")
    suspend fun signInWithPassword(
        @Header("apikey") apiKey: String,
        @Body request: SupabaseAuthRequest
    ): Response<SupabaseAuthResponse>

    @GET("rest/v1/competitions?select=*&order=created_at_millis.desc")
    suspend fun fetchCompetitions(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("id") idFilter: String? = null
    ): Response<List<SupabaseCompetitionDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/competitions")
    suspend fun upsertCompetition(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: SupabaseCompetitionDto
    ): Response<Unit>

    @DELETE("rest/v1/competitions")
    suspend fun deleteCompetition(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("id") idFilter: String
    ): Response<Unit>

    @GET("rest/v1/categories?select=*&order=sort_order.asc")
    suspend fun fetchCategories(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabaseCategoryDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/categories")
    suspend fun upsertCategories(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: List<SupabaseCategoryDto>
    ): Response<Unit>

    @GET("rest/v1/judge_accounts?select=*&order=judge_number.asc")
    suspend fun fetchJudges(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabaseJudgeAccountDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/judge_accounts")
    suspend fun upsertJudges(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: List<SupabaseJudgeAccountDto>
    ): Response<Unit>

    @GET("rest/v1/scoring_criteria?select=*&order=sort_order.asc")
    suspend fun fetchCriteria(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabaseCriterionDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/scoring_criteria")
    suspend fun upsertCriteria(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: List<SupabaseCriterionDto>
    ): Response<Unit>

    @DELETE("rest/v1/scoring_criteria")
    suspend fun deleteCriterion(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("id") idFilter: String,
        @Query("event_id") eventIdFilter: String
    ): Response<Unit>

    @GET("rest/v1/penalty_presets?select=*&order=sort_order.asc")
    suspend fun fetchPenaltyPresets(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabasePenaltyPresetDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/penalty_presets")
    suspend fun upsertPenaltyPresets(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: List<SupabasePenaltyPresetDto>
    ): Response<Unit>

    @DELETE("rest/v1/penalty_presets")
    suspend fun deletePenaltyPreset(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("id") idFilter: String,
        @Query("event_id") eventIdFilter: String
    ): Response<Unit>

    @GET("rest/v1/teams?select=*&order=order_number.asc")
    suspend fun fetchTeams(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabaseTeamDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/teams")
    suspend fun upsertTeams(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: List<SupabaseTeamDto>
    ): Response<Unit>

    @DELETE("rest/v1/teams")
    suspend fun deleteTeam(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("id") idFilter: String,
        @Query("event_id") eventIdFilter: String
    ): Response<Unit>

    @GET("rest/v1/score_sheets?select=*")
    suspend fun fetchScoreSheets(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabaseScoreSheetDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/score_sheets")
    suspend fun upsertScoreSheets(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: List<SupabaseScoreSheetDto>
    ): Response<Unit>

    @GET("rest/v1/results?select=*")
    suspend fun fetchResults(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabaseArchiveResultDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/results")
    suspend fun upsertResult(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: SupabaseArchiveResultDto
    ): Response<Unit>

    @GET("rest/v1/audit_logs?select=*&order=timestamp_millis.desc&limit=100")
    suspend fun fetchAuditLogs(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Query("event_id") eventIdFilter: String
    ): Response<List<SupabaseAuditLogDto>>

    @Headers("Prefer: resolution=merge-duplicates")
    @POST("rest/v1/audit_logs")
    suspend fun upsertAuditLogs(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearer: String?,
        @Body body: List<SupabaseAuditLogDto>
    ): Response<Unit>
}

object SupabaseClientFactory {
    fun createApi(): SupabaseRestApi? {
        if (!SupabaseConfig.isConfigured) return null
        return runCatching {
            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(8, TimeUnit.SECONDS)
                .writeTimeout(8, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()
            val baseUrl = "${SupabaseConfig.url}/"
            Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(SupabaseRestApi::class.java)
        }.getOrNull()
    }
}

object SupabaseSchema {
    const val POSTGRES_DDL = """
-- Skema Multi-Event & Digital Competition Archive (PostgreSQL + RLS)
-- Setiap tabel terisolasi oleh event_id dengan Foreign Key & Cascade Protection.

create table if not exists competitions (
  id text primary key,
  name text not null,
  theme text not null default '',
  organizer text not null,
  location text not null,
  event_date text not null,
  year int not null default 2026,
  max_duration_minutes int not null default 10,
  logo_url text not null default '',
  banner_url text not null default '',
  ranking_mode text not null default 'LIVE',
  is_ranking_published boolean not null default true,
  only_count_locked_in_final boolean not null default true,
  is_scoring_locked boolean not null default false,
  status text not null default 'ACTIVE',
  is_archived_locked boolean not null default false,
  created_at_millis bigint not null default 0,
  reopen_reason text not null default '',
  last_reopened_at_millis bigint
);

create table if not exists categories (
  id text primary key,
  event_id text not null references competitions(id) on delete cascade,
  code text not null,
  display_name text not null,
  is_enabled boolean not null default true,
  sort_order int not null default 0
);
create index if not exists idx_categories_event on categories(event_id);

create table if not exists judge_accounts (
  id text primary key,
  event_id text not null references competitions(id) on delete cascade,
  judge_number int not null check (judge_number between 1 and 5),
  name text not null,
  specialty text not null,
  email text not null,
  pin_code text not null,
  is_active boolean not null default true
);
create index if not exists idx_judges_event on judge_accounts(event_id);

create table if not exists scoring_criteria (
  id text primary key,
  event_id text not null references competitions(id) on delete cascade,
  name text not null,
  category_group text not null,
  max_score int not null default 100,
  weight_percent int not null default 10,
  description text not null default '',
  is_active boolean not null default true,
  sort_order int not null default 0
);
create index if not exists idx_criteria_event on scoring_criteria(event_id);

create table if not exists penalty_presets (
  id text primary key,
  event_id text not null references competitions(id) on delete cascade,
  label text not null,
  points int not null default 5,
  description text not null default '',
  is_active boolean not null default true,
  sort_order int not null default 0
);
create index if not exists idx_penalties_event on penalty_presets(event_id);

create table if not exists teams (
  id text primary key,
  event_id text not null references competitions(id) on delete cascade,
  order_number int not null,
  name text not null,
  squad_name text not null default '',
  contingent_code text not null,
  category text not null,
  danton_name text not null,
  status text not null default 'WAITING'
);
create index if not exists idx_teams_event on teams(event_id);

create table if not exists score_sheets (
  id text primary key,
  event_id text not null references competitions(id) on delete cascade,
  team_id text not null references teams(id) on delete cascade,
  judge_number int not null check (judge_number between 1 and 5),
  criterion_scores_json text not null,
  penalty_points int not null default 0,
  penalty_notes text not null default '',
  evaluator_notes text not null default '',
  is_locked boolean not null default false,
  updated_at_millis bigint not null
);
create index if not exists idx_scores_event on score_sheets(event_id);

create table if not exists results (
  event_id text primary key references competitions(id) on delete cascade,
  snapshot_json text not null,
  total_participants int not null,
  total_judges int not null,
  winner_summary text not null,
  locked_at_millis bigint not null,
  locked_by text not null
);

create table if not exists audit_logs (
  id text primary key,
  event_id text not null references competitions(id) on delete cascade,
  actor text not null,
  action_type text not null default 'SYSTEM',
  message text not null,
  reason text not null default '',
  timestamp_millis bigint not null
);
create index if not exists idx_audit_logs_event on audit_logs(event_id);

-- Row Level Security (RLS) berdasarkan Role & Event Status
alter table competitions enable row level security;
alter table categories enable row level security;
alter table judge_accounts enable row level security;
alter table scoring_criteria enable row level security;
alter table penalty_presets enable row level security;
alter table teams enable row level security;
alter table score_sheets enable row level security;
alter table results enable row level security;
alter table audit_logs enable row level security;

-- Admin memiliki akses penuh; Juri hanya membaca event aktif & mengubah nilai jika arsip tidak dikunci
create policy "auth_read_events" on competitions for select using (auth.role() = 'authenticated');
create policy "admin_manage_events" on competitions for all
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

create policy "judge_write_unlocked_scores" on score_sheets for insert with check (
  exists (
    select 1 from competitions c
    where c.id = event_id and c.is_archived_locked = false and c.is_scoring_locked = false
  )
);
"""
}
