package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ActivityLogEntry
import com.example.data.model.ArchiveResultSnapshot
import com.example.data.model.AuditActionType
import com.example.data.model.CompetitionCategory
import com.example.data.model.CompetitionConfig
import com.example.data.model.EventCategoryConfig
import com.example.data.model.EventStatus
import com.example.data.model.JudgeAccount
import com.example.data.model.JudgeScoreSheet
import com.example.data.model.LkbbConstants
import com.example.data.model.PenaltyPreset
import com.example.data.model.RankingMode
import com.example.data.model.ScoringCriterion
import com.example.data.model.Team
import com.example.data.model.TeamPerformanceStatus
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "app_state")
data class AppStateEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "competition_config")
data class CompetitionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val theme: String,
    val organizer: String,
    val location: String,
    val eventDate: String,
    val year: Int,
    val maxDurationMinutes: Int,
    val logoUrl: String,
    val bannerUrl: String,
    val rankingMode: String,
    val isRankingPublished: Boolean,
    val onlyCountLockedInFinal: Boolean,
    val isScoringLocked: Boolean,
    val status: String,
    val isArchivedLocked: Boolean,
    val createdAtMillis: Long,
    val reopenReason: String,
    val lastReopenedAtMillis: Long?,
    val lastSyncedAtMillis: Long?
)

@Entity(
    tableName = "event_categories",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"])]
)
data class EventCategoryEntity(
    @PrimaryKey val id: String,
    val eventId: String,
    val code: String,
    val displayName: String,
    val isEnabled: Boolean,
    val sortOrder: Int
)

@Entity(
    tableName = "judge_accounts",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"])]
)
data class JudgeAccountEntity(
    @PrimaryKey val id: String,
    val eventId: String,
    val judgeNumber: Int,
    val name: String,
    val specialty: String,
    val email: String,
    val pinCode: String,
    val isActive: Boolean
)

@Entity(
    tableName = "scoring_criteria",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"])]
)
data class CriterionEntity(
    @PrimaryKey val id: String,
    val eventId: String,
    val name: String,
    val categoryGroup: String,
    val maxScore: Int,
    val weightPercent: Int,
    val description: String,
    val isActive: Boolean,
    val sortOrder: Int
)

@Entity(
    tableName = "penalty_presets",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"])]
)
data class PenaltyPresetEntity(
    @PrimaryKey val id: String,
    val eventId: String,
    val label: String,
    val points: Int,
    val description: String,
    val isActive: Boolean,
    val sortOrder: Int
)

@Entity(
    tableName = "teams",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"])]
)
data class TeamEntity(
    @PrimaryKey val id: String,
    val eventId: String,
    val orderNumber: Int,
    val name: String,
    val squadName: String,
    val contingentCode: String,
    val category: String,
    val dantonName: String,
    val status: String
)

@Entity(
    tableName = "score_sheets",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"]), Index(value = ["teamId"])]
)
data class ScoreSheetEntity(
    @PrimaryKey val id: String,
    val eventId: String,
    val teamId: String,
    val judgeNumber: Int,
    val criterionScoresJson: String,
    val penaltyPoints: Int,
    val penaltyNotes: String,
    val evaluatorNotes: String,
    val isLocked: Boolean,
    val updatedAtMillis: Long
)

@Entity(
    tableName = "archive_results",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"], unique = true)]
)
data class ArchiveResultEntity(
    @PrimaryKey val eventId: String,
    val snapshotJson: String,
    val totalParticipants: Int,
    val totalJudges: Int,
    val winnerSummary: String,
    val lockedAtMillis: Long,
    val lockedBy: String
)

@Entity(
    tableName = "activity_logs",
    foreignKeys = [
        ForeignKey(
            entity = CompetitionEntity::class,
            parentColumns = ["id"],
            childColumns = ["eventId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["eventId"])]
)
data class ActivityLogEntity(
    @PrimaryKey val id: String,
    val eventId: String,
    val actor: String,
    val actionType: String,
    val message: String,
    val reason: String,
    val timestampMillis: Long
)

@Dao
interface LkbbDao {
    // Active event pointer
    @Query("SELECT value FROM app_state WHERE `key` = 'active_event_id' LIMIT 1")
    fun observeActiveEventId(): Flow<String?>

    @Query("SELECT value FROM app_state WHERE `key` = 'active_event_id' LIMIT 1")
    suspend fun getActiveEventIdOnce(): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAppState(state: AppStateEntity)

    // Competitions (all events + single event)
    @Query("SELECT * FROM competition_config ORDER BY createdAtMillis DESC")
    fun observeAllCompetitions(): Flow<List<CompetitionEntity>>

    @Query("SELECT * FROM competition_config ORDER BY createdAtMillis DESC")
    suspend fun getAllCompetitionsOnce(): List<CompetitionEntity>

    @Query("SELECT * FROM competition_config WHERE id = :eventId LIMIT 1")
    fun observeCompetitionById(eventId: String): Flow<CompetitionEntity?>

    @Query("SELECT * FROM competition_config WHERE id = :eventId LIMIT 1")
    suspend fun getCompetitionByIdOnce(eventId: String): CompetitionEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCompetitionIgnore(config: CompetitionEntity): Long

    @Update
    suspend fun updateCompetitionConfig(config: CompetitionEntity)

    @Transaction
    suspend fun upsertCompetitionConfig(config: CompetitionEntity) {
        if (insertCompetitionIgnore(config) == -1L) {
            updateCompetitionConfig(config)
        }
    }

    @Query("DELETE FROM competition_config WHERE id = :eventId")
    suspend fun deleteCompetitionById(eventId: String)

    // Event Categories (filtered by eventId)
    @Query("SELECT * FROM event_categories WHERE eventId = :eventId ORDER BY sortOrder ASC")
    fun observeCategoriesByEvent(eventId: String): Flow<List<EventCategoryEntity>>

    @Query("SELECT * FROM event_categories WHERE eventId = :eventId ORDER BY sortOrder ASC")
    suspend fun getCategoriesByEventOnce(eventId: String): List<EventCategoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCategories(categories: List<EventCategoryEntity>)

    // Judges (filtered by eventId + global aggregate)
    @Query("SELECT * FROM judge_accounts WHERE eventId = :eventId ORDER BY judgeNumber ASC")
    fun observeJudgesByEvent(eventId: String): Flow<List<JudgeAccountEntity>>

    @Query("SELECT * FROM judge_accounts WHERE eventId = :eventId ORDER BY judgeNumber ASC")
    suspend fun getJudgesByEventOnce(eventId: String): List<JudgeAccountEntity>

    @Query("SELECT * FROM judge_accounts")
    fun observeAllJudges(): Flow<List<JudgeAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJudges(judges: List<JudgeAccountEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJudge(judge: JudgeAccountEntity)

    // Criteria (filtered by eventId)
    @Query("SELECT * FROM scoring_criteria WHERE eventId = :eventId ORDER BY sortOrder ASC")
    fun observeCriteriaByEvent(eventId: String): Flow<List<CriterionEntity>>

    @Query("SELECT * FROM scoring_criteria WHERE eventId = :eventId ORDER BY sortOrder ASC")
    suspend fun getCriteriaByEventOnce(eventId: String): List<CriterionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCriteria(criteria: List<CriterionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCriterion(criterion: CriterionEntity)

    @Query("DELETE FROM scoring_criteria WHERE id = :id AND eventId = :eventId")
    suspend fun deleteCriterionById(id: String, eventId: String)

    // Penalty Presets (filtered by eventId)
    @Query("SELECT * FROM penalty_presets WHERE eventId = :eventId ORDER BY sortOrder ASC")
    fun observePenaltyPresetsByEvent(eventId: String): Flow<List<PenaltyPresetEntity>>

    @Query("SELECT * FROM penalty_presets WHERE eventId = :eventId ORDER BY sortOrder ASC")
    suspend fun getPenaltyPresetsByEventOnce(eventId: String): List<PenaltyPresetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPenaltyPresets(presets: List<PenaltyPresetEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPenaltyPreset(preset: PenaltyPresetEntity)

    @Query("DELETE FROM penalty_presets WHERE id = :id AND eventId = :eventId")
    suspend fun deletePenaltyPresetById(id: String, eventId: String)

    // Teams (filtered by eventId + global aggregate)
    @Query("SELECT * FROM teams WHERE eventId = :eventId ORDER BY orderNumber ASC")
    fun observeTeamsByEvent(eventId: String): Flow<List<TeamEntity>>

    @Query("SELECT * FROM teams WHERE eventId = :eventId ORDER BY orderNumber ASC")
    suspend fun getTeamsByEventOnce(eventId: String): List<TeamEntity>

    @Query("SELECT * FROM teams")
    fun observeAllTeams(): Flow<List<TeamEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTeams(teams: List<TeamEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTeam(team: TeamEntity)

    @Query("DELETE FROM teams WHERE id = :id AND eventId = :eventId")
    suspend fun deleteTeamById(id: String, eventId: String)

    @Query("DELETE FROM score_sheets WHERE teamId = :teamId AND eventId = :eventId")
    suspend fun deleteScoresByTeamId(teamId: String, eventId: String)

    // Score Sheets (filtered by eventId + global aggregate)
    @Query("SELECT * FROM score_sheets WHERE eventId = :eventId")
    fun observeScoreSheetsByEvent(eventId: String): Flow<List<ScoreSheetEntity>>

    @Query("SELECT * FROM score_sheets WHERE eventId = :eventId")
    suspend fun getScoreSheetsByEventOnce(eventId: String): List<ScoreSheetEntity>

    @Query("SELECT * FROM score_sheets")
    fun observeAllScoreSheets(): Flow<List<ScoreSheetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertScoreSheets(sheets: List<ScoreSheetEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertScoreSheet(sheet: ScoreSheetEntity)

    // Archive Result Snapshots
    @Query("SELECT * FROM archive_results")
    fun observeAllArchiveSnapshots(): Flow<List<ArchiveResultEntity>>

    @Query("SELECT * FROM archive_results WHERE eventId = :eventId LIMIT 1")
    suspend fun getArchiveSnapshotOnce(eventId: String): ArchiveResultEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertArchiveSnapshot(snapshot: ArchiveResultEntity)

    // Audit / Activity Logs (filtered by eventId)
    @Query("SELECT * FROM activity_logs WHERE eventId = :eventId ORDER BY timestampMillis DESC LIMIT 100")
    fun observeActivityLogsByEvent(eventId: String): Flow<List<ActivityLogEntity>>

    @Query("SELECT * FROM activity_logs WHERE eventId = :eventId ORDER BY timestampMillis DESC LIMIT 100")
    suspend fun getActivityLogsByEventOnce(eventId: String): List<ActivityLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ActivityLogEntity)

    // Scoped clears for single-event sync/reset (never deletes other events!)
    @Query("DELETE FROM score_sheets WHERE eventId = :eventId")
    suspend fun clearScoreSheetsForEvent(eventId: String)

    @Query("DELETE FROM teams WHERE eventId = :eventId")
    suspend fun clearTeamsForEvent(eventId: String)

    @Query("DELETE FROM scoring_criteria WHERE eventId = :eventId")
    suspend fun clearCriteriaForEvent(eventId: String)

    @Query("DELETE FROM penalty_presets WHERE eventId = :eventId")
    suspend fun clearPenaltyPresetsForEvent(eventId: String)

    @Query("DELETE FROM judge_accounts WHERE eventId = :eventId")
    suspend fun clearJudgesForEvent(eventId: String)

    @Query("DELETE FROM event_categories WHERE eventId = :eventId")
    suspend fun clearCategoriesForEvent(eventId: String)

    @Query("DELETE FROM activity_logs WHERE eventId = :eventId")
    suspend fun clearLogsForEvent(eventId: String)
}

@Database(
    entities = [
        AppStateEntity::class,
        CompetitionEntity::class,
        EventCategoryEntity::class,
        JudgeAccountEntity::class,
        CriterionEntity::class,
        PenaltyPresetEntity::class,
        TeamEntity::class,
        ScoreSheetEntity::class,
        ArchiveResultEntity::class,
        ActivityLogEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class LkbbDatabase : RoomDatabase() {
    abstract fun lkbbDao(): LkbbDao

    companion object {
        @Volatile
        private var INSTANCE: LkbbDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `logoUrl` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `bannerUrl` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `rankingMode` TEXT NOT NULL DEFAULT 'LIVE'")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `isRankingPublished` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `onlyCountLockedInFinal` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `teams` ADD COLUMN `squadName` TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `penalty_presets` (`id` TEXT NOT NULL, `label` TEXT NOT NULL, `points` INTEGER NOT NULL, `description` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("PRAGMA foreign_keys=OFF")

                // 1. Ensure default competition_config exists & upgrade columns cleanly
                var activeEventId = "lkbb-2026-main"
                db.query("SELECT id FROM competition_config LIMIT 1").use { cursor ->
                    if (cursor.moveToFirst()) {
                        val existingId = cursor.getString(0)
                        if (!existingId.isNullOrBlank()) activeEventId = existingId
                    }
                }

                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `theme` TEXT NOT NULL DEFAULT 'Langkah Tegap Pemuda Berkarakter'")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `year` INTEGER NOT NULL DEFAULT 2026")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `status` TEXT NOT NULL DEFAULT 'ACTIVE'")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `isArchivedLocked` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `createdAtMillis` INTEGER NOT NULL DEFAULT 1763452800000")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `reopenReason` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `competition_config` ADD COLUMN `lastReopenedAtMillis` INTEGER")

                // 2. App state table storing active_event_id
                db.execSQL("CREATE TABLE IF NOT EXISTS `app_state` (`key` TEXT NOT NULL, `value` TEXT NOT NULL, PRIMARY KEY(`key`))")
                db.execSQL("INSERT OR REPLACE INTO `app_state` (`key`, `value`) VALUES ('active_event_id', ?)", arrayOf(activeEventId))

                // 3. Event categories table
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `event_categories` (`id` TEXT NOT NULL, `eventId` TEXT NOT NULL, `code` TEXT NOT NULL, `displayName` TEXT NOT NULL, `isEnabled` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_event_categories_eventId` ON `event_categories` (`eventId`)")

                // 4. Recreate judge_accounts with eventId + composite id + FK
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `judge_accounts_new` (`id` TEXT NOT NULL, `eventId` TEXT NOT NULL, `judgeNumber` INTEGER NOT NULL, `name` TEXT NOT NULL, `specialty` TEXT NOT NULL, `email` TEXT NOT NULL, `pinCode` TEXT NOT NULL, `isActive` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL(
                    "INSERT INTO `judge_accounts_new` (`id`, `eventId`, `judgeNumber`, `name`, `specialty`, `email`, `pinCode`, `isActive`) " +
                        "SELECT ? || '_j' || `judgeNumber`, ?, `judgeNumber`, `name`, `specialty`, `email`, `pinCode`, `isActive` FROM `judge_accounts`",
                    arrayOf(activeEventId, activeEventId)
                )
                db.execSQL("DROP TABLE `judge_accounts`")
                db.execSQL("ALTER TABLE `judge_accounts_new` RENAME TO `judge_accounts`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_judge_accounts_eventId` ON `judge_accounts` (`eventId`)")

                // 5. Recreate scoring_criteria with eventId + FK
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `scoring_criteria_new` (`id` TEXT NOT NULL, `eventId` TEXT NOT NULL, `name` TEXT NOT NULL, `categoryGroup` TEXT NOT NULL, `maxScore` INTEGER NOT NULL, `weightPercent` INTEGER NOT NULL, `description` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL(
                    "INSERT INTO `scoring_criteria_new` (`id`, `eventId`, `name`, `categoryGroup`, `maxScore`, `weightPercent`, `description`, `isActive`, `sortOrder`) " +
                        "SELECT `id`, ?, `name`, `categoryGroup`, `maxScore`, `weightPercent`, `description`, `isActive`, `sortOrder` FROM `scoring_criteria`",
                    arrayOf(activeEventId)
                )
                db.execSQL("DROP TABLE `scoring_criteria`")
                db.execSQL("ALTER TABLE `scoring_criteria_new` RENAME TO `scoring_criteria`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_scoring_criteria_eventId` ON `scoring_criteria` (`eventId`)")

                // 6. Recreate penalty_presets with eventId + FK
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `penalty_presets_new` (`id` TEXT NOT NULL, `eventId` TEXT NOT NULL, `label` TEXT NOT NULL, `points` INTEGER NOT NULL, `description` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL(
                    "INSERT INTO `penalty_presets_new` (`id`, `eventId`, `label`, `points`, `description`, `isActive`, `sortOrder`) " +
                        "SELECT `id`, ?, `label`, `points`, `description`, `isActive`, `sortOrder` FROM `penalty_presets`",
                    arrayOf(activeEventId)
                )
                db.execSQL("DROP TABLE `penalty_presets`")
                db.execSQL("ALTER TABLE `penalty_presets_new` RENAME TO `penalty_presets`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_penalty_presets_eventId` ON `penalty_presets` (`eventId`)")

                // 7. Recreate teams with eventId + FK
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `teams_new` (`id` TEXT NOT NULL, `eventId` TEXT NOT NULL, `orderNumber` INTEGER NOT NULL, `name` TEXT NOT NULL, `squadName` TEXT NOT NULL, `contingentCode` TEXT NOT NULL, `category` TEXT NOT NULL, `dantonName` TEXT NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL(
                    "INSERT INTO `teams_new` (`id`, `eventId`, `orderNumber`, `name`, `squadName`, `contingentCode`, `category`, `dantonName`, `status`) " +
                        "SELECT `id`, ?, `orderNumber`, `name`, `squadName`, `contingentCode`, `category`, `dantonName`, `status` FROM `teams`",
                    arrayOf(activeEventId)
                )
                db.execSQL("DROP TABLE `teams`")
                db.execSQL("ALTER TABLE `teams_new` RENAME TO `teams`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_teams_eventId` ON `teams` (`eventId`)")

                // 8. Recreate score_sheets with eventId + FK
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `score_sheets_new` (`id` TEXT NOT NULL, `eventId` TEXT NOT NULL, `teamId` TEXT NOT NULL, `judgeNumber` INTEGER NOT NULL, `criterionScoresJson` TEXT NOT NULL, `penaltyPoints` INTEGER NOT NULL, `penaltyNotes` TEXT NOT NULL, `evaluatorNotes` TEXT NOT NULL, `isLocked` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL(
                    "INSERT INTO `score_sheets_new` (`id`, `eventId`, `teamId`, `judgeNumber`, `criterionScoresJson`, `penaltyPoints`, `penaltyNotes`, `evaluatorNotes`, `isLocked`, `updatedAtMillis`) " +
                        "SELECT `id`, ?, `teamId`, `judgeNumber`, `criterionScoresJson`, `penaltyPoints`, `penaltyNotes`, `evaluatorNotes`, `isLocked`, `updatedAtMillis` FROM `score_sheets`",
                    arrayOf(activeEventId)
                )
                db.execSQL("DROP TABLE `score_sheets`")
                db.execSQL("ALTER TABLE `score_sheets_new` RENAME TO `score_sheets`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_score_sheets_eventId` ON `score_sheets` (`eventId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_score_sheets_teamId` ON `score_sheets` (`teamId`)")

                // 9. Create archive_results snapshot table
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `archive_results` (`eventId` TEXT NOT NULL, `snapshotJson` TEXT NOT NULL, `totalParticipants` INTEGER NOT NULL, `totalJudges` INTEGER NOT NULL, `winnerSummary` TEXT NOT NULL, `lockedAtMillis` INTEGER NOT NULL, `lockedBy` TEXT NOT NULL, PRIMARY KEY(`eventId`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_archive_results_eventId` ON `archive_results` (`eventId`)")

                // 10. Recreate activity_logs with eventId, actionType, reason + FK
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `activity_logs_new` (`id` TEXT NOT NULL, `eventId` TEXT NOT NULL, `actor` TEXT NOT NULL, `actionType` TEXT NOT NULL, `message` TEXT NOT NULL, `reason` TEXT NOT NULL, `timestampMillis` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`eventId`) REFERENCES `competition_config`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL(
                    "INSERT INTO `activity_logs_new` (`id`, `eventId`, `actor`, `actionType`, `message`, `reason`, `timestampMillis`) " +
                        "SELECT `id`, ?, `actor`, 'SYSTEM', `message`, '', `timestampMillis` FROM `activity_logs`",
                    arrayOf(activeEventId)
                )
                db.execSQL("DROP TABLE `activity_logs`")
                db.execSQL("ALTER TABLE `activity_logs_new` RENAME TO `activity_logs`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_activity_logs_eventId` ON `activity_logs` (`eventId`)")

                db.execSQL("PRAGMA foreign_keys=ON")
            }
        }

        fun getInstance(context: Context): LkbbDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LkbbDatabase::class.java,
                    "lkbb_scoring.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

object LkbbEntityMapper {
    fun CompetitionEntity.toDomain() = CompetitionConfig(
        id = id,
        name = name,
        theme = theme,
        organizer = organizer,
        location = location,
        eventDate = eventDate,
        year = year,
        maxDurationMinutes = maxDurationMinutes,
        logoUrl = logoUrl,
        bannerUrl = bannerUrl,
        rankingMode = runCatching { RankingMode.valueOf(rankingMode) }.getOrDefault(RankingMode.LIVE),
        isRankingPublished = isRankingPublished,
        onlyCountLockedInFinal = onlyCountLockedInFinal,
        isScoringLocked = isScoringLocked,
        status = runCatching { EventStatus.valueOf(status) }.getOrDefault(EventStatus.ACTIVE),
        isArchivedLocked = isArchivedLocked,
        createdAtMillis = createdAtMillis,
        reopenReason = reopenReason,
        lastReopenedAtMillis = lastReopenedAtMillis,
        lastSyncedAtMillis = lastSyncedAtMillis
    )

    fun CompetitionConfig.toEntity() = CompetitionEntity(
        id = id,
        name = name,
        theme = theme,
        organizer = organizer,
        location = location,
        eventDate = eventDate,
        year = year,
        maxDurationMinutes = maxDurationMinutes,
        logoUrl = logoUrl,
        bannerUrl = bannerUrl,
        rankingMode = rankingMode.name,
        isRankingPublished = isRankingPublished,
        onlyCountLockedInFinal = onlyCountLockedInFinal,
        isScoringLocked = isScoringLocked,
        status = status.name,
        isArchivedLocked = isArchivedLocked,
        createdAtMillis = createdAtMillis,
        reopenReason = reopenReason,
        lastReopenedAtMillis = lastReopenedAtMillis,
        lastSyncedAtMillis = lastSyncedAtMillis
    )

    fun EventCategoryEntity.toDomain() = EventCategoryConfig(
        id = id,
        eventId = eventId,
        code = code,
        displayName = displayName,
        isEnabled = isEnabled,
        sortOrder = sortOrder
    )

    fun EventCategoryConfig.toEntity() = EventCategoryEntity(
        id = id,
        eventId = eventId,
        code = code,
        displayName = displayName,
        isEnabled = isEnabled,
        sortOrder = sortOrder
    )

    fun JudgeAccountEntity.toDomain() = JudgeAccount(
        judgeNumber = judgeNumber,
        name = name,
        specialty = specialty,
        email = email,
        pinCode = pinCode,
        isActive = isActive,
        eventId = eventId
    )

    fun JudgeAccount.toEntity(overrideEventId: String = eventId) = JudgeAccountEntity(
        id = "${overrideEventId}_j${judgeNumber}",
        eventId = overrideEventId,
        judgeNumber = judgeNumber,
        name = name,
        specialty = specialty,
        email = email,
        pinCode = pinCode,
        isActive = isActive
    )

    fun CriterionEntity.toDomain() = ScoringCriterion(
        id = id,
        name = name,
        categoryGroup = categoryGroup,
        maxScore = maxScore,
        weightPercent = weightPercent,
        description = description,
        isActive = isActive,
        sortOrder = sortOrder,
        eventId = eventId
    )

    fun ScoringCriterion.toEntity(overrideEventId: String = eventId) = CriterionEntity(
        id = id,
        eventId = overrideEventId,
        name = name,
        categoryGroup = categoryGroup,
        maxScore = maxScore,
        weightPercent = weightPercent,
        description = description,
        isActive = isActive,
        sortOrder = sortOrder
    )

    fun PenaltyPresetEntity.toDomain() = PenaltyPreset(
        id = id,
        label = label,
        points = points,
        description = description,
        isActive = isActive,
        sortOrder = sortOrder,
        eventId = eventId
    )

    fun PenaltyPreset.toEntity(overrideEventId: String = eventId) = PenaltyPresetEntity(
        id = id,
        eventId = overrideEventId,
        label = label,
        points = points,
        description = description,
        isActive = isActive,
        sortOrder = sortOrder
    )

    fun TeamEntity.toDomain() = Team(
        id = id,
        orderNumber = orderNumber,
        name = name,
        squadName = squadName,
        contingentCode = contingentCode,
        category = runCatching { CompetitionCategory.valueOf(category) }.getOrDefault(CompetitionCategory.SMA),
        dantonName = dantonName,
        status = runCatching { TeamPerformanceStatus.valueOf(status) }.getOrDefault(TeamPerformanceStatus.WAITING),
        eventId = eventId
    )

    fun Team.toEntity(overrideEventId: String = eventId) = TeamEntity(
        id = id,
        eventId = overrideEventId,
        orderNumber = orderNumber,
        name = name,
        squadName = squadName,
        contingentCode = contingentCode,
        category = category.name,
        dantonName = dantonName,
        status = status.name
    )

    fun ScoreSheetEntity.toDomain(): JudgeScoreSheet {
        val map = mutableMapOf<String, Int>()
        runCatching {
            val json = JSONObject(criterionScoresJson)
            val keys = json.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = json.optInt(k, 0)
            }
        }
        return JudgeScoreSheet(
            id = id,
            teamId = teamId,
            judgeNumber = judgeNumber,
            criterionScores = map,
            penaltyPoints = penaltyPoints,
            penaltyNotes = penaltyNotes,
            evaluatorNotes = evaluatorNotes,
            isLocked = isLocked,
            updatedAtMillis = updatedAtMillis,
            eventId = eventId
        )
    }

    fun JudgeScoreSheet.toEntity(overrideEventId: String = eventId): ScoreSheetEntity {
        val json = JSONObject()
        criterionScores.forEach { (k, v) -> json.put(k, v) }
        return ScoreSheetEntity(
            id = id,
            eventId = overrideEventId,
            teamId = teamId,
            judgeNumber = judgeNumber,
            criterionScoresJson = json.toString(),
            penaltyPoints = penaltyPoints,
            penaltyNotes = penaltyNotes,
            evaluatorNotes = evaluatorNotes,
            isLocked = isLocked,
            updatedAtMillis = updatedAtMillis
        )
    }

    fun ArchiveResultEntity.toDomain() = ArchiveResultSnapshot(
        eventId = eventId,
        snapshotJson = snapshotJson,
        totalParticipants = totalParticipants,
        totalJudges = totalJudges,
        winnerSummary = winnerSummary,
        lockedAtMillis = lockedAtMillis,
        lockedBy = lockedBy
    )

    fun ArchiveResultSnapshot.toEntity() = ArchiveResultEntity(
        eventId = eventId,
        snapshotJson = snapshotJson,
        totalParticipants = totalParticipants,
        totalJudges = totalJudges,
        winnerSummary = winnerSummary,
        lockedAtMillis = lockedAtMillis,
        lockedBy = lockedBy
    )

    fun ActivityLogEntity.toDomain() = ActivityLogEntry(
        id = id,
        actor = actor,
        message = message,
        timestampMillis = timestampMillis,
        eventId = eventId,
        actionType = runCatching { AuditActionType.valueOf(actionType) }.getOrDefault(AuditActionType.SYSTEM),
        reason = reason
    )
}

object LkbbSeedData {
    const val DEFAULT_EVENT_ID = "lkbb-2026-main"
    const val ARCHIVED_2025_EVENT_ID = "lkbb-2025-garuda"

    val defaultConfig = CompetitionConfig(id = DEFAULT_EVENT_ID)

    fun defaultCategories(eventId: String): List<EventCategoryConfig> = CompetitionCategory.entries.mapIndexed { idx, cat ->
        EventCategoryConfig(
            id = "${eventId}_cat_${cat.name.lowercase()}",
            eventId = eventId,
            code = cat.name,
            displayName = cat.displayName,
            isEnabled = true,
            sortOrder = idx + 1
        )
    }

    val defaultJudges = listOf(
        JudgeAccount(1, "Mayor (Purn.) Hendra Wijaya", "PBB Dasar & Sikap", "juri1@lkbb.id", "1111", true, DEFAULT_EVENT_ID),
        JudgeAccount(2, "Kapten R. Pratama", "Variasi & Formasi", "juri2@lkbb.id", "2222", true, DEFAULT_EVENT_ID),
        JudgeAccount(3, "Siti Nurhaliza, S.Pd", "Komandan (Danton)", "juri3@lkbb.id", "3333", true, DEFAULT_EVENT_ID),
        JudgeAccount(4, "Budi Santoso, M.Or", "Kerapian & Kostum", "juri4@lkbb.id", "4444", true, DEFAULT_EVENT_ID),
        JudgeAccount(5, "Letda Arif Rahman", "Kekompakan & Arena", "juri5@lkbb.id", "5555", true, DEFAULT_EVENT_ID)
    )

    val defaultCriteria = listOf(
        ScoringCriterion("c_pbb_dasar", "PBB Dasar (Gerakan di Tempat & Berjalan)", "Ketangkasan", 100, 35, "Ketegasan sikap sempurna, langkah tegap, belok kanan/kiri, dan haluan.", true, 1, DEFAULT_EVENT_ID),
        ScoringCriterion("c_varfor", "Variasi & Formasi", "Kreativitas", 100, 25, "Kerumitan pola formasi, kekompakan transisi, dan dinamika visual.", true, 2, DEFAULT_EVENT_ID),
        ScoringCriterion("c_danton", "Komandan Pleton (Danton)", "Kepemimpinan", 100, 15, "Intonasi aba-aba, penguasaan lapangan, dan ketepatan laporan.", true, 3, DEFAULT_EVENT_ID),
        ScoringCriterion("c_kostum", "Kostum, Atribut & Kerapian", "Penampilan", 100, 10, "Keseragaman pakaian, kelengkapan atribut, dan kebersihan perlengkapan.", true, 4, DEFAULT_EVENT_ID),
        ScoringCriterion("c_kompak", "Kekompakan & Semangat Pasukan", "Kesatuan", 100, 10, "Keselarasan tempo langkah, ketenangan, dan daya tahan pasukan.", true, 5, DEFAULT_EVENT_ID),
        ScoringCriterion("c_devile", "Prosesi Masuk & Keluar Arena", "Protokoler", 100, 5, "Kerapian langkah saat masuk dan keluar arena perlombaan.", true, 6, DEFAULT_EVENT_ID)
    )

    val defaultPenaltyPresets: List<PenaltyPreset> = LkbbConstants.defaultPenaltyPresets.map {
        it.copy(eventId = DEFAULT_EVENT_ID)
    }

    val defaultTeams = listOf(
        Team("team_01", 1, "SMAN 1 Garuda Sakti", "Pleton Alpha", "SMA-01", CompetitionCategory.SMA, "Raka Pradipta", TeamPerformanceStatus.FINISHED, DEFAULT_EVENT_ID),
        Team("team_02", 2, "SMK Taruna Nusantara", "Pleton Patriot", "SMA-02", CompetitionCategory.SMA, "Dimas Anggara", TeamPerformanceStatus.FINISHED, DEFAULT_EVENT_ID),
        Team("team_03", 3, "MAN 2 Cendekia", "Pleton Elang", "SMA-03", CompetitionCategory.SMA, "Nadia Putri", TeamPerformanceStatus.FINISHED, DEFAULT_EVENT_ID),
        Team("team_04", 4, "SMPN 4 Satria Muda", "Regu Satria", "SMP-01", CompetitionCategory.SMP, "Bagus Setiawan", TeamPerformanceStatus.FINISHED, DEFAULT_EVENT_ID),
        Team("team_05", 5, "Purna Paskibra Rajawali", "Regu Rajawali", "UMM-01", CompetitionCategory.UMUM, "Fajar Kurniawan", TeamPerformanceStatus.FINISHED, DEFAULT_EVENT_ID),
        Team("team_06", 6, "SMAN 5 Bhayangkara", "Pleton Bhayangkara", "SMA-04", CompetitionCategory.SMA, "Gilang Ramadhan", TeamPerformanceStatus.PERFORMING, DEFAULT_EVENT_ID),
        Team("team_07", 7, "SMPN 1 Tunas Bangsa", "Regu Tunas", "SMP-02", CompetitionCategory.SMP, "Aulia Zahra", TeamPerformanceStatus.WAITING, DEFAULT_EVENT_ID),
        Team("team_08", 8, "Satuan Wira Karya", "Regu Wira", "UMM-02", CompetitionCategory.UMUM, "Hafiz Maulana", TeamPerformanceStatus.WAITING, DEFAULT_EVENT_ID)
    )

    fun buildInitialScoreSheets(): List<JudgeScoreSheet> {
        val now = System.currentTimeMillis()
        val sheets = mutableListOf<JudgeScoreSheet>()

        val teamBaseScores = mapOf(
            "team_01" to listOf(93, 91, 90, 92, 94),
            "team_02" to listOf(90, 89, 88, 91, 89),
            "team_03" to listOf(87, 86, 88, 85, 86),
            "team_04" to listOf(88, 85, 84, 87, 86),
            "team_05" to listOf(92, 94, 91, 90, 93)
        )

        teamBaseScores.forEach { (teamId, judgeBases) ->
            judgeBases.forEachIndexed { idx, base ->
                val judgeNo = idx + 1
                val scores = mapOf(
                    "c_pbb_dasar" to (base + (judgeNo % 3) - 1).coerceIn(60, 100),
                    "c_varfor" to (base - 1 + (judgeNo % 2)).coerceIn(60, 100),
                    "c_danton" to (base + 1 - (judgeNo % 3)).coerceIn(60, 100),
                    "c_kostum" to (base + 2).coerceIn(60, 100),
                    "c_kompak" to (base).coerceIn(60, 100),
                    "c_devile" to (base - 1).coerceIn(60, 100)
                )
                val penalty = if (teamId == "team_02" && judgeNo == 5) 5 else 0
                val penaltyNote = if (penalty > 0) "Menginjak/Melewati Garis Arena (-5)" else ""
                sheets += JudgeScoreSheet(
                    id = "${teamId}_j${judgeNo}",
                    teamId = teamId,
                    judgeNumber = judgeNo,
                    criterionScores = scores,
                    penaltyPoints = penalty,
                    penaltyNotes = penaltyNote,
                    evaluatorNotes = "Formasi rapi, tempo stabil.",
                    isLocked = true,
                    updatedAtMillis = now - ((6 - judgeNo) * 60_000L),
                    eventId = DEFAULT_EVENT_ID
                )
            }
        }

        sheets += JudgeScoreSheet(
            id = "team_06_j1",
            teamId = "team_06",
            judgeNumber = 1,
            criterionScores = mapOf(
                "c_pbb_dasar" to 89,
                "c_varfor" to 88,
                "c_danton" to 90,
                "c_kostum" to 91,
                "c_kompak" to 87,
                "c_devile" to 88
            ),
            penaltyPoints = 0,
            evaluatorNotes = "Penilaian sementara saat tampil.",
            isLocked = false,
            updatedAtMillis = now - 30_000L,
            eventId = DEFAULT_EVENT_ID
        )
        sheets += JudgeScoreSheet(
            id = "team_06_j2",
            teamId = "team_06",
            judgeNumber = 2,
            criterionScores = mapOf(
                "c_pbb_dasar" to 88,
                "c_varfor" to 92,
                "c_danton" to 87,
                "c_kostum" to 89,
                "c_kompak" to 90,
                "c_devile" to 88
            ),
            penaltyPoints = 0,
            evaluatorNotes = "Transisi formasi sangat baik.",
            isLocked = true,
            updatedAtMillis = now - 20_000L,
            eventId = DEFAULT_EVENT_ID
        )
        return sheets
    }

    // Historical archived event to showcase real multi-event isolation & archive detail right away
    val archived2025Config = CompetitionConfig(
        id = ARCHIVED_2025_EVENT_ID,
        name = "LKBB Garuda Jaya 2025",
        theme = "Satria Muda Disiplin & Tangguh",
        organizer = "PPI Kota Bandung & Dispora",
        location = "Stadion Siliwangi Arena",
        eventDate = "12 Oktober 2025",
        year = 2025,
        maxDurationMinutes = 10,
        rankingMode = RankingMode.FINAL,
        isRankingPublished = true,
        onlyCountLockedInFinal = true,
        isScoringLocked = true,
        status = EventStatus.FINISHED,
        isArchivedLocked = true,
        createdAtMillis = 1728691200000L
    )

    val archived2025Judges = defaultJudges.map {
        it.copy(eventId = ARCHIVED_2025_EVENT_ID)
    }

    val archived2025Criteria = defaultCriteria.map {
        it.copy(id = "${ARCHIVED_2025_EVENT_ID}_${it.id}", eventId = ARCHIVED_2025_EVENT_ID)
    }

    val archived2025Penalties = defaultPenaltyPresets.map {
        it.copy(id = "${ARCHIVED_2025_EVENT_ID}_${it.id}", eventId = ARCHIVED_2025_EVENT_ID)
    }

    val archived2025Teams = listOf(
        Team("${ARCHIVED_2025_EVENT_ID}_t1", 1, "SMAN 3 Bhayangkara", "Pleton Merah Putih", "SMA-25A", CompetitionCategory.SMA, "Andika Putra", TeamPerformanceStatus.FINISHED, ARCHIVED_2025_EVENT_ID),
        Team("${ARCHIVED_2025_EVENT_ID}_t2", 2, "SMK Bina Mandiri", "Pleton Cakra", "SMA-25B", CompetitionCategory.SMA, "Salsa Bila", TeamPerformanceStatus.FINISHED, ARCHIVED_2025_EVENT_ID),
        Team("${ARCHIVED_2025_EVENT_ID}_t3", 3, "SMPN 2 Kencana", "Regu Kencana", "SMP-25A", CompetitionCategory.SMP, "Iqbal Fauzi", TeamPerformanceStatus.FINISHED, ARCHIVED_2025_EVENT_ID)
    )

    fun buildArchived2025Sheets(): List<JudgeScoreSheet> {
        val ts = 1728748800000L
        val bases = mapOf(
            "${ARCHIVED_2025_EVENT_ID}_t1" to listOf(95, 93, 94, 92, 95),
            "${ARCHIVED_2025_EVENT_ID}_t2" to listOf(91, 90, 89, 92, 90),
            "${ARCHIVED_2025_EVENT_ID}_t3" to listOf(88, 87, 89, 88, 86)
        )
        val out = mutableListOf<JudgeScoreSheet>()
        bases.forEach { (teamId, scoresByJudge) ->
            scoresByJudge.forEachIndexed { idx, base ->
                val judgeNo = idx + 1
                val scores = archived2025Criteria.associate { crit ->
                    crit.id to (base - (judgeNo % 2)).coerceIn(70, 100)
                }
                out += JudgeScoreSheet(
                    id = "${teamId}_j${judgeNo}",
                    teamId = teamId,
                    judgeNumber = judgeNo,
                    criterionScores = scores,
                    penaltyPoints = if (teamId.endsWith("_t2") && judgeNo == 4) 5 else 0,
                    penaltyNotes = if (teamId.endsWith("_t2") && judgeNo == 4) "Atribut / Perlengkapan Jatuh (-5)" else "",
                    evaluatorNotes = "Rekap resmi arsip LKBB 2025.",
                    isLocked = true,
                    updatedAtMillis = ts + judgeNo * 30_000L,
                    eventId = ARCHIVED_2025_EVENT_ID
                )
            }
        }
        return out
    }

    fun buildArchived2025Snapshot(): ArchiveResultSnapshot {
        val summaryArr = JSONArray().apply {
            put(JSONObject().put("rank", 1).put("team", "SMAN 3 Bhayangkara").put("finalScore", 467.0))
            put(JSONObject().put("rank", 2).put("team", "SMK Bina Mandiri").put("finalScore", 445.0))
            put(JSONObject().put("rank", 3).put("team", "SMPN 2 Kencana").put("finalScore", 436.0))
        }
        return ArchiveResultSnapshot(
            eventId = ARCHIVED_2025_EVENT_ID,
            snapshotJson = JSONObject().put("eventId", ARCHIVED_2025_EVENT_ID).put("rankings", summaryArr).toString(),
            totalParticipants = 3,
            totalJudges = 5,
            winnerSummary = "#1 SMAN 3 Bhayangkara (467.00)",
            lockedAtMillis = 1728752400000L,
            lockedBy = "Admin Panitia 2025"
        )
    }
}
