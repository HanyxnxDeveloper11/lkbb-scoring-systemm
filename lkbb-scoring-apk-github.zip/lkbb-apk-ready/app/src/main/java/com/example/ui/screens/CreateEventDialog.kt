package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.LkbbSeedData
import com.example.data.model.CompetitionCategory
import com.example.data.model.CreateEventRequest
import com.example.data.model.EventArchiveSummary
import com.example.data.model.EventDetailBundle
import com.example.data.model.EventStatus
import com.example.data.model.JudgeAccount
import com.example.data.model.PenaltyPreset
import com.example.data.model.ScoringCriterion
import com.example.data.model.Team
import com.example.data.model.TeamPerformanceStatus
import com.example.ui.components.CompetitionLogoBadge
import com.example.ui.components.StatusPill
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CreateEventDialog(
    existingEvents: List<EventArchiveSummary>,
    onFetchSourceBundle: suspend (String) -> EventDetailBundle?,
    onPickLogoImage: (Uri, (String) -> Unit) -> Unit,
    onDismiss: () -> Unit,
    onSubmit: (CreateEventRequest) -> Unit
) {
    val scope = rememberCoroutineScope()

    var duplicateMode by remember { mutableStateOf(false) }
    var selectedSourceId by remember { mutableStateOf(existingEvents.firstOrNull()?.config?.id.orEmpty()) }
    var sourceMenuExpanded by remember { mutableStateOf(false) }
    var copyCategories by remember { mutableStateOf(true) }
    var copyCriteria by remember { mutableStateOf(true) }
    var copyPenalties by remember { mutableStateOf(true) }
    var copyJudges by remember { mutableStateOf(false) }

    var eventName by remember { mutableStateOf("") }
    var eventTheme by remember { mutableStateOf("Tegas, Disiplin, Berjiwa Satria") }
    var organizer by remember { mutableStateOf("Panitia Pelaksana Paskibra") }
    var location by remember { mutableStateOf("GOR Gelanggang Pemuda") }
    var eventDate by remember { mutableStateOf("20 Desember 2026") }
    var yearText by remember { mutableStateOf("2026") }
    var durationText by remember { mutableStateOf("10") }
    var logoUrl by remember { mutableStateOf("") }
    var initialStatus by remember { mutableStateOf(EventStatus.ACTIVE) }
    var activateImmediately by remember { mutableStateOf(true) }
    var enabledCategories by remember { mutableStateOf(CompetitionCategory.entries.toSet()) }

    val draftTeams = remember { mutableStateListOf<Team>() }
    var newTeamName by remember { mutableStateOf("") }
    var newTeamSquad by remember { mutableStateOf("") }
    var newTeamDanton by remember { mutableStateOf("") }
    var newTeamCategory by remember { mutableStateOf(CompetitionCategory.SMA) }

    val draftJudges = remember {
        mutableStateListOf<JudgeAccount>().apply {
            addAll(LkbbSeedData.defaultJudges.map { it.copy() })
        }
    }

    val draftCriteria = remember {
        mutableStateListOf<ScoringCriterion>().apply {
            addAll(LkbbSeedData.defaultCriteria.map { it.copy() })
        }
    }
    var newCritName by remember { mutableStateOf("") }
    var newCritWeight by remember { mutableStateOf("10") }

    val draftPenalties = remember {
        mutableStateListOf<PenaltyPreset>().apply {
            addAll(LkbbSeedData.defaultPenaltyPresets.map { it.copy() })
        }
    }
    var newPenLabel by remember { mutableStateOf("") }
    var newPenPoints by remember { mutableStateOf("5") }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickLogoImage(uri) { savedPath -> logoUrl = savedPath }
        }
    }

    fun applySourceDuplication(sourceId: String) {
        if (sourceId.isBlank()) return
        scope.launch {
            val bundle = onFetchSourceBundle(sourceId) ?: return@launch
            if (copyCategories) {
                val cats = bundle.categories
                    .filter { it.isEnabled }
                    .mapNotNull { runCatching { CompetitionCategory.valueOf(it.code) }.getOrNull() }
                    .toSet()
                if (cats.isNotEmpty()) enabledCategories = cats
            }
            if (copyCriteria && bundle.criteria.isNotEmpty()) {
                draftCriteria.clear()
                draftCriteria.addAll(bundle.criteria)
            }
            if (copyPenalties && bundle.penaltyPresets.isNotEmpty()) {
                draftPenalties.clear()
                draftPenalties.addAll(bundle.penaltyPresets)
            }
            if (copyJudges && bundle.judges.isNotEmpty()) {
                draftJudges.clear()
                draftJudges.addAll(bundle.judges)
            }
            // Guarantee: NEVER copy old teams or score sheets!
        }
    }

    LaunchedEffect(duplicateMode, selectedSourceId, copyCategories, copyCriteria, copyPenalties, copyJudges) {
        if (duplicateMode && selectedSourceId.isNotBlank()) {
            applySourceDuplication(selectedSourceId)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Buat Perlombaan Baru", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", tint = CrispWhite)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = NavyPrimary,
                        titleContentColor = CrispWhite
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Mode Pemilihan: Dari Awal vs Duplikasi
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Metode Pembuatan Event", style = MaterialTheme.typography.titleMedium)
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            SegmentedButton(
                                selected = !duplicateMode,
                                onClick = { duplicateMode = false },
                                shape = SegmentedButtonDefaults.itemShape(0, 2),
                                modifier = Modifier.testTag("create_event_mode_scratch")
                            ) {
                                Text("1. Dari Awal")
                            }
                            SegmentedButton(
                                selected = duplicateMode,
                                onClick = { duplicateMode = true },
                                enabled = existingEvents.isNotEmpty(),
                                shape = SegmentedButtonDefaults.itemShape(1, 2),
                                modifier = Modifier.testTag("create_event_mode_duplicate")
                            ) {
                                Text("2. Duplikasi")
                            }
                        }

                        if (duplicateMode && existingEvents.isNotEmpty()) {
                            val selectedSource = existingEvents.find { it.config.id == selectedSourceId }
                            ExposedDropdownMenuBox(
                                expanded = sourceMenuExpanded,
                                onExpandedChange = { sourceMenuExpanded = !sourceMenuExpanded }
                            ) {
                                OutlinedTextField(
                                    value = selectedSource?.config?.name ?: "Pilih event sumber",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Salin Pengaturan dari Event") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sourceMenuExpanded) },
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = sourceMenuExpanded,
                                    onDismissRequest = { sourceMenuExpanded = false }
                                ) {
                                    existingEvents.forEach { ev ->
                                        DropdownMenuItem(
                                            text = { Text("${ev.config.name} (${ev.config.year})") },
                                            onClick = {
                                                selectedSourceId = ev.config.id
                                                sourceMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "Pilih konfigurasi yang disalin (peserta & nilai lama tidak akan disalin):",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = copyCategories,
                                    onClick = { copyCategories = !copyCategories },
                                    label = { Text("Kategori") }
                                )
                                FilterChip(
                                    selected = copyCriteria,
                                    onClick = { copyCriteria = !copyCriteria },
                                    label = { Text("Aspek & Bobot") }
                                )
                                FilterChip(
                                    selected = copyPenalties,
                                    onClick = { copyPenalties = !copyPenalties },
                                    label = { Text("Penalti") }
                                )
                                FilterChip(
                                    selected = copyJudges,
                                    onClick = { copyJudges = !copyJudges },
                                    label = { Text("Susunan 5 Juri") }
                                )
                            }
                            StatusPill(
                                text = "Data peserta & nilai event lama dijamin tidak ikut tersalin",
                                containerColor = EmeraldSoft,
                                contentColor = EmeraldSuccess,
                                icon = Icons.Default.ContentCopy
                            )
                        }
                    }
                }

                // Identitas Event, Tema, Logo, Tanggal, Lokasi, Penyelenggara
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Identitas & Jadwal Perlombaan", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = eventName,
                            onValueChange = { eventName = it },
                            label = { Text("Nama Event Perlombaan *") },
                            placeholder = { Text("Contoh: LKBB Nusantara Cup 2027") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("create_event_name_input")
                        )
                        OutlinedTextField(
                            value = eventTheme,
                            onValueChange = { eventTheme = it },
                            label = { Text("Tema Perlombaan") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("create_event_theme_input")
                        )
                        OutlinedTextField(
                            value = organizer,
                            onValueChange = { organizer = it },
                            label = { Text("Nama Penyelenggara") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("create_event_organizer_input")
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = eventDate,
                                onValueChange = { eventDate = it },
                                label = { Text("Tanggal") },
                                singleLine = true,
                                modifier = Modifier.weight(1.4f).testTag("create_event_date_input")
                            )
                            OutlinedTextField(
                                value = yearText,
                                onValueChange = { yearText = it.filter { ch -> ch.isDigit() }.take(4) },
                                label = { Text("Tahun") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = location,
                                onValueChange = { location = it },
                                label = { Text("Lokasi Arena") },
                                singleLine = true,
                                modifier = Modifier.weight(1.5f).testTag("create_event_location_input")
                            )
                            OutlinedTextField(
                                value = durationText,
                                onValueChange = { durationText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Durasi (mnt)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.8f)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CompetitionLogoBadge(
                                logoUrl = logoUrl,
                                contentDescription = "Logo Event Baru",
                                modifier = Modifier.size(48.dp)
                            )
                            OutlinedButton(
                                onClick = {
                                    logoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Pilih Logo")
                            }
                            OutlinedTextField(
                                value = logoUrl,
                                onValueChange = { logoUrl = it },
                                label = { Text("URL Logo") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Text("Kategori Lomba Aktif", style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CompetitionCategory.entries.forEach { cat ->
                                val selected = cat in enabledCategories
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        val next = if (selected) enabledCategories - cat else enabledCategories + cat
                                        if (next.isNotEmpty()) enabledCategories = next
                                    },
                                    label = { Text(cat.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NavyPrimary,
                                        selectedLabelColor = CrispWhite
                                    )
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Aktifkan event ini setelah dibuat", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = activateImmediately, onCheckedChange = { activateImmediately = it })
                        }
                    }
                }

                // Data Peserta Awal (Baru, Tidak Pernah Menyalin Peserta Lama)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Data Peserta Awal (${draftTeams.size} pleton)", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newTeamName,
                                onValueChange = { newTeamName = it },
                                label = { Text("Nama Sekolah") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("create_event_team_name")
                            )
                            OutlinedTextField(
                                value = newTeamSquad,
                                onValueChange = { newTeamSquad = it },
                                label = { Text("Nama Regu") },
                                singleLine = true,
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newTeamDanton,
                                onValueChange = { newTeamDanton = it },
                                label = { Text("Nama Danton") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    if (newTeamName.isNotBlank()) {
                                        val nextNo = draftTeams.size + 1
                                        draftTeams += Team(
                                            id = "tmp_$nextNo",
                                            orderNumber = nextNo,
                                            name = newTeamName.trim(),
                                            squadName = newTeamSquad.trim(),
                                            contingentCode = "${newTeamCategory.name}-$nextNo",
                                            category = newTeamCategory,
                                            dantonName = newTeamDanton.trim().ifEmpty { "-" },
                                            status = TeamPerformanceStatus.WAITING
                                        )
                                        newTeamName = ""
                                        newTeamSquad = ""
                                        newTeamDanton = ""
                                    }
                                },
                                modifier = Modifier.testTag("create_event_add_team_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Tambah")
                            }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            enabledCategories.forEach { cat ->
                                FilterChip(
                                    selected = newTeamCategory == cat,
                                    onClick = { newTeamCategory = cat },
                                    label = { Text(cat.displayName) }
                                )
                            }
                        }
                        draftTeams.forEachIndexed { idx, team ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "#${team.orderNumber} ${team.name} (${team.category.displayName})",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = { draftTeams.removeAt(idx) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus", tint = CrimsonRed)
                                }
                            }
                        }
                    }
                }

                // 5 Akun Juri
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Lima Akun Juri Event Ini", style = MaterialTheme.typography.titleMedium)
                        draftJudges.forEachIndexed { idx, judge ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = judge.name,
                                    onValueChange = { draftJudges[idx] = judge.copy(name = it) },
                                    label = { Text("Juri ${judge.judgeNumber}") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1.3f)
                                )
                                OutlinedTextField(
                                    value = judge.pinCode,
                                    onValueChange = { draftJudges[idx] = judge.copy(pinCode = it.take(10)) },
                                    label = { Text("PIN") },
                                    singleLine = true,
                                    modifier = Modifier.weight(0.6f)
                                )
                            }
                        }
                    }
                }

                // Aspek, Bobot & Penalti
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val totalW = draftCriteria.sumOf { it.weightPercent }
                        Text("Aspek & Bobot Penilaian (Total: $totalW%)", style = MaterialTheme.typography.titleMedium)
                        draftCriteria.forEachIndexed { idx, crit ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${crit.name} (${crit.weightPercent}%)",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                if (draftCriteria.size > 1) {
                                    IconButton(onClick = { draftCriteria.removeAt(idx) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus aspek", tint = CrimsonRed)
                                    }
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = newCritName,
                                onValueChange = { newCritName = it },
                                label = { Text("Aspek Baru") },
                                singleLine = true,
                                modifier = Modifier.weight(1.3f)
                            )
                            OutlinedTextField(
                                value = newCritWeight,
                                onValueChange = { newCritWeight = it.filter { c -> c.isDigit() } },
                                label = { Text("Bobot %") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.6f)
                            )
                            OutlinedButton(onClick = {
                                if (newCritName.isNotBlank()) {
                                    draftCriteria += ScoringCriterion(
                                        id = "new_${draftCriteria.size + 1}",
                                        name = newCritName.trim(),
                                        categoryGroup = "Ketangkasan",
                                        maxScore = 100,
                                        weightPercent = (newCritWeight.toIntOrNull() ?: 10).coerceIn(1, 100),
                                        description = "Aspek penilaian lomba.",
                                        isActive = true,
                                        sortOrder = draftCriteria.size + 1
                                    )
                                    newCritName = ""
                                }
                            }) {
                                Text("+")
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Text("Pengaturan Penalti (${draftPenalties.size} aturan)", style = MaterialTheme.typography.titleMedium)
                        draftPenalties.forEachIndexed { idx, pen ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${pen.label} (-${pen.points})", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                IconButton(onClick = { draftPenalties.removeAt(idx) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus penalti", tint = CrimsonRed)
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = newPenLabel,
                                onValueChange = { newPenLabel = it },
                                label = { Text("Pelanggaran") },
                                singleLine = true,
                                modifier = Modifier.weight(1.3f)
                            )
                            OutlinedTextField(
                                value = newPenPoints,
                                onValueChange = { newPenPoints = it.filter { c -> c.isDigit() } },
                                label = { Text("Poin") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.6f)
                            )
                            OutlinedButton(onClick = {
                                if (newPenLabel.isNotBlank()) {
                                    draftPenalties += PenaltyPreset(
                                        id = "pen_${draftPenalties.size + 1}",
                                        label = newPenLabel.trim(),
                                        points = (newPenPoints.toIntOrNull() ?: 5).coerceIn(1, 100),
                                        isActive = true,
                                        sortOrder = draftPenalties.size + 1
                                    )
                                    newPenLabel = ""
                                }
                            }) {
                                Text("+")
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        onSubmit(
                            CreateEventRequest(
                                name = eventName.trim(),
                                theme = eventTheme.trim(),
                                logoUrl = logoUrl.trim(),
                                bannerUrl = "",
                                eventDate = eventDate.trim().ifEmpty { "2026" },
                                year = yearText.toIntOrNull() ?: 2026,
                                location = location.trim().ifEmpty { "Arena Utama" },
                                organizer = organizer.trim().ifEmpty { "Panitia LKBB" },
                                maxDurationMinutes = (durationText.toIntOrNull() ?: 10).coerceIn(3, 30),
                                status = initialStatus,
                                enabledCategories = enabledCategories,
                                teams = draftTeams.toList(),
                                judges = draftJudges.toList(),
                                criteria = draftCriteria.toList(),
                                penaltyPresets = draftPenalties.toList(),
                                sourceEventIdForDuplication = if (duplicateMode) selectedSourceId else null,
                                activateImmediately = activateImmediately
                            )
                        )
                    },
                    enabled = eventName.isNotBlank() && draftCriteria.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = CrispWhite),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("create_event_submit_button")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Simpan & Buat Perlombaan Baru", fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
