package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.CompetitionCategory
import com.example.data.model.CompetitionConfig
import com.example.data.model.JudgeAccount
import com.example.data.model.PenaltyPreset
import com.example.data.model.RankingMode
import com.example.data.model.ScoringCriterion
import com.example.data.model.Team
import com.example.data.remote.SupabaseSchema
import com.example.ui.LkbbUiState
import com.example.ui.components.CriterionEditorDialog
import com.example.ui.components.JudgeEditorDialog
import com.example.ui.components.PenaltyEditorDialog
import com.example.ui.components.TeamEditorDialog
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyPrimary

private enum class SettingsTab(val label: String, val icon: ImageVector) {
    GENERAL("Umum & Media", Icons.Default.Palette),
    JUDGES("5 Juri", Icons.Default.Gavel),
    PARTICIPANTS("Peserta & Regu", Icons.Default.Groups),
    CRITERIA("Aspek & Penalti", Icons.Default.Tune),
    RANKING_DB("Ranking & DB", Icons.Default.CloudSync)
}

@Composable
fun CompetitionSettingsScreen(
    uiState: LkbbUiState,
    onSaveConfig: (CompetitionConfig) -> Unit,
    onPickBrandImage: (Uri, Boolean) -> Unit,
    onUpdateRankingSettings: (RankingMode, Boolean, Boolean, Boolean) -> Unit,
    onSaveCriterion: (ScoringCriterion) -> Unit,
    onDeleteCriterion: (ScoringCriterion) -> Unit,
    onNormalizeWeights: () -> Unit,
    onSavePenalty: (PenaltyPreset) -> Unit,
    onDeletePenalty: (PenaltyPreset) -> Unit,
    onSaveJudge: (JudgeAccount) -> Unit,
    onSaveTeam: (String?, Int, String, String, String, CompetitionCategory, String) -> Unit,
    onDeleteTeam: (Team) -> Unit,
    onPushSupabase: () -> Unit,
    onPullSupabase: () -> Unit,
    onResetDemoData: () -> Unit
) {
    var activeTab by remember { mutableStateOf(SettingsTab.GENERAL) }
    val listState = rememberLazyListState()

    LaunchedEffect(activeTab) {
        listState.scrollToItem(0)
    }

    var showAddTeam by remember { mutableStateOf(false) }
    var editingTeam by remember { mutableStateOf<Team?>(null) }
    var showAddCriterion by remember { mutableStateOf(false) }
    var editingCriterion by remember { mutableStateOf<ScoringCriterion?>(null) }
    var showAddPenalty by remember { mutableStateOf(false) }
    var editingPenalty by remember { mutableStateOf<PenaltyPreset?>(null) }
    var editingJudge by remember { mutableStateOf<JudgeAccount?>(null) }
    var showSqlDialog by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onPickBrandImage(uri, true)
    }
    val bannerPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onPickBrandImage(uri, false)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(SettingsTab.entries) { tab ->
                    FilterChip(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        label = { Text(tab.label) },
                        leadingIcon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyPrimary,
                            selectedLabelColor = CrispWhite,
                            selectedLeadingIconColor = CrispWhite
                        ),
                        modifier = Modifier.testTag("settings_tab_${tab.name.lowercase()}")
                    )
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("settings_criteria_list"),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (uiState.isCurrentEventLockedForEditing) {
                    item(key = "archive_locked_notice") {
                        Text(
                            text = "PERHATIAN: Event ini berstatus SELESAI & terkunci permanen. Buka kunci di menu Arsip Perlombaan untuk perubahan besar.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonRed,
                            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth()
                        )
                    }
                }
                when (activeTab) {
                    SettingsTab.GENERAL -> {
                        item(key = "tab_general") {
                            Column(modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth()) {
                                GeneralAndBrandSettingsSection(
                                    config = uiState.competitionConfig,
                                    onSaveConfig = onSaveConfig,
                                    onPickLogo = {
                                        logoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    onPickBanner = {
                                        bannerPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                )
                            }
                        }
                    }

                    SettingsTab.JUDGES -> {
                        item(key = "tab_judges") {
                            Column(modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth()) {
                                FiveJudgesSettingsSection(
                                    judges = uiState.judges,
                                    onEditJudge = { editingJudge = it }
                                )
                            }
                        }
                    }

                    SettingsTab.PARTICIPANTS -> {
                        participantsSettingsItems(
                            teams = uiState.teams,
                            onAddTeam = { showAddTeam = true },
                            onEditTeam = { editingTeam = it },
                            onDeleteTeam = onDeleteTeam
                        )
                    }

                    SettingsTab.CRITERIA -> {
                        criteriaAndPenaltiesSettingsItems(
                            uiState = uiState,
                            onAddCriterion = { showAddCriterion = true },
                            onEditCriterion = { editingCriterion = it },
                            onDeleteCriterion = onDeleteCriterion,
                            onNormalizeWeights = onNormalizeWeights,
                            onAddPenalty = { showAddPenalty = true },
                            onEditPenalty = { editingPenalty = it },
                            onDeletePenalty = onDeletePenalty
                        )
                    }

                    SettingsTab.RANKING_DB -> {
                        rankingAndSupabaseSettingsItems(
                            uiState = uiState,
                            onUpdateRankingSettings = onUpdateRankingSettings,
                            onPushSupabase = onPushSupabase,
                            onPullSupabase = onPullSupabase,
                            onShowSql = { showSqlDialog = true },
                            onRequestReset = { showResetConfirm = true }
                        )
                    }
                }
                item(key = "bottom_spacer") { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    if (showAddTeam) {
        val nextNum = (uiState.teams.maxOfOrNull { it.orderNumber } ?: 0) + 1
        TeamEditorDialog(
            suggestedOrderNumber = nextNum,
            onDismiss = { showAddTeam = false },
            onConfirm = { order, name, squad, code, cat, danton ->
                onSaveTeam(null, order, name, squad, code, cat, danton)
                showAddTeam = false
            }
        )
    }

    editingTeam?.let { teamToEdit ->
        TeamEditorDialog(
            initialTeam = teamToEdit,
            suggestedOrderNumber = teamToEdit.orderNumber,
            onDismiss = { editingTeam = null },
            onConfirm = { order, name, squad, code, cat, danton ->
                onSaveTeam(teamToEdit.id, order, name, squad, code, cat, danton)
                editingTeam = null
            }
        )
    }

    if (showAddCriterion) {
        CriterionEditorDialog(
            nextSortOrder = (uiState.criteria.maxOfOrNull { it.sortOrder } ?: 0) + 1,
            onDismiss = { showAddCriterion = false },
            onConfirm = {
                onSaveCriterion(it)
                showAddCriterion = false
            }
        )
    }

    editingCriterion?.let { crit ->
        CriterionEditorDialog(
            initialCriterion = crit,
            nextSortOrder = crit.sortOrder,
            onDismiss = { editingCriterion = null },
            onConfirm = {
                onSaveCriterion(it)
                editingCriterion = null
            }
        )
    }

    if (showAddPenalty) {
        PenaltyEditorDialog(
            nextSortOrder = (uiState.penaltyPresets.maxOfOrNull { it.sortOrder } ?: 0) + 1,
            onDismiss = { showAddPenalty = false },
            onConfirm = {
                onSavePenalty(it)
                showAddPenalty = false
            }
        )
    }

    editingPenalty?.let { pen ->
        PenaltyEditorDialog(
            initialPenalty = pen,
            nextSortOrder = pen.sortOrder,
            onDismiss = { editingPenalty = null },
            onConfirm = {
                onSavePenalty(it)
                editingPenalty = null
            }
        )
    }

    editingJudge?.let { judge ->
        JudgeEditorDialog(
            judge = judge,
            onDismiss = { editingJudge = null },
            onConfirm = {
                onSaveJudge(it)
                editingJudge = null
            }
        )
    }

    if (showSqlDialog) {
        AlertDialog(
            onDismissRequest = { showSqlDialog = false },
            title = { Text("Skema Tabel Supabase PostgreSQL") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = SupabaseSchema.POSTGRES_DDL.trim(),
                        style = MonoTextStyles.BadgeCode
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showSqlDialog = false }) { Text("Tutup") }
            }
        )
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset Data Perlombaan?") },
            text = { Text("Semua skor, peserta, aspek, penalti, dan pengaturan akan dikembalikan ke template awal.") },
            confirmButton = {
                Button(
                    onClick = {
                        onResetDemoData()
                        showResetConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("Ya, Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text("Batal") }
            }
        )
    }
}
