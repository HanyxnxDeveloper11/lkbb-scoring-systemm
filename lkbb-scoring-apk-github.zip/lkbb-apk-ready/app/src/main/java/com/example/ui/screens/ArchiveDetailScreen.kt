package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.EventDetailBundle
import com.example.data.model.EventStatus
import com.example.data.model.UserRole
import com.example.ui.components.CompetitionLogoBadge
import com.example.ui.components.GoldRankBadge
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySoft
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class ArchiveDetailTab(val label: String) {
    RANKING("Ranking & Juara"),
    JUDGE_RECAP("Nilai 5 Juri & Penalti"),
    PARTICIPANTS("Peserta"),
    JUDGES_CRITERIA("Juri & Aspek"),
    AUDIT_LOGS("Riwayat & Audit")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ArchiveDetailScreen(
    bundle: EventDetailBundle?,
    userRole: UserRole,
    totalEventsCount: Int,
    onBack: () -> Unit,
    onFinalizeAndLock: (String) -> Unit,
    onReopenArchive: (String, String) -> Unit,
    onDeleteEvent: (String) -> Unit,
    onExportPdf: (String) -> Unit,
    onExportExcelCsv: (String) -> Unit,
    onExportBackupJson: (String) -> Unit,
    onActivateEvent: (String) -> Unit
) {
    BackHandler { onBack() }

    if (bundle == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    var activeTab by remember { mutableStateOf(ArchiveDetailTab.RANKING) }
    var showFinalizeConfirm by remember { mutableStateOf(false) }
    var showReopenDialog by remember { mutableStateOf(false) }
    var reopenReasonText by remember { mutableStateOf("") }
    var deleteStep by remember { mutableStateOf(0) } // 0=closed, 1=step1 warning, 2=step2 type HAPUS
    var deleteConfirmText by remember { mutableStateOf("") }

    val config = bundle.config
    val isAdmin = userRole == UserRole.ADMIN
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("archive_detail_list"),
        contentPadding = PaddingValues(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Info Card
        item {
            Card(
                modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.65f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("archive_detail_back_button")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = CrispWhite)
                        }
                        CompetitionLogoBadge(
                            logoUrl = config.logoUrl,
                            contentDescription = "Logo ${config.name}",
                            modifier = Modifier.size(52.dp)
                        )
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                StatusPill(
                                    text = config.status.badgeText,
                                    containerColor = GoldChampionship,
                                    contentColor = NavyDeep
                                )
                                if (config.isArchivedLocked) {
                                    StatusPill(
                                        text = "TERKUNCI PERMANEN",
                                        containerColor = CrimsonRed,
                                        contentColor = CrispWhite,
                                        icon = Icons.Default.Lock
                                    )
                                }
                                StatusPill(
                                    text = if (config.isRankingPublished) "Dipublikasikan" else "Pratinjau Admin",
                                    containerColor = CrispWhite.copy(alpha = 0.16f),
                                    contentColor = CrispWhite
                                )
                            }
                            Text(config.name, style = MaterialTheme.typography.titleLarge, color = CrispWhite)
                            if (config.theme.isNotBlank()) {
                                Text("Tema: ${config.theme}", style = MaterialTheme.typography.bodySmall, color = GoldChampionship)
                            }
                        }
                    }

                    Text(
                        text = "${config.location} • ${config.eventDate} • Penyelenggara: ${config.organizer}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CrispWhite.copy(alpha = 0.85f)
                    )
                    Text(
                        text = "ID Arsip: ${config.id} • Dibuat: ${dateFormatter.format(Date(config.createdAtMillis))} • ${bundle.teams.size} Peserta • ${bundle.judges.size} Juri",
                        style = MonoTextStyles.BadgeCode,
                        color = CrispWhite.copy(alpha = 0.72f)
                    )

                    bundle.snapshot?.let { snap ->
                        Surface(
                            color = GoldSoft,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = NavyDeep)
                                Text(
                                    text = "Snapshot Terkunci (${dateFormatter.format(Date(snap.lockedAtMillis))}): ${snap.winnerSummary}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NavyDeep,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (config.reopenReason.isNotBlank()) {
                        Surface(
                            color = AmberSoft,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Catatan Pembukaan Arsip Terakhir: \"${config.reopenReason}\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = AmberWarning,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }

        // Export & Protection Controls
        item {
            Card(
                modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Ekspor Laporan, Backup & Penguncian Arsip", style = MaterialTheme.typography.titleMedium)

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onExportPdf(config.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = CrispWhite),
                            modifier = Modifier.testTag("archive_export_pdf_button")
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("PDF Resmi")
                        }
                        Button(
                            onClick = { onExportExcelCsv(config.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = CrispWhite),
                            modifier = Modifier.testTag("archive_export_csv_button")
                        ) {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Excel (CSV)")
                        }
                        OutlinedButton(
                            onClick = { onExportBackupJson(config.id) },
                            modifier = Modifier.testTag("archive_export_json_button")
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Backup JSON")
                        }
                    }

                    if (isAdmin) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!config.isArchivedLocked && config.status != EventStatus.FINISHED) {
                                Button(
                                    onClick = { showFinalizeConfirm = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = CrispWhite),
                                    modifier = Modifier.testTag("archive_finalize_lock_button")
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Selesaikan & Kunci Arsip")
                                }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        reopenReasonText = ""
                                        showReopenDialog = true
                                    },
                                    border = BorderStroke(1.dp, AmberWarning),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberWarning),
                                    modifier = Modifier.testTag("archive_reopen_button")
                                ) {
                                    Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Buka Kunci Arsip (Admin)")
                                }
                            }

                            OutlinedButton(onClick = { onActivateEvent(config.id) }) {
                                Text("Muat ke Workspace")
                            }

                            if (totalEventsCount > 1) {
                                OutlinedButton(
                                    onClick = { deleteStep = 1 },
                                    border = BorderStroke(1.dp, CrimsonRed),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonRed),
                                    modifier = Modifier.testTag("archive_delete_button")
                                ) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Hapus Event")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Detail Navigation Tabs
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth()
            ) {
                items(ArchiveDetailTab.entries) { tab ->
                    FilterChip(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        label = { Text(tab.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyPrimary,
                            selectedLabelColor = CrispWhite
                        ),
                        modifier = Modifier.testTag("archive_detail_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }

        when (activeTab) {
            ArchiveDetailTab.RANKING -> {
                if (bundle.rankings.isEmpty()) {
                    item { EmptyArchiveNotice("Belum ada peserta maupun peringkat pada event ini.") }
                } else {
                    items(bundle.rankings, key = { "rank_${it.team.id}" }) { r ->
                        Card(
                            modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, if (r.rank <= 3) GoldChampionship else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                GoldRankBadge(rank = r.rank)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(r.team.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    val squad = if (r.team.squadName.isNotBlank()) "${r.team.squadName} • " else ""
                                    Text(
                                        text = "No.${r.team.orderNumber} • $squad${r.team.category.displayName} • ${r.predicate}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = String.format(Locale.US, "%.2f", r.finalScore),
                                        style = MonoTextStyles.CardScore,
                                        color = NavyPrimary
                                    )
                                    Text(
                                        text = if (r.totalPenalty > 0) "Penalti -${r.totalPenalty}" else "Tanpa Penalti",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (r.totalPenalty > 0) CrimsonRed else EmeraldSuccess
                                    )
                                }
                            }
                        }
                    }
                }
            }

            ArchiveDetailTab.JUDGE_RECAP -> {
                if (bundle.rankings.isEmpty()) {
                    item { EmptyArchiveNotice("Belum ada rekapitulasi nilai juri.") }
                } else {
                    items(bundle.rankings, key = { "recap_${it.team.id}" }) { r ->
                        val teamSheets = bundle.scoreSheets.filter { it.teamId == r.team.id }
                        Card(
                            modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("#${r.team.orderNumber} ${r.team.name}", style = MaterialTheme.typography.titleMedium)
                                    Text("Akhir: ${String.format(Locale.US, "%.2f", r.finalScore)}", style = MonoTextStyles.TableCell, fontWeight = FontWeight.Bold, color = NavyPrimary)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    (1..5).forEach { j ->
                                        val valScore = r.judgeWeightedTotals[j]
                                        Surface(
                                            color = if (r.judgeLockedStates[j] == true) EmeraldSoft else NavySoft,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text("J$j", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                                Text(
                                                    text = valScore?.let { String.format(Locale.US, "%.1f", it) } ?: "—",
                                                    style = MonoTextStyles.TableCell
                                                )
                                            }
                                        }
                                    }
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Skor Kotor: ${String.format(Locale.US, "%.2f", r.grossScore)}", style = MaterialTheme.typography.bodySmall)
                                    Text("Total Penalti: -${r.totalPenalty}", style = MaterialTheme.typography.bodySmall, color = CrimsonRed, fontWeight = FontWeight.SemiBold)
                                }
                                val notes = teamSheets.mapNotNull { s -> s.penaltyNotes.takeIf { it.isNotBlank() }?.let { "J${s.judgeNumber}: $it" } }
                                if (notes.isNotEmpty()) {
                                    Text("Catatan Penalti: ${notes.joinToString(" | ")}", style = MaterialTheme.typography.bodySmall, color = CrimsonRed)
                                }
                            }
                        }
                    }
                }
            }

            ArchiveDetailTab.PARTICIPANTS -> {
                if (bundle.teams.isEmpty()) {
                    item { EmptyArchiveNotice("Tidak ada peserta terdaftar.") }
                } else {
                    items(bundle.teams, key = { "part_${it.id}" }) { t ->
                        Card(
                            modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("#${t.orderNumber} ${t.name}", style = MaterialTheme.typography.titleMedium)
                                    val sq = if (t.squadName.isNotBlank()) "Regu: ${t.squadName} • " else ""
                                    Text("$sq${t.category.displayName} • Danton: ${t.dantonName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusPill(text = t.status.label, containerColor = NavySoft, contentColor = NavyPrimary)
                            }
                        }
                    }
                }
            }

            ArchiveDetailTab.JUDGES_CRITERIA -> {
                item {
                    Card(
                        modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Daftar Lima Juri", style = MaterialTheme.typography.titleMedium)
                            bundle.judges.forEach { j ->
                                Text("Juri ${j.judgeNumber}: ${j.name} (${j.specialty})", style = MaterialTheme.typography.bodySmall)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Text("Aspek & Bobot Penilaian", style = MaterialTheme.typography.titleMedium)
                            bundle.criteria.forEach { c ->
                                Text("• ${c.name} — Bobot ${c.weightPercent}% (Maks ${c.maxScore})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            ArchiveDetailTab.AUDIT_LOGS -> {
                if (bundle.auditLogs.isEmpty()) {
                    item { EmptyArchiveNotice("Belum ada catatan audit log pada event ini.") }
                } else {
                    items(bundle.auditLogs, key = { it.id }) { log ->
                        Card(
                            modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    StatusPill(text = log.actionType.label, containerColor = NavySoft, contentColor = NavyPrimary)
                                    Text(dateFormatter.format(Date(log.timestampMillis)), style = MonoTextStyles.BadgeCode, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("${log.actor}: ${log.message}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                if (log.reason.isNotBlank()) {
                                    Text("Alasan Resmi: \"${log.reason}\"", style = MaterialTheme.typography.bodySmall, color = CrimsonRed, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(60.dp)) }
    }

    // Finalize & Lock Confirmation
    if (showFinalizeConfirm) {
        AlertDialog(
            onDismissRequest = { showFinalizeConfirm = false },
            title = { Text("Selesaikan & Kunci Arsip?") },
            text = {
                Text("Status perlombaan akan diubah menjadi SELESAI, snapshot peringkat akhir disimpan permanen, dan seluruh nilai tidak dapat diedit oleh juri.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onFinalizeAndLock(config.id)
                        showFinalizeConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    modifier = Modifier.testTag("confirm_finalize_lock_button")
                ) {
                    Text("Ya, Selesaikan & Kunci")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFinalizeConfirm = false }) { Text("Batal") }
            }
        )
    }

    // Admin Reopen Dialog requiring mandatory reason
    if (showReopenDialog) {
        AlertDialog(
            onDismissRequest = { showReopenDialog = false },
            title = { Text("Buka Kembali Arsip Terkunci") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Hanya Admin yang diizinkan membuka kembali arsip. Alasan resmi wajib diisi dan akan dicatat permanen dalam Audit Log.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = reopenReasonText,
                        onValueChange = { reopenReasonText = it },
                        label = { Text("Alasan Pembukaan Arsip *") },
                        placeholder = { Text("Contoh: Koreksi salah input penalti Juri 4") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("reopen_reason_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReopenArchive(config.id, reopenReasonText)
                        showReopenDialog = false
                    },
                    enabled = reopenReasonText.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                    modifier = Modifier.testTag("confirm_reopen_button")
                ) {
                    Text("Buka Arsip & Catat Log")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReopenDialog = false }) { Text("Batal") }
            }
        )
    }

    // Two-layer Delete Confirmation
    if (deleteStep == 1) {
        AlertDialog(
            onDismissRequest = { deleteStep = 0 },
            title = { Text("Peringatan Hapus Permanen (Langkah 1/2)") },
            text = {
                Text("Anda akan menghapus event '${config.name}' beserta seluruh data peserta, nilai 5 juri, snapshot hasil, dan audit log.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        deleteConfirmText = ""
                        deleteStep = 2
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("Lanjut Konfirmasi")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteStep = 0 }) { Text("Batal") }
            }
        )
    }

    if (deleteStep == 2) {
        AlertDialog(
            onDismissRequest = { deleteStep = 0 },
            title = { Text("Konfirmasi Akhir (Langkah 2/2)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Ketik kata HAPUS untuk mengonfirmasi penghapusan permanen '${config.name}'.")
                    OutlinedTextField(
                        value = deleteConfirmText,
                        onValueChange = { deleteConfirmText = it },
                        label = { Text("Ketik HAPUS") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("delete_confirm_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteEvent(config.id)
                        deleteStep = 0
                    },
                    enabled = deleteConfirmText.trim().equals("HAPUS", ignoreCase = true),
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    modifier = Modifier.testTag("confirm_final_delete_button")
                ) {
                    Text("Hapus Permanen")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteStep = 0 }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun EmptyArchiveNotice(text: String) {
    Card(
        modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(24.dp)
        )
    }
}
