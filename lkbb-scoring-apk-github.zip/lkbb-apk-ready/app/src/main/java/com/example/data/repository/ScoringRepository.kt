package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.ActivityLogEntity
import com.example.data.local.AppStateEntity
import com.example.data.local.LkbbDao
import com.example.data.local.LkbbDatabase
import com.example.data.local.LkbbEntityMapper.toDomain
import com.example.data.local.LkbbEntityMapper.toEntity
import com.example.data.local.LkbbSeedData
import com.example.data.model.ActivityLogEntry
import com.example.data.model.ArchiveResultSnapshot
import com.example.data.model.AuditActionType
import com.example.data.model.AuthSession
import com.example.data.model.CompetitionCategory
import com.example.data.model.CompetitionConfig
import com.example.data.model.CreateEventRequest
import com.example.data.model.EventArchiveSummary
import com.example.data.model.EventCategoryConfig
import com.example.data.model.EventDetailBundle
import com.example.data.model.EventStatus
import com.example.data.model.GlobalArchiveStats
import com.example.data.model.JudgeAccount
import com.example.data.model.JudgeScoreSheet
import com.example.data.model.PenaltyPreset
import com.example.data.model.RankingMode
import com.example.data.model.ScoringCriterion
import com.example.data.model.Team
import com.example.data.model.TeamPerformanceStatus
import com.example.data.model.TeamRankingSummary
import com.example.data.model.UserRole
import com.example.data.remote.SupabaseArchiveResultDto
import com.example.data.remote.SupabaseAuditLogDto
import com.example.data.remote.SupabaseAuthRequest
import com.example.data.remote.SupabaseCategoryDto
import com.example.data.remote.SupabaseClientFactory
import com.example.data.remote.SupabaseCompetitionDto
import com.example.data.remote.SupabaseConfig
import com.example.data.remote.SupabaseCriterionDto
import com.example.data.remote.SupabaseJudgeAccountDto
import com.example.data.remote.SupabasePenaltyPresetDto
import com.example.data.remote.SupabaseScoreSheetDto
import com.example.data.remote.SupabaseTeamDto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

sealed class AuthResult {
    data class Success(val session: AuthSession) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

sealed class SyncResult {
    data class Success(val summary: String) : SyncResult()
    data class LocalOnly(val message: String) : SyncResult()
    data class Failure(val error: String) : SyncResult()
}

@OptIn(ExperimentalCoroutinesApi::class)
class LkbbScoringRepository(
    private val db: LkbbDatabase?,
    private val dao: LkbbDao
) {
    private val backgroundSyncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    constructor(dao: LkbbDao) : this(null, dao)
    constructor(db: LkbbDatabase) : this(db, db.lkbbDao())

    private var supabaseAccessToken: String? = null

    private suspend fun <T> runInTransaction(block: suspend () -> T): T {
        return if (db != null) db.withTransaction { block() } else block()
    }

    val activeEventId: Flow<String> = dao.observeActiveEventId().map {
        it?.takeIf { id -> id.isNotBlank() } ?: LkbbSeedData.DEFAULT_EVENT_ID
    }

    val competitionConfig: Flow<CompetitionConfig> = activeEventId.flatMapLatest { eventId ->
        dao.observeCompetitionById(eventId).map { it?.toDomain() ?: LkbbSeedData.defaultConfig }
    }

    val categories: Flow<List<EventCategoryConfig>> = activeEventId.flatMapLatest { eventId ->
        dao.observeCategoriesByEvent(eventId).map { list -> list.map { it.toDomain() } }
    }

    val judges: Flow<List<JudgeAccount>> = activeEventId.flatMapLatest { eventId ->
        dao.observeJudgesByEvent(eventId).map { list -> list.map { it.toDomain() } }
    }

    val criteria: Flow<List<ScoringCriterion>> = activeEventId.flatMapLatest { eventId ->
        dao.observeCriteriaByEvent(eventId).map { list -> list.map { it.toDomain() } }
    }

    val penaltyPresets: Flow<List<PenaltyPreset>> = activeEventId.flatMapLatest { eventId ->
        dao.observePenaltyPresetsByEvent(eventId).map { list -> list.map { it.toDomain() } }
    }

    val teams: Flow<List<Team>> = activeEventId.flatMapLatest { eventId ->
        dao.observeTeamsByEvent(eventId).map { list -> list.map { it.toDomain() } }
    }

    val scoreSheets: Flow<List<JudgeScoreSheet>> = activeEventId.flatMapLatest { eventId ->
        dao.observeScoreSheetsByEvent(eventId).map { list -> list.map { it.toDomain() } }
    }

    val activityLogs: Flow<List<ActivityLogEntry>> = activeEventId.flatMapLatest { eventId ->
        dao.observeActivityLogsByEvent(eventId).map { list -> list.map { it.toDomain() } }
    }

    val archiveSummaries: Flow<List<EventArchiveSummary>> = combine(
        dao.observeAllCompetitions(),
        dao.observeAllTeams(),
        dao.observeAllJudges(),
        dao.observeAllScoreSheets(),
        dao.observeAllArchiveSnapshots()
    ) { competitions, allTeams, allJudges, allSheets, allSnapshots ->
        val teamsByEvent = allTeams.groupBy { it.eventId }
        val judgesByEvent = allJudges.groupBy { it.eventId }
        val sheetsByEvent = allSheets.groupBy { it.eventId }
        val snapshotByEvent = allSnapshots.associateBy { it.eventId }

        competitions.map { comp ->
            val domain = comp.toDomain()
            val eventTeams = teamsByEvent[comp.id].orEmpty()
            val eventJudges = judgesByEvent[comp.id].orEmpty()
            val eventSheets = sheetsByEvent[comp.id].orEmpty()
            EventArchiveSummary(
                config = domain,
                teamCount = eventTeams.size,
                judgeCount = eventJudges.count { it.isActive }.takeIf { it > 0 } ?: eventJudges.size,
                lockedSheetCount = eventSheets.count { it.isLocked },
                snapshot = snapshotByEvent[comp.id]?.toDomain()
            )
        }
    }

    val globalArchiveStats: Flow<GlobalArchiveStats> = archiveSummaries.map { list ->
        GlobalArchiveStats(
            totalEvents = list.size,
            activeEvents = list.count { it.config.status == EventStatus.ACTIVE },
            finishedEvents = list.count { it.config.status == EventStatus.FINISHED },
            draftEvents = list.count { it.config.status == EventStatus.DRAFT },
            totalParticipantsAllEvents = list.sumOf { it.teamCount },
            totalJudgesAllEvents = list.sumOf { it.judgeCount }
        )
    }

    private suspend fun resolveActiveEventId(): String {
        val stored = dao.getActiveEventIdOnce()
        if (!stored.isNullOrBlank() && dao.getCompetitionByIdOnce(stored) != null) {
            return stored
        }
        val firstComp = dao.getAllCompetitionsOnce().firstOrNull()?.id ?: LkbbSeedData.DEFAULT_EVENT_ID
        dao.upsertAppState(AppStateEntity("active_event_id", firstComp))
        return firstComp
    }

    suspend fun ensureSeeded() {
        runInTransaction {
            val existingCompetitions = dao.getAllCompetitionsOnce()
            if (existingCompetitions.isEmpty()) {
                val mainId = LkbbSeedData.DEFAULT_EVENT_ID
                dao.upsertCompetitionConfig(LkbbSeedData.defaultConfig.toEntity())
                dao.upsertAppState(AppStateEntity("active_event_id", mainId))
                dao.upsertCategories(LkbbSeedData.defaultCategories(mainId).map { it.toEntity() })
                dao.upsertJudges(LkbbSeedData.defaultJudges.map { it.toEntity(mainId) })
                dao.upsertCriteria(LkbbSeedData.defaultCriteria.map { it.toEntity(mainId) })
                dao.upsertPenaltyPresets(LkbbSeedData.defaultPenaltyPresets.map { it.toEntity(mainId) })
                dao.upsertTeams(LkbbSeedData.defaultTeams.map { it.toEntity(mainId) })
                dao.upsertScoreSheets(LkbbSeedData.buildInitialScoreSheets().map { it.toEntity(mainId) })
                logActivity(
                    eventId = mainId,
                    actor = "Sistem",
                    actionType = AuditActionType.SYSTEM,
                    message = "Event aktif LKBB Nusantara Cup 2026 & 5 Juri siap digunakan."
                )

                // Seed 1 historical archived competition for immediate multi-event archive demonstration
                val archId = LkbbSeedData.ARCHIVED_2025_EVENT_ID
                dao.upsertCompetitionConfig(LkbbSeedData.archived2025Config.toEntity())
                dao.upsertCategories(LkbbSeedData.defaultCategories(archId).map { it.toEntity() })
                dao.upsertJudges(LkbbSeedData.archived2025Judges.map { it.toEntity(archId) })
                dao.upsertCriteria(LkbbSeedData.archived2025Criteria.map { it.toEntity(archId) })
                dao.upsertPenaltyPresets(LkbbSeedData.archived2025Penalties.map { it.toEntity(archId) })
                dao.upsertTeams(LkbbSeedData.archived2025Teams.map { it.toEntity(archId) })
                dao.upsertScoreSheets(LkbbSeedData.buildArchived2025Sheets().map { it.toEntity(archId) })
                dao.upsertArchiveSnapshot(LkbbSeedData.buildArchived2025Snapshot().toEntity())
                logActivity(
                    eventId = archId,
                    actor = "Admin Panitia 2025",
                    actionType = AuditActionType.EVENT_LOCK,
                    message = "Arsip final LKBB Garuda Jaya 2025 dikunci permanen.",
                    timestampOverride = 1728752400000L
                )
            } else {
                val activeId = resolveActiveEventId()
                if (dao.getCategoriesByEventOnce(activeId).isEmpty()) {
                    dao.upsertCategories(LkbbSeedData.defaultCategories(activeId).map { it.toEntity() })
                }
                if (dao.getJudgesByEventOnce(activeId).isEmpty()) {
                    dao.upsertJudges(LkbbSeedData.defaultJudges.map { it.toEntity(activeId) })
                }
                if (dao.getCriteriaByEventOnce(activeId).isEmpty()) {
                    dao.upsertCriteria(LkbbSeedData.defaultCriteria.map { it.toEntity(activeId) })
                }
                if (dao.getPenaltyPresetsByEventOnce(activeId).isEmpty()) {
                    dao.upsertPenaltyPresets(LkbbSeedData.defaultPenaltyPresets.map { it.toEntity(activeId) })
                }
                if (dao.getTeamsByEventOnce(activeId).isEmpty()) {
                    dao.upsertTeams(LkbbSeedData.defaultTeams.map { it.toEntity(activeId) })
                }
            }
        }
    }

    suspend fun resetDemoData() {
        val activeId = resolveActiveEventId()
        runInTransaction {
            val current = dao.getCompetitionByIdOnce(activeId)?.toDomain()
            dao.clearScoreSheetsForEvent(activeId)
            dao.clearTeamsForEvent(activeId)
            dao.clearCriteriaForEvent(activeId)
            dao.clearPenaltyPresetsForEvent(activeId)
            dao.clearJudgesForEvent(activeId)
            dao.clearCategoriesForEvent(activeId)
            dao.clearLogsForEvent(activeId)

            val resetConfig = (current ?: LkbbSeedData.defaultConfig).copy(
                id = activeId,
                status = EventStatus.ACTIVE,
                isArchivedLocked = false,
                isScoringLocked = false,
                rankingMode = RankingMode.LIVE,
                isRankingPublished = true
            )
            dao.upsertCompetitionConfig(resetConfig.toEntity())
            dao.upsertCategories(LkbbSeedData.defaultCategories(activeId).map { it.toEntity() })
            dao.upsertJudges(LkbbSeedData.defaultJudges.map { it.toEntity(activeId) })
            dao.upsertCriteria(LkbbSeedData.defaultCriteria.map { it.copy(id = "${activeId}_${it.id}", eventId = activeId).toEntity(activeId) })
            dao.upsertPenaltyPresets(LkbbSeedData.defaultPenaltyPresets.map { it.copy(id = "${activeId}_${it.id}", eventId = activeId).toEntity(activeId) })
            if (activeId == LkbbSeedData.DEFAULT_EVENT_ID) {
                dao.upsertCriteria(LkbbSeedData.defaultCriteria.map { it.toEntity(activeId) })
                dao.upsertPenaltyPresets(LkbbSeedData.defaultPenaltyPresets.map { it.toEntity(activeId) })
                dao.upsertTeams(LkbbSeedData.defaultTeams.map { it.toEntity(activeId) })
                dao.upsertScoreSheets(LkbbSeedData.buildInitialScoreSheets().map { it.toEntity(activeId) })
            }
            logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Data event '${resetConfig.name}' direset ke template awal (event lain tetap aman).")
        }
        pushIfConfigured()
    }

    suspend fun setActiveEvent(eventId: String, actor: String = "Admin"): Boolean {
        val target = dao.getCompetitionByIdOnce(eventId) ?: return false
        runInTransaction {
            dao.upsertAppState(AppStateEntity("active_event_id", eventId))
            logActivity(eventId, actor, AuditActionType.SYSTEM, "Event '${target.name}' dibuka sebagai event aktif.")
        }
        return true
    }

    suspend fun createNewEvent(request: CreateEventRequest, actor: String = "Admin"): String {
        val uniqueSuffix = UUID.randomUUID().toString().replace("-", "").take(6)
        val newEventId = "evt_${System.currentTimeMillis()}_$uniqueSuffix"
        val now = System.currentTimeMillis()

        runInTransaction {
            val newConfig = CompetitionConfig(
                id = newEventId,
                name = request.name.trim(),
                theme = request.theme.trim(),
                organizer = request.organizer.trim(),
                location = request.location.trim(),
                eventDate = request.eventDate.trim(),
                year = request.year,
                maxDurationMinutes = request.maxDurationMinutes.coerceIn(3, 30),
                logoUrl = request.logoUrl.trim(),
                bannerUrl = request.bannerUrl.trim(),
                rankingMode = RankingMode.LIVE,
                isRankingPublished = true,
                onlyCountLockedInFinal = true,
                isScoringLocked = false,
                status = request.status,
                isArchivedLocked = false,
                createdAtMillis = now
            )
            dao.upsertCompetitionConfig(newConfig.toEntity())

            val categories = CompetitionCategory.entries.mapIndexed { idx, cat ->
                EventCategoryConfig(
                    id = "${newEventId}_cat_${cat.name.lowercase()}",
                    eventId = newEventId,
                    code = cat.name,
                    displayName = cat.displayName,
                    isEnabled = cat in request.enabledCategories,
                    sortOrder = idx + 1
                )
            }
            dao.upsertCategories(categories.map { it.toEntity() })

            val judges = (1..5).map { num ->
                val provided = request.judges.find { it.judgeNumber == num }
                JudgeAccount(
                    judgeNumber = num,
                    name = provided?.name?.trim()?.ifEmpty { "Juri $num" } ?: "Juri $num",
                    specialty = provided?.specialty?.trim()?.ifEmpty { "Penilaian PBB" } ?: "Penilaian PBB",
                    email = provided?.email?.trim()?.ifEmpty { "juri$num@lkbb.id" } ?: "juri$num@lkbb.id",
                    pinCode = provided?.pinCode?.trim()?.ifEmpty { "$num".repeat(4) } ?: "$num".repeat(4),
                    isActive = provided?.isActive ?: true,
                    eventId = newEventId
                )
            }
            dao.upsertJudges(judges.map { it.toEntity(newEventId) })

            val criteria = request.criteria.mapIndexed { idx, crit ->
                crit.copy(
                    id = "${newEventId}_crit_${idx + 1}_${UUID.randomUUID().toString().take(4)}",
                    eventId = newEventId,
                    sortOrder = idx + 1
                )
            }
            dao.upsertCriteria(criteria.map { it.toEntity(newEventId) })

            val penalties = request.penaltyPresets.mapIndexed { idx, pen ->
                pen.copy(
                    id = "${newEventId}_pen_${idx + 1}_${UUID.randomUUID().toString().take(4)}",
                    eventId = newEventId,
                    sortOrder = idx + 1
                )
            }
            dao.upsertPenaltyPresets(penalties.map { it.toEntity(newEventId) })

            // Never copy old teams or old scores from source event! Only insert freshly added teams from wizard.
            val freshTeams = request.teams.mapIndexed { idx, t ->
                t.copy(
                    id = "${newEventId}_team_${idx + 1}_${UUID.randomUUID().toString().take(4)}",
                    eventId = newEventId,
                    orderNumber = if (t.orderNumber > 0) t.orderNumber else idx + 1,
                    status = TeamPerformanceStatus.WAITING
                )
            }
            if (freshTeams.isNotEmpty()) {
                dao.upsertTeams(freshTeams.map { it.toEntity(newEventId) })
            }

            val sourceNote = request.sourceEventIdForDuplication?.let {
                " (duplikasi konfigurasi dari event $it; data peserta & nilai lama tidak disalin)"
            } ?: " (dibuat dari awal)"

            logActivity(
                eventId = newEventId,
                actor = actor,
                actionType = AuditActionType.EVENT_CREATE,
                message = "Perlombaan baru '${newConfig.name}' dibuat$sourceNote."
            )

            if (request.activateImmediately) {
                dao.upsertAppState(AppStateEntity("active_event_id", newEventId))
            }
        }

        pushEventInBackground(newEventId)
        return newEventId
    }

    suspend fun getEventDetailBundle(eventId: String): EventDetailBundle? {
        val comp = dao.getCompetitionByIdOnce(eventId)?.toDomain() ?: return null
        val categories = dao.getCategoriesByEventOnce(eventId).map { it.toDomain() }
        val judges = dao.getJudgesByEventOnce(eventId).map { it.toDomain() }
        val criteria = dao.getCriteriaByEventOnce(eventId).map { it.toDomain() }
        val penalties = dao.getPenaltyPresetsByEventOnce(eventId).map { it.toDomain() }
        val teams = dao.getTeamsByEventOnce(eventId).map { it.toDomain() }
        val sheets = dao.getScoreSheetsByEventOnce(eventId).map { it.toDomain() }
        val snapshot = dao.getArchiveSnapshotOnce(eventId)?.toDomain()
        val logs = dao.getActivityLogsByEventOnce(eventId).map { it.toDomain() }
        val rankings = computeRankings(
            teams = teams,
            criteria = criteria,
            scoreSheets = sheets,
            rankingMode = comp.rankingMode,
            onlyCountLockedInFinal = comp.onlyCountLockedInFinal
        )
        return EventDetailBundle(
            config = comp,
            categories = categories,
            judges = judges,
            criteria = criteria,
            penaltyPresets = penalties,
            teams = teams,
            scoreSheets = sheets,
            rankings = rankings,
            snapshot = snapshot,
            auditLogs = logs
        )
    }

    suspend fun finalizeAndLockEvent(eventId: String, actor: String): Boolean {
        val compEntity = dao.getCompetitionByIdOnce(eventId) ?: return false
        runInTransaction {
            val comp = compEntity.toDomain()
            val teams = dao.getTeamsByEventOnce(eventId).map { it.toDomain() }
            val criteria = dao.getCriteriaByEventOnce(eventId).map { it.toDomain() }
            val judges = dao.getJudgesByEventOnce(eventId).map { it.toDomain() }
            val sheets = dao.getScoreSheetsByEventOnce(eventId).map { it.toDomain() }
            val finalRankings = computeRankings(
                teams = teams,
                criteria = criteria,
                scoreSheets = sheets,
                rankingMode = RankingMode.FINAL,
                onlyCountLockedInFinal = comp.onlyCountLockedInFinal
            )
            val now = System.currentTimeMillis()
            val snapshotJson = buildSnapshotJson(comp, finalRankings, now)
            val leader = finalRankings.firstOrNull { it.finalScore > 0.0 }
            val winnerSummary = leader?.let {
                "#1 ${it.team.name} (${String.format(Locale.US, "%.2f", it.finalScore)})"
            } ?: "Belum ada juara tercatat"

            dao.upsertArchiveSnapshot(
                ArchiveResultSnapshot(
                    eventId = eventId,
                    snapshotJson = snapshotJson,
                    totalParticipants = teams.size,
                    totalJudges = judges.count { it.isActive }.takeIf { it > 0 } ?: judges.size,
                    winnerSummary = winnerSummary,
                    lockedAtMillis = now,
                    lockedBy = actor
                ).toEntity()
            )
            dao.upsertCompetitionConfig(
                comp.copy(
                    status = EventStatus.FINISHED,
                    rankingMode = RankingMode.FINAL,
                    isScoringLocked = true,
                    isArchivedLocked = true,
                    isRankingPublished = true
                ).toEntity()
            )
            logActivity(
                eventId = eventId,
                actor = actor,
                actionType = AuditActionType.EVENT_LOCK,
                message = "Event '${comp.name}' ditandai SELESAI, snapshot hasil akhir disimpan, dan seluruh data dikunci."
            )
        }
        pushEventInBackground(eventId)
        return true
    }

    suspend fun reopenArchivedEvent(eventId: String, actor: String, reason: String): Boolean {
        val cleanReason = reason.trim()
        if (cleanReason.isEmpty()) return false
        val compEntity = dao.getCompetitionByIdOnce(eventId) ?: return false
        runInTransaction {
            val now = System.currentTimeMillis()
            val comp = compEntity.toDomain()
            dao.upsertCompetitionConfig(
                comp.copy(
                    status = EventStatus.ACTIVE,
                    isArchivedLocked = false,
                    isScoringLocked = false,
                    reopenReason = cleanReason,
                    lastReopenedAtMillis = now
                ).toEntity()
            )
            logActivity(
                eventId = eventId,
                actor = actor,
                actionType = AuditActionType.EVENT_REOPEN,
                message = "Admin membuka kembali arsip '${comp.name}'.",
                reason = cleanReason
            )
        }
        pushEventInBackground(eventId)
        return true
    }

    suspend fun deleteEventPermanently(eventId: String, actor: String): Result<String> {
        val allCompetitions = dao.getAllCompetitionsOnce()
        if (allCompetitions.size <= 1) {
            return Result.failure(IllegalStateException("Minimal harus terdapat 1 perlombaan di sistem."))
        }
        val target = allCompetitions.find { it.id == eventId }
            ?: return Result.failure(IllegalArgumentException("Event tidak ditemukan."))

        runInTransaction {
            val activeId = resolveActiveEventId()
            if (activeId == eventId) {
                val fallbackId = allCompetitions.first { it.id != eventId }.id
                dao.upsertAppState(AppStateEntity("active_event_id", fallbackId))
            }
            dao.deleteCompetitionById(eventId)
        }
        val api = SupabaseClientFactory.createApi()
        if (api != null) {
            backgroundSyncScope.launch {
                runCatching { api.deleteCompetition(SupabaseConfig.anonKey, resolveBearer(), "eq.$eventId") }
            }
        }
        return Result.success("Event '${target.name}' berhasil dihapus permanen.")
    }

    suspend fun buildEventBackupJson(eventId: String): String {
        val bundle = getEventDetailBundle(eventId) ?: return "{}"
        val root = JSONObject()
        root.put("backupVersion", 3)
        root.put("exportedAtMillis", System.currentTimeMillis())

        val compJson = JSONObject().apply {
            put("id", bundle.config.id)
            put("name", bundle.config.name)
            put("theme", bundle.config.theme)
            put("organizer", bundle.config.organizer)
            put("location", bundle.config.location)
            put("eventDate", bundle.config.eventDate)
            put("year", bundle.config.year)
            put("status", bundle.config.status.name)
            put("isArchivedLocked", bundle.config.isArchivedLocked)
            put("rankingMode", bundle.config.rankingMode.name)
            put("isRankingPublished", bundle.config.isRankingPublished)
            put("createdAtMillis", bundle.config.createdAtMillis)
        }
        root.put("competition", compJson)

        root.put("categories", JSONArray().apply {
            bundle.categories.forEach { cat ->
                put(JSONObject().put("code", cat.code).put("displayName", cat.displayName).put("isEnabled", cat.isEnabled))
            }
        })
        root.put("judges", JSONArray().apply {
            bundle.judges.forEach { j ->
                put(JSONObject().put("judgeNumber", j.judgeNumber).put("name", j.name).put("specialty", j.specialty).put("email", j.email))
            }
        })
        root.put("criteria", JSONArray().apply {
            bundle.criteria.forEach { c ->
                put(JSONObject().put("id", c.id).put("name", c.name).put("weightPercent", c.weightPercent).put("maxScore", c.maxScore))
            }
        })
        root.put("penaltyPresets", JSONArray().apply {
            bundle.penaltyPresets.forEach { p ->
                put(JSONObject().put("id", p.id).put("label", p.label).put("points", p.points))
            }
        })
        root.put("teams", JSONArray().apply {
            bundle.teams.forEach { t ->
                put(JSONObject().put("id", t.id).put("orderNumber", t.orderNumber).put("name", t.name).put("squadName", t.squadName).put("category", t.category.name).put("dantonName", t.dantonName))
            }
        })
        root.put("scoreSheets", JSONArray().apply {
            bundle.scoreSheets.forEach { s ->
                put(JSONObject().put("id", s.id).put("teamId", s.teamId).put("judgeNumber", s.judgeNumber).put("penaltyPoints", s.penaltyPoints).put("isLocked", s.isLocked).put("scores", JSONObject(s.criterionScores)))
            }
        })
        root.put("rankings", JSONArray().apply {
            bundle.rankings.forEach { r ->
                put(JSONObject().put("rank", r.rank).put("teamName", r.team.name).put("squadName", r.team.squadName).put("grossScore", r.grossScore).put("totalPenalty", r.totalPenalty).put("finalScore", r.finalScore).put("predicate", r.predicate))
            }
        })
        root.put("auditLogs", JSONArray().apply {
            bundle.auditLogs.forEach { log ->
                put(JSONObject().put("actor", log.actor).put("actionType", log.actionType.name).put("message", log.message).put("reason", log.reason).put("timestampMillis", log.timestampMillis))
            }
        })
        return root.toString(2)
    }

    suspend fun authenticate(
        role: UserRole,
        identifier: String,
        secret: String,
        judgeNumber: Int?
    ): AuthResult {
        val cleanId = identifier.trim()
        val cleanSecret = secret.trim()
        val activeId = resolveActiveEventId()

        if (cleanId.isEmpty() || cleanSecret.isEmpty()) {
            return AuthResult.Error("Email/Username dan PIN/Password wajib diisi.")
        }

        val api = SupabaseClientFactory.createApi()
        if (api != null && cleanId.contains("@")) {
            val response = runCatching {
                api.signInWithPassword(
                    apiKey = SupabaseConfig.anonKey,
                    request = SupabaseAuthRequest(email = cleanId, password = cleanSecret)
                )
            }.getOrNull()

            if (response != null && response.isSuccessful) {
                val body = response.body()
                supabaseAccessToken = body?.accessToken
                val assignedJudge = if (role == UserRole.JUDGE) (judgeNumber ?: 1) else null
                val judgeInfo = assignedJudge?.let { num ->
                    dao.getJudgesByEventOnce(activeId).find { it.judgeNumber == num }
                }
                val session = AuthSession(
                    userId = body?.user?.id ?: UUID.randomUUID().toString(),
                    displayName = judgeInfo?.name ?: if (role == UserRole.ADMIN) "Admin Panitia" else "Juri $assignedJudge",
                    email = body?.user?.email ?: cleanId,
                    role = role,
                    judgeNumber = assignedJudge,
                    isSupabaseAuthenticated = true
                )
                logActivity(activeId, session.displayName, AuditActionType.SYSTEM, "Masuk via Supabase Auth (${role.label}).")
                return AuthResult.Success(session)
            }
        }

        return when (role) {
            UserRole.ADMIN -> {
                val validAdminIds = setOf("admin", "admin@lkbb.id", "panitia@lkbb.id")
                val validPins = setOf("admin123", "123456", "2026")
                if (cleanId.lowercase() in validAdminIds && cleanSecret in validPins) {
                    val session = AuthSession(
                        userId = "local-admin",
                        displayName = "Admin Panitia Utama",
                        email = "admin@lkbb.id",
                        role = UserRole.ADMIN,
                        judgeNumber = null,
                        isSupabaseAuthenticated = false
                    )
                    logActivity(activeId, session.displayName, AuditActionType.SYSTEM, "Login ke Command Center Admin.")
                    AuthResult.Success(session)
                } else {
                    AuthResult.Error("Kredensial Admin salah. Gunakan admin@lkbb.id / admin123.")
                }
            }

            UserRole.JUDGE -> {
                val targetNumber = judgeNumber ?: 1
                val judge = dao.getJudgesByEventOnce(activeId).find { it.judgeNumber == targetNumber }
                    ?: return AuthResult.Error("Akun Juri $targetNumber tidak ditemukan pada event aktif.")

                val idMatches = cleanId.equals(judge.email, ignoreCase = true) ||
                    cleanId.equals("juri$targetNumber", ignoreCase = true) ||
                    cleanId.equals(judge.name, ignoreCase = true)
                val pinMatches = cleanSecret == judge.pinCode

                if (idMatches && pinMatches) {
                    val session = AuthSession(
                        userId = "local-judge-$targetNumber",
                        displayName = judge.name,
                        email = judge.email,
                        role = UserRole.JUDGE,
                        judgeNumber = targetNumber,
                        isSupabaseAuthenticated = false
                    )
                    logActivity(activeId, "Juri $targetNumber", AuditActionType.SYSTEM, "${judge.name} login ke meja penilaian.")
                    AuthResult.Success(session)
                } else {
                    AuthResult.Error("Email/kode atau PIN Juri $targetNumber tidak cocok (PIN saat ini: ${judge.pinCode}).")
                }
            }
        }
    }

    suspend fun saveCompetitionConfig(config: CompetitionConfig) {
        dao.upsertCompetitionConfig(config.toEntity())
        logActivity(config.id, "Admin", AuditActionType.SETTINGS, "Memperbarui pengaturan lomba: ${config.name}.")
        pushIfConfigured()
    }

    suspend fun saveJudgeAccount(judge: JudgeAccount) {
        val activeId = judge.eventId.ifBlank { resolveActiveEventId() }
        dao.upsertJudge(judge.toEntity(activeId))
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Memperbarui Juri ${judge.judgeNumber} (${judge.name}).")
        pushIfConfigured()
    }

    suspend fun saveCriterion(criterion: ScoringCriterion) {
        val activeId = criterion.eventId.ifBlank { resolveActiveEventId() }
        dao.upsertCriterion(criterion.toEntity(activeId))
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Menyimpan aspek '${criterion.name}' (Bobot ${criterion.weightPercent}%).")
        pushIfConfigured()
    }

    suspend fun deleteCriterion(id: String, name: String) {
        val activeId = resolveActiveEventId()
        dao.deleteCriterionById(id, activeId)
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Menghapus aspek '$name'.")
        val api = SupabaseClientFactory.createApi()
        if (api != null) {
            runCatching { api.deleteCriterion(SupabaseConfig.anonKey, resolveBearer(), "eq.$id", "eq.$activeId") }
        }
    }

    suspend fun normalizeCriteriaWeights() {
        val activeId = resolveActiveEventId()
        val all = dao.getCriteriaByEventOnce(activeId).map { it.toDomain() }
        val active = all.filter { it.isActive }
        if (active.isEmpty()) return
        val sum = active.sumOf { it.weightPercent }.coerceAtLeast(1)
        var running = 0
        val updatedActive = active.mapIndexed { idx, crit ->
            val normalized = if (idx == active.lastIndex) {
                (100 - running).coerceAtLeast(1)
            } else {
                val part = ((crit.weightPercent * 100.0) / sum).toInt().coerceAtLeast(1)
                running += part
                part
            }
            crit.copy(weightPercent = normalized)
        }
        val inactive = all.filter { !it.isActive }
        dao.upsertCriteria((updatedActive + inactive).map { it.toEntity(activeId) })
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Menormalisasi bobot ${active.size} aspek penilaian ke 100%.")
        pushIfConfigured()
    }

    suspend fun savePenaltyPreset(preset: PenaltyPreset) {
        val activeId = preset.eventId.ifBlank { resolveActiveEventId() }
        dao.upsertPenaltyPreset(preset.toEntity(activeId))
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Menyimpan aturan penalti '${preset.label}' (-${preset.points}).")
        pushIfConfigured()
    }

    suspend fun deletePenaltyPreset(preset: PenaltyPreset) {
        val activeId = preset.eventId.ifBlank { resolveActiveEventId() }
        dao.deletePenaltyPresetById(preset.id, activeId)
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Menghapus aturan penalti '${preset.label}'.")
        val api = SupabaseClientFactory.createApi()
        if (api != null) {
            runCatching { api.deletePenaltyPreset(SupabaseConfig.anonKey, resolveBearer(), "eq.${preset.id}", "eq.$activeId") }
        }
    }

    suspend fun saveTeam(team: Team) {
        val activeId = team.eventId.ifBlank { resolveActiveEventId() }
        dao.upsertTeam(team.toEntity(activeId))
        val squadInfo = if (team.squadName.isNotBlank()) " (${team.squadName})" else ""
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Menyimpan peserta #${team.orderNumber} ${team.name}$squadInfo.")
        pushIfConfigured()
    }

    suspend fun updateTeamStatus(team: Team, status: TeamPerformanceStatus) {
        val activeId = team.eventId.ifBlank { resolveActiveEventId() }
        dao.upsertTeam(team.copy(status = status, eventId = activeId).toEntity(activeId))
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Status #${team.orderNumber} ${team.name} -> ${status.label}.")
        pushIfConfigured()
    }

    suspend fun deleteTeam(team: Team) {
        val activeId = team.eventId.ifBlank { resolveActiveEventId() }
        dao.deleteScoresByTeamId(team.id, activeId)
        dao.deleteTeamById(team.id, activeId)
        logActivity(activeId, "Admin", AuditActionType.SETTINGS, "Menghapus peserta #${team.orderNumber} ${team.name}.")
        val api = SupabaseClientFactory.createApi()
        if (api != null) {
            runCatching { api.deleteTeam(SupabaseConfig.anonKey, resolveBearer(), "eq.${team.id}", "eq.$activeId") }
        }
    }

    suspend fun saveScoreSheet(sheet: JudgeScoreSheet, actorLabel: String): Boolean {
        val activeId = sheet.eventId.ifBlank { resolveActiveEventId() }
        val config = dao.getCompetitionByIdOnce(activeId)?.toDomain()
        if (config != null && (config.isArchivedLocked || config.status == EventStatus.FINISHED)) {
            return false
        }
        dao.upsertScoreSheet(sheet.toEntity(activeId))
        val stateText = if (sheet.isLocked) "dikunci & dikirim" else "disimpan sebagai draft"
        logActivity(activeId, actorLabel, AuditActionType.SCORE_EDIT, "Nilai Juri ${sheet.judgeNumber} untuk pleton ${sheet.teamId} $stateText.")
        pushIfConfigured()
        return true
    }

    suspend fun unlockScoreSheet(teamId: String, judgeNumber: Int): Boolean {
        val activeId = resolveActiveEventId()
        val config = dao.getCompetitionByIdOnce(activeId)?.toDomain()
        if (config != null && (config.isArchivedLocked || config.status == EventStatus.FINISHED)) {
            return false
        }
        val existing = dao.getScoreSheetsByEventOnce(activeId).find { it.teamId == teamId && it.judgeNumber == judgeNumber }
        if (existing != null) {
            dao.upsertScoreSheet(existing.copy(isLocked = false, updatedAtMillis = System.currentTimeMillis()))
            logActivity(activeId, "Admin", AuditActionType.SCORE_EDIT, "Membuka kunci nilai Juri $judgeNumber pada pleton $teamId untuk koreksi.")
            pushIfConfigured()
        }
        return true
    }

    private fun resolveBearer(): String? = when {
        supabaseAccessToken != null -> "Bearer $supabaseAccessToken"
        SupabaseConfig.isPublishableKey -> null
        else -> "Bearer ${SupabaseConfig.anonKey}"
    }

    private fun pushIfConfigured() {
        if (SupabaseConfig.isConfigured) {
            backgroundSyncScope.launch {
                runCatching { syncWithSupabase() }
            }
        }
    }

    private fun pushEventInBackground(eventId: String) {
        if (SupabaseConfig.isConfigured) {
            backgroundSyncScope.launch {
                runCatching { syncEventWithSupabase(eventId) }
            }
        }
    }

    suspend fun syncWithSupabase(): SyncResult {
        val activeId = resolveActiveEventId()
        return syncEventWithSupabase(activeId)
    }

    suspend fun syncEventWithSupabase(eventId: String): SyncResult {
        if (!SupabaseConfig.isConfigured) {
            return SyncResult.LocalOnly(
                "Mode Lokal Aktif. Isi SUPABASE_URL & SUPABASE_ANON (sb_publishable_...) di Secrets AI Studio untuk simpan permanen ke Supabase."
            )
        }
        val api = SupabaseClientFactory.createApi()
            ?: return SyncResult.Failure("Gagal menginisialisasi klien Supabase.")

        val bearer = resolveBearer()
        return try {
            val config = dao.getCompetitionByIdOnce(eventId)?.toDomain()
                ?: return SyncResult.Failure("Event $eventId tidak ditemukan secara lokal.")
            val categories = dao.getCategoriesByEventOnce(eventId).map { it.toDomain() }
            val judges = dao.getJudgesByEventOnce(eventId).map { it.toDomain() }
            val criteria = dao.getCriteriaByEventOnce(eventId).map { it.toDomain() }
            val penalties = dao.getPenaltyPresetsByEventOnce(eventId).map { it.toDomain() }
            val teams = dao.getTeamsByEventOnce(eventId).map { it.toDomain() }
            val sheets = dao.getScoreSheetsByEventOnce(eventId).map { it.toDomain() }
            val snapshot = dao.getArchiveSnapshotOnce(eventId)?.toDomain()
            val logs = dao.getActivityLogsByEventOnce(eventId).map { it.toDomain() }

            val compResp = api.upsertCompetition(
                apiKey = SupabaseConfig.anonKey,
                bearer = bearer,
                body = SupabaseCompetitionDto(
                    id = config.id,
                    name = config.name,
                    theme = config.theme,
                    organizer = config.organizer,
                    location = config.location,
                    eventDate = config.eventDate,
                    year = config.year,
                    maxDurationMinutes = config.maxDurationMinutes,
                    logoUrl = config.logoUrl,
                    bannerUrl = config.bannerUrl,
                    rankingMode = config.rankingMode.name,
                    isRankingPublished = config.isRankingPublished,
                    onlyCountLockedInFinal = config.onlyCountLockedInFinal,
                    isScoringLocked = config.isScoringLocked,
                    status = config.status.name,
                    isArchivedLocked = config.isArchivedLocked,
                    createdAtMillis = config.createdAtMillis,
                    reopenReason = config.reopenReason,
                    lastReopenedAtMillis = config.lastReopenedAtMillis
                )
            )
            if (!compResp.isSuccessful) {
                return SyncResult.Failure("Supabase error ${compResp.code()}: periksa tabel multi-event & RLS policy di Supabase.")
            }

            if (categories.isNotEmpty()) {
                api.upsertCategories(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = categories.map {
                        SupabaseCategoryDto(it.id, eventId, it.code, it.displayName, it.isEnabled, it.sortOrder)
                    }
                )
            }

            if (judges.isNotEmpty()) {
                api.upsertJudges(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = judges.map {
                        SupabaseJudgeAccountDto(
                            id = "${eventId}_j${it.judgeNumber}",
                            eventId = eventId,
                            judgeNumber = it.judgeNumber,
                            name = it.name,
                            specialty = it.specialty,
                            email = it.email,
                            pinCode = it.pinCode,
                            isActive = it.isActive
                        )
                    }
                )
            }

            if (criteria.isNotEmpty()) {
                api.upsertCriteria(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = criteria.map {
                        SupabaseCriterionDto(it.id, eventId, it.name, it.categoryGroup, it.maxScore, it.weightPercent, it.description, it.isActive, it.sortOrder)
                    }
                )
            }

            if (penalties.isNotEmpty()) {
                api.upsertPenaltyPresets(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = penalties.map {
                        SupabasePenaltyPresetDto(it.id, eventId, it.label, it.points, it.description, it.isActive, it.sortOrder)
                    }
                )
            }

            if (teams.isNotEmpty()) {
                api.upsertTeams(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = teams.map {
                        SupabaseTeamDto(it.id, eventId, it.orderNumber, it.name, it.squadName, it.contingentCode, it.category.name, it.dantonName, it.status.name)
                    }
                )
            }

            if (sheets.isNotEmpty()) {
                api.upsertScoreSheets(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = sheets.map { sheet ->
                        val json = JSONObject()
                        sheet.criterionScores.forEach { (k, v) -> json.put(k, v) }
                        SupabaseScoreSheetDto(
                            id = sheet.id,
                            eventId = eventId,
                            teamId = sheet.teamId,
                            judgeNumber = sheet.judgeNumber,
                            criterionScoresJson = json.toString(),
                            penaltyPoints = sheet.penaltyPoints,
                            penaltyNotes = sheet.penaltyNotes,
                            evaluatorNotes = sheet.evaluatorNotes,
                            isLocked = sheet.isLocked,
                            updatedAtMillis = sheet.updatedAtMillis
                        )
                    }
                )
            }

            if (snapshot != null) {
                api.upsertResult(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = SupabaseArchiveResultDto(
                        eventId = snapshot.eventId,
                        snapshotJson = snapshot.snapshotJson,
                        totalParticipants = snapshot.totalParticipants,
                        totalJudges = snapshot.totalJudges,
                        winnerSummary = snapshot.winnerSummary,
                        lockedAtMillis = snapshot.lockedAtMillis,
                        lockedBy = snapshot.lockedBy
                    )
                )
            }

            if (logs.isNotEmpty()) {
                api.upsertAuditLogs(
                    apiKey = SupabaseConfig.anonKey,
                    bearer = bearer,
                    body = logs.map { log ->
                        SupabaseAuditLogDto(log.id, eventId, log.actor, log.actionType.name, log.message, log.reason, log.timestampMillis)
                    }
                )
            }

            val updated = config.copy(lastSyncedAtMillis = System.currentTimeMillis())
            dao.upsertCompetitionConfig(updated.toEntity())
            logActivity(eventId, "Supabase Sync", AuditActionType.SYSTEM, "Event '${config.name}' (${teams.size} peserta, ${sheets.size} nilai) tersinkron ke Supabase.")
            SyncResult.Success("Event '${config.name}' tersimpan permanen di Supabase (${teams.size} peserta, ${criteria.size} aspek).")
        } catch (e: Exception) {
            SyncResult.Failure("Koneksi Supabase gagal: ${e.localizedMessage ?: "periksa jaringan"}")
        }
    }

    suspend fun pullFromSupabase(): SyncResult {
        if (!SupabaseConfig.isConfigured) {
            return SyncResult.LocalOnly(
                "Mode Lokal Aktif. Isi SUPABASE_URL & SUPABASE_ANON di Secrets untuk mengambil data dari Supabase."
            )
        }
        val api = SupabaseClientFactory.createApi()
            ?: return SyncResult.Failure("Gagal menginisialisasi klien Supabase.")
        val bearer = resolveBearer()
        return try {
            val compResp = api.fetchCompetitions(SupabaseConfig.anonKey, bearer)
            if (!compResp.isSuccessful) {
                return SyncResult.Failure("Gagal menarik data Supabase (${compResp.code()}).")
            }
            val remoteCompetitions = compResp.body().orEmpty()
            if (remoteCompetitions.isEmpty()) {
                return SyncResult.LocalOnly("Belum ada data event tersimpan di Supabase.")
            }

            val activeId = resolveActiveEventId()
            remoteCompetitions.forEach { dto ->
                val eventId = dto.id
                val domain = CompetitionConfig(
                    id = eventId,
                    name = dto.name,
                    theme = dto.theme,
                    organizer = dto.organizer,
                    location = dto.location,
                    eventDate = dto.eventDate,
                    year = dto.year,
                    maxDurationMinutes = dto.maxDurationMinutes,
                    logoUrl = dto.logoUrl,
                    bannerUrl = dto.bannerUrl,
                    rankingMode = runCatching { RankingMode.valueOf(dto.rankingMode) }.getOrDefault(RankingMode.LIVE),
                    isRankingPublished = dto.isRankingPublished,
                    onlyCountLockedInFinal = dto.onlyCountLockedInFinal,
                    isScoringLocked = dto.isScoringLocked,
                    status = runCatching { EventStatus.valueOf(dto.status) }.getOrDefault(EventStatus.ACTIVE),
                    isArchivedLocked = dto.isArchivedLocked,
                    createdAtMillis = dto.createdAtMillis,
                    reopenReason = dto.reopenReason,
                    lastReopenedAtMillis = dto.lastReopenedAtMillis,
                    lastSyncedAtMillis = System.currentTimeMillis()
                )
                dao.upsertCompetitionConfig(domain.toEntity())

                val eventFilter = "eq.$eventId"
                api.fetchCategories(SupabaseConfig.anonKey, bearer, eventFilter).body()?.takeIf { it.isNotEmpty() }?.let { list ->
                    dao.upsertCategories(list.map { EventCategoryConfig(it.id, eventId, it.code, it.displayName, it.isEnabled, it.sortOrder).toEntity() })
                }
                api.fetchJudges(SupabaseConfig.anonKey, bearer, eventFilter).body()?.takeIf { it.isNotEmpty() }?.let { list ->
                    dao.upsertJudges(list.map { JudgeAccount(it.judgeNumber, it.name, it.specialty, it.email, it.pinCode, it.isActive, eventId).toEntity(eventId) })
                }
                api.fetchCriteria(SupabaseConfig.anonKey, bearer, eventFilter).body()?.takeIf { it.isNotEmpty() }?.let { list ->
                    dao.clearCriteriaForEvent(eventId)
                    dao.upsertCriteria(list.map { ScoringCriterion(it.id, it.name, it.categoryGroup, it.maxScore, it.weightPercent, it.description, it.isActive, it.sortOrder, eventId).toEntity(eventId) })
                }
                api.fetchPenaltyPresets(SupabaseConfig.anonKey, bearer, eventFilter).body()?.takeIf { it.isNotEmpty() }?.let { list ->
                    dao.clearPenaltyPresetsForEvent(eventId)
                    dao.upsertPenaltyPresets(list.map { PenaltyPreset(it.id, it.label, it.points, it.description, it.isActive, it.sortOrder, eventId).toEntity(eventId) })
                }
                api.fetchTeams(SupabaseConfig.anonKey, bearer, eventFilter).body()?.takeIf { it.isNotEmpty() }?.let { list ->
                    dao.clearTeamsForEvent(eventId)
                    dao.upsertTeams(list.map {
                        Team(
                            id = it.id,
                            orderNumber = it.orderNumber,
                            name = it.name,
                            squadName = it.squadName,
                            contingentCode = it.contingentCode,
                            category = runCatching { CompetitionCategory.valueOf(it.category) }.getOrDefault(CompetitionCategory.SMA),
                            dantonName = it.dantonName,
                            status = runCatching { TeamPerformanceStatus.valueOf(it.status) }.getOrDefault(TeamPerformanceStatus.WAITING),
                            eventId = eventId
                        ).toEntity(eventId)
                    })
                }
                api.fetchScoreSheets(SupabaseConfig.anonKey, bearer, eventFilter).body()?.takeIf { it.isNotEmpty() }?.let { list ->
                    dao.upsertScoreSheets(list.map { sDto ->
                        val map = mutableMapOf<String, Int>()
                        runCatching {
                            val json = JSONObject(sDto.criterionScoresJson)
                            val keys = json.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                map[k] = json.optInt(k, 0)
                            }
                        }
                        JudgeScoreSheet(
                            id = sDto.id,
                            teamId = sDto.teamId,
                            judgeNumber = sDto.judgeNumber,
                            criterionScores = map,
                            penaltyPoints = sDto.penaltyPoints,
                            penaltyNotes = sDto.penaltyNotes,
                            evaluatorNotes = sDto.evaluatorNotes,
                            isLocked = sDto.isLocked,
                            updatedAtMillis = sDto.updatedAtMillis,
                            eventId = eventId
                        ).toEntity(eventId)
                    })
                }
                api.fetchResults(SupabaseConfig.anonKey, bearer, eventFilter).body()?.firstOrNull()?.let { res ->
                    dao.upsertArchiveSnapshot(
                        ArchiveResultSnapshot(
                            eventId = res.eventId,
                            snapshotJson = res.snapshotJson,
                            totalParticipants = res.totalParticipants,
                            totalJudges = res.totalJudges,
                            winnerSummary = res.winnerSummary,
                            lockedAtMillis = res.lockedAtMillis,
                            lockedBy = res.lockedBy
                        ).toEntity()
                    )
                }
            }

            logActivity(activeId, "Supabase Pull", AuditActionType.SYSTEM, "${remoteCompetitions.size} event berhasil disinkronkan dari Supabase.")
            SyncResult.Success("${remoteCompetitions.size} arsip & event aktif berhasil dimuat dari Supabase.")
        } catch (e: Exception) {
            SyncResult.Failure("Gagal mengambil data Supabase: ${e.localizedMessage ?: "periksa jaringan"}")
        }
    }

    private suspend fun logActivity(
        eventId: String,
        actor: String,
        actionType: AuditActionType,
        message: String,
        reason: String = "",
        timestampOverride: Long? = null
    ) {
        dao.insertLog(
            ActivityLogEntity(
                id = UUID.randomUUID().toString(),
                eventId = eventId,
                actor = actor,
                actionType = actionType.name,
                message = message,
                reason = reason,
                timestampMillis = timestampOverride ?: System.currentTimeMillis()
            )
        )
    }

    companion object {
        fun calculateWeightedJudgeScore(
            criterionScores: Map<String, Int>,
            criteria: List<ScoringCriterion>
        ): Double {
            val active = criteria.filter { it.isActive }
            if (active.isEmpty()) return 0.0
            val totalWeight = active.sumOf { it.weightPercent }.coerceAtLeast(1)
            return active.sumOf { criterion ->
                val raw = (criterionScores[criterion.id] ?: 0).coerceIn(0, criterion.maxScore)
                val ratio = raw.toDouble() / criterion.maxScore.coerceAtLeast(1)
                ratio * criterion.weightPercent * (100.0 / totalWeight)
            }
        }

        fun computeRankings(
            teams: List<Team>,
            criteria: List<ScoringCriterion>,
            scoreSheets: List<JudgeScoreSheet>,
            rankingMode: RankingMode = RankingMode.LIVE,
            onlyCountLockedInFinal: Boolean = true
        ): List<TeamRankingSummary> {
            val requireLocked = rankingMode == RankingMode.FINAL && onlyCountLockedInFinal

            val prelim = teams.map { team ->
                val teamSheets = scoreSheets.filter { it.teamId == team.id }
                val judgeTotals = mutableMapOf<Int, Double>()
                val judgeLocked = mutableMapOf<Int, Boolean>()
                var penaltySum = 0

                for (j in 1..5) {
                    val sheet = teamSheets.find { it.judgeNumber == j }
                    if (sheet != null) {
                        judgeLocked[j] = sheet.isLocked
                        if (!requireLocked || sheet.isLocked) {
                            judgeTotals[j] = calculateWeightedJudgeScore(sheet.criterionScores, criteria)
                            penaltySum += sheet.penaltyPoints
                        }
                    } else {
                        judgeLocked[j] = false
                    }
                }

                val gross = judgeTotals.values.sum()
                val finalScore = (gross - penaltySum).coerceAtLeast(0.0)
                val submittedCount = judgeLocked.values.count { it }

                TeamRankingSummary(
                    rank = 0,
                    team = team,
                    judgeWeightedTotals = judgeTotals,
                    judgeLockedStates = judgeLocked,
                    grossScore = gross,
                    totalPenalty = penaltySum,
                    finalScore = finalScore,
                    submittedJudgeCount = submittedCount,
                    predicate = ""
                )
            }

            val sorted = prelim.sortedWith(
                compareByDescending<TeamRankingSummary> { it.finalScore }
                    .thenByDescending { it.submittedJudgeCount }
                    .thenBy { it.team.orderNumber }
            )

            return sorted.mapIndexed { index, summary ->
                val rank = index + 1
                val predicate = when {
                    summary.grossScore == 0.0 -> if (requireLocked) "Menunggu Nilai Terkunci" else "Belum Dinilai"
                    rank == 1 -> "Juara Umum / Utama I"
                    rank == 2 -> "Juara Utama II"
                    rank == 3 -> "Juara Utama III"
                    rank == 4 -> "Juara Harapan I"
                    rank == 5 -> "Juara Harapan II"
                    rank == 6 -> "Juara Harapan III"
                    else -> "Madya Peringkat $rank"
                }
                summary.copy(rank = rank, predicate = predicate)
            }
        }

        private fun buildSnapshotJson(
            config: CompetitionConfig,
            rankings: List<TeamRankingSummary>,
            lockedAtMillis: Long
        ): String {
            val arr = JSONArray()
            rankings.forEach { r ->
                arr.put(
                    JSONObject()
                        .put("rank", r.rank)
                        .put("teamId", r.team.id)
                        .put("teamName", r.team.name)
                        .put("squadName", r.team.squadName)
                        .put("category", r.team.category.displayName)
                        .put("grossScore", r.grossScore)
                        .put("totalPenalty", r.totalPenalty)
                        .put("finalScore", r.finalScore)
                        .put("predicate", r.predicate)
                )
            }
            return JSONObject()
                .put("eventId", config.id)
                .put("eventName", config.name)
                .put("lockedAtMillis", lockedAtMillis)
                .put("rankings", arr)
                .toString()
        }
    }
}
