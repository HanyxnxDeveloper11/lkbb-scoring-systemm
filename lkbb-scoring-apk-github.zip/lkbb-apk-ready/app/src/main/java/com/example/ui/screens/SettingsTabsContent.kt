package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CompetitionConfig
import com.example.data.model.JudgeAccount
import com.example.data.model.PenaltyPreset
import com.example.data.model.RankingMode
import com.example.data.model.ScoringCriterion
import com.example.data.model.Team
import com.example.data.remote.SupabaseSchema
import com.example.ui.LkbbUiState
import com.example.ui.components.CompetitionBannerImage
import com.example.ui.components.CompetitionLogoBadge
import com.example.ui.components.StatusPill
import com.example.ui.components.SupabaseConnectionCard
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary

@Composable
fun GeneralAndBrandSettingsSection(
    config: CompetitionConfig,
    onSaveConfig: (CompetitionConfig) -> Unit,
    onPickLogo: () -> Unit,
    onPickBanner: () -> Unit
) {
    var name by remember(config.name) { mutableStateOf(config.name) }
    var organizer by remember(config.organizer) { mutableStateOf(config.organizer) }
    var location by remember(config.location) { mutableStateOf(config.location) }
    var eventDate by remember(config.eventDate) { mutableStateOf(config.eventDate) }
    var maxMinutes by remember(config.maxDurationMinutes) { mutableStateOf(config.maxDurationMinutes.toString()) }
    var logoUrl by remember(config.logoUrl) { mutableStateOf(config.logoUrl) }
    var bannerUrl by remember(config.bannerUrl) { mutableStateOf(config.bannerUrl) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // 1 & 3. Nama Perlombaan, Tanggal & Lokasi
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("1. Identitas, Tanggal & Lokasi Perlombaan", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Perlombaan LKBB") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_competition_name")
                )
                OutlinedTextField(
                    value = organizer,
                    onValueChange = { organizer = it },
                    label = { Text("Penyelenggara / Panitia") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = eventDate,
                        onValueChange = { eventDate = it },
                        label = { Text("Tanggal Lomba") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("settings_competition_date")
                    )
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("Lokasi Arena") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("settings_competition_location")
                    )
                }
                OutlinedTextField(
                    value = maxMinutes,
                    onValueChange = { maxMinutes = it.filter { c -> c.isDigit() } },
                    label = { Text("Batas Durasi Tampil (menit)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // 2. Logo & Banner
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("2. Logo & Banner Perlombaan", style = MaterialTheme.typography.titleLarge)
                Text(
                    text = "Pilih gambar dari galeri perangkat (Photo Picker) atau masukkan URL gambar publik (mis. Supabase Storage).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Live Preview
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    CompetitionLogoBadge(
                        logoUrl = logoUrl,
                        contentDescription = "Preview Logo Perlombaan",
                        modifier = Modifier.size(64.dp)
                    )
                    CompetitionBannerImage(
                        bannerUrl = bannerUrl,
                        contentDescription = "Preview Banner Perlombaan",
                        modifier = Modifier
                            .weight(1f)
                            .height(74.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onPickLogo,
                        modifier = Modifier.weight(1f).testTag("settings_pick_logo_button")
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pilih Logo")
                    }
                    OutlinedButton(
                        onClick = onPickBanner,
                        modifier = Modifier.weight(1f).testTag("settings_pick_banner_button")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pilih Banner")
                    }
                }

                OutlinedTextField(
                    value = logoUrl,
                    onValueChange = { logoUrl = it },
                    label = { Text("URL / Path Logo (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_logo_url_input")
                )
                OutlinedTextField(
                    value = bannerUrl,
                    onValueChange = { bannerUrl = it },
                    label = { Text("URL / Path Banner (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_banner_url_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = {
                            logoUrl = ""
                            bannerUrl = ""
                            onSaveConfig(config.copy(logoUrl = "", bannerUrl = ""))
                        }
                    ) {
                        Text("Reset Logo & Banner Default", color = CrimsonRed)
                    }
                }
            }
        }

        Button(
            onClick = {
                onSaveConfig(
                    config.copy(
                        name = name.trim().ifEmpty { config.name },
                        organizer = organizer.trim().ifEmpty { config.organizer },
                        location = location.trim().ifEmpty { config.location },
                        eventDate = eventDate.trim().ifEmpty { config.eventDate },
                        maxDurationMinutes = (maxMinutes.toIntOrNull() ?: 10).coerceIn(3, 30),
                        logoUrl = logoUrl.trim(),
                        bannerUrl = bannerUrl.trim()
                    )
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = CrispWhite),
            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("settings_save_config_button")
        ) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Simpan Identitas, Tanggal, Lokasi & Media")
        }
    }
}

@Composable
fun FiveJudgesSettingsSection(
    judges: List<JudgeAccount>,
    onEditJudge: (JudgeAccount) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("4. Pengaturan Nama & Profil Lima Juri", style = MaterialTheme.typography.titleLarge)
            Text(
                text = "Ubah nama lengkap kelima juri, bidang spesialisasi, email Supabase, dan PIN login.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            judges.forEach { judge ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Juri ${judge.judgeNumber} — ${judge.name}",
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                StatusPill(
                                    text = if (judge.isActive) "Aktif" else "Nonaktif",
                                    containerColor = if (judge.isActive) EmeraldSoft else CrimsonSoft,
                                    contentColor = if (judge.isActive) EmeraldSuccess else CrimsonRed
                                )
                            }
                            Spacer(Modifier.height(3.dp))
                            Text(
                                text = "${judge.specialty} • ${judge.email} • PIN: ${judge.pinCode}",
                                style = MonoTextStyles.BadgeCode,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = { onEditJudge(judge) },
                            modifier = Modifier.testTag("settings_edit_judge_${judge.judgeNumber}")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Juri ${judge.judgeNumber}")
                        }
                    }
                }
            }
        }
    }
}

fun androidx.compose.foundation.lazy.LazyListScope.participantsSettingsItems(
    teams: List<Team>,
    onAddTeam: () -> Unit,
    onEditTeam: (Team) -> Unit,
    onDeleteTeam: (Team) -> Unit
) {
    item(key = "participants_header") {
        Card(
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("5 & 6. Peserta, Nama Sekolah & Regu", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = "Total ${teams.size} peserta terdaftar. Tambah, edit nama sekolah/regu, atau hapus peserta.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = onAddTeam,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = CrispWhite),
                    modifier = Modifier.testTag("settings_add_team_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Peserta")
                }
            }
        }
    }

    items(teams.size, key = { "part_team_${teams[it].id}" }) { idx ->
        val team = teams[idx]
        Card(
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "#${team.orderNumber} ${team.name}",
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    val squadLabel = if (team.squadName.isNotBlank()) "Regu: ${team.squadName} • " else ""
                    Text(
                        text = "$squadLabel${team.category.displayName} • Danton: ${team.dantonName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    IconButton(
                        onClick = { onEditTeam(team) },
                        modifier = Modifier.testTag("settings_edit_team_${team.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit ${team.name}")
                    }
                    IconButton(
                        onClick = { onDeleteTeam(team) },
                        modifier = Modifier.testTag("settings_delete_team_${team.id}")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus ${team.name}", tint = CrimsonRed)
                    }
                }
            }
        }
    }
}

fun androidx.compose.foundation.lazy.LazyListScope.criteriaAndPenaltiesSettingsItems(
    uiState: LkbbUiState,
    onAddCriterion: () -> Unit,
    onEditCriterion: (ScoringCriterion) -> Unit,
    onDeleteCriterion: (ScoringCriterion) -> Unit,
    onNormalizeWeights: () -> Unit,
    onAddPenalty: () -> Unit,
    onEditPenalty: (PenaltyPreset) -> Unit,
    onDeletePenalty: (PenaltyPreset) -> Unit
) {
    // 7 & 8. Aspek & Bobot Penilaian
    item(key = "criteria_header") {
        Card(
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("7 & 8. Aspek & Bobot Penilaian", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = "Total bobot aktif: ${uiState.totalWeightPercent}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (uiState.totalWeightPercent == 100) EmeraldSuccess else AmberWarning,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Button(
                        onClick = onAddCriterion,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldChampionship, contentColor = NavyDeep),
                        modifier = Modifier.testTag("settings_add_criterion_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Aspek", fontWeight = FontWeight.Bold)
                    }
                }

                if (uiState.totalWeightPercent != 100) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(
                            text = "Total bobot ${uiState.totalWeightPercent}% (target 100%)",
                            containerColor = AmberSoft,
                            contentColor = AmberWarning
                        )
                        OutlinedButton(onClick = onNormalizeWeights) {
                            Icon(Icons.Default.Balance, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Normalisasi 100%")
                        }
                    }
                }
            }
        }
    }

    items(uiState.criteria.size, key = { "crit_${uiState.criteria[it].id}" }) { idx ->
        val crit = uiState.criteria[idx]
        Card(
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = crit.name,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        StatusPill(
                            text = "${crit.weightPercent}%",
                            containerColor = NavyPrimary,
                            contentColor = GoldChampionship
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "${crit.categoryGroup} • Maks ${crit.maxScore} poin • ${if (crit.isActive) "Aktif" else "Nonaktif"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    IconButton(onClick = { onEditCriterion(crit) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit ${crit.name}")
                    }
                    IconButton(onClick = { onDeleteCriterion(crit) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus ${crit.name}", tint = CrimsonRed)
                    }
                }
            }
        }
    }

    item(key = "penalties_divider") {
        HorizontalDivider(modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth().padding(vertical = 4.dp))
    }

    // 9. Pengaturan Penalti
    item(key = "penalties_header") {
        Card(
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.45f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("9. Pengaturan Aturan Penalti", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = "Kelola daftar pelanggaran dan poin pengurangan yang tampil di formulir juri.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = onAddPenalty,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = CrispWhite),
                    modifier = Modifier.testTag("settings_add_penalty_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Penalti")
                }
            }
        }
    }

    items(uiState.penaltyPresets.size, key = { "pen_${uiState.penaltyPresets[it].id}" }) { idx ->
        val preset = uiState.penaltyPresets[idx]
        Card(
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = preset.label,
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        StatusPill(
                            text = "-${preset.points} poin",
                            containerColor = CrimsonSoft,
                            contentColor = CrimsonRed
                        )
                    }
                    if (preset.description.isNotBlank()) {
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "${preset.description} • ${if (preset.isActive) "Aktif" else "Nonaktif"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Row {
                    IconButton(onClick = { onEditPenalty(preset) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit ${preset.label}")
                    }
                    IconButton(onClick = { onDeletePenalty(preset) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus ${preset.label}", tint = CrimsonRed)
                    }
                }
            }
        }
    }
}

fun androidx.compose.foundation.lazy.LazyListScope.rankingAndSupabaseSettingsItems(
    uiState: LkbbUiState,
    onUpdateRankingSettings: (RankingMode, Boolean, Boolean, Boolean) -> Unit,
    onPushSupabase: () -> Unit,
    onPullSupabase: () -> Unit,
    onShowSql: () -> Unit,
    onRequestReset: () -> Unit
) {
    // 10. Pengaturan Live Ranking & Final Ranking
    item(key = "ranking_mode_card") {
        val config = uiState.competitionConfig
        var rankingMode by remember(config.rankingMode) { mutableStateOf(config.rankingMode) }
        var isRankingPublished by remember(config.isRankingPublished) { mutableStateOf(config.isRankingPublished) }
        var onlyLockedInFinal by remember(config.onlyCountLockedInFinal) { mutableStateOf(config.onlyCountLockedInFinal) }
        var isScoringLocked by remember(config.isScoringLocked) { mutableStateOf(config.isScoringLocked) }

        Card(
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.65f))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Verified, contentDescription = null, tint = GoldChampionship)
                    Text("10. Pengaturan Live Ranking & Final Ranking", style = MaterialTheme.typography.titleLarge)
                }

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    RankingMode.entries.forEachIndexed { idx, mode ->
                        SegmentedButton(
                            selected = rankingMode == mode,
                            onClick = { rankingMode = mode },
                            shape = SegmentedButtonDefaults.itemShape(idx, RankingMode.entries.size),
                            colors = SegmentedButtonDefaults.colors(
                                activeContainerColor = if (mode == RankingMode.FINAL) GoldChampionship else NavyPrimary,
                                activeContentColor = if (mode == RankingMode.FINAL) NavyDeep else CrispWhite
                            ),
                            modifier = Modifier.testTag("settings_ranking_mode_${mode.name.lowercase()}")
                        ) {
                            Text(mode.label)
                        }
                    }
                }

                Text(
                    text = rankingMode.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Publikasikan Dashboard Ranking", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "Jika dimatikan, ranking hanya terlihat oleh Admin (sembunyikan sementara dari Juri).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = isRankingPublished, onCheckedChange = { isRankingPublished = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Hanya Nilai Terkunci di Final Ranking", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "Mengabaikan nilai draft yang belum dikunci juri saat mode Final Ranking aktif.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = onlyLockedInFinal, onCheckedChange = { onlyLockedInFinal = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Kunci Penilaian Global", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "Menghentikan semua input/edit nilai oleh 5 juri.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isScoringLocked,
                        onCheckedChange = { isScoringLocked = it },
                        modifier = Modifier.testTag("settings_global_lock_switch")
                    )
                }

                Button(
                    onClick = {
                        onUpdateRankingSettings(
                            rankingMode,
                            isRankingPublished,
                            onlyLockedInFinal,
                            isScoringLocked
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = CrispWhite),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("settings_save_ranking_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Terapkan Pengaturan Ranking")
                }
            }
        }
    }

    // Supabase Cloud Push & Pull
    item(key = "supabase_sync_card") {
        Column(modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth()) {
            SupabaseConnectionCard(
                isConfigured = uiState.isSupabaseConfigured,
                isSyncing = uiState.isSyncing,
                onSyncClick = onPushSupabase
            )
        }
    }

    item(key = "supabase_actions_row") {
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth()
        ) {
            OutlinedButton(
                onClick = onPullSupabase,
                enabled = !uiState.isSyncing,
                modifier = Modifier.weight(1f).testTag("settings_pull_supabase_button")
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Muat dari Supabase")
            }
            OutlinedButton(
                onClick = onShowSql,
                modifier = Modifier.weight(1f).testTag("settings_view_sql_button")
            ) {
                Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Skema SQL")
            }
        }
    }

    item(key = "reset_demo_button_item") {
        OutlinedButton(
            onClick = onRequestReset,
            border = BorderStroke(1.dp, CrimsonRed),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonRed),
            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth().testTag("settings_reset_demo_button")
        ) {
            Icon(Icons.Default.RestartAlt, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Reset Data Perlombaan ke Template Awal")
        }
    }
}
