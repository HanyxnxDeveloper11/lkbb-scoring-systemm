package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.EventArchiveSummary
import com.example.data.model.EventStatus
import com.example.ui.LkbbUiState
import com.example.ui.components.CompetitionLogoBadge
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySoft
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EventArchiveScreen(
    uiState: LkbbUiState,
    onBack: () -> Unit,
    onCreateNewEvent: () -> Unit,
    onOpenArchiveDetail: (String) -> Unit,
    onActivateEvent: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedYear by remember { mutableStateOf<Int?>(null) }
    var selectedStatus by remember { mutableStateOf<EventStatus?>(null) }
    var sortNewestFirst by remember { mutableStateOf(true) }

    val availableYears = remember(uiState.archiveSummaries) {
        uiState.archiveSummaries.map { it.config.year }.distinct().sortedDescending()
    }

    val filteredEvents = remember(
        uiState.archiveSummaries,
        searchQuery,
        selectedYear,
        selectedStatus,
        sortNewestFirst
    ) {
        uiState.archiveSummaries
            .filter { summary ->
                val c = summary.config
                val matchesQuery = searchQuery.isBlank() ||
                    c.name.contains(searchQuery, ignoreCase = true) ||
                    c.location.contains(searchQuery, ignoreCase = true) ||
                    c.theme.contains(searchQuery, ignoreCase = true)
                val matchesYear = selectedYear == null || c.year == selectedYear
                val matchesStatus = selectedStatus == null || c.status == selectedStatus
                matchesQuery && matchesYear && matchesStatus
            }
            .let { list ->
                if (sortNewestFirst) {
                    list.sortedByDescending { it.config.createdAtMillis }
                } else {
                    list.sortedBy { it.config.createdAtMillis }
                }
            }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card + Create New Competition Button
            item {
                Card(
                    modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            IconButton(onClick = onBack) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Kembali ke Dashboard",
                                    tint = CrispWhite
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                StatusPill(
                                    text = "ARSIP PERLOMBAAN DIGITAL",
                                    containerColor = GoldChampionship,
                                    contentColor = NavyDeep,
                                    icon = Icons.Default.Archive
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = "Multi-Event & Arsip LKBB",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = CrispWhite
                                )
                                Text(
                                    text = "${uiState.archiveSummaries.size} event tersimpan dengan pemisahan data per event_id.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CrispWhite.copy(alpha = 0.82f)
                                )
                            }
                        }

                        Button(
                            onClick = onCreateNewEvent,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CrimsonRed,
                                contentColor = CrispWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("archive_create_event_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("BUAT PERLOMBAAN BARU", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Search, Year Filter, Status Filter & Date Sort
            item {
                Card(
                    modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Cari nama event, tema, atau lokasi...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("archive_search_input")
                            )
                            OutlinedButton(
                                onClick = { sortNewestFirst = !sortNewestFirst },
                                modifier = Modifier.testTag("archive_sort_button")
                            ) {
                                Icon(Icons.Default.SwapVert, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (sortNewestFirst) "Terbaru" else "Terlama")
                            }
                        }

                        // Year Filter Row
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                FilterChip(
                                    selected = selectedYear == null,
                                    onClick = { selectedYear = null },
                                    label = { Text("Semua Tahun") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NavyPrimary,
                                        selectedLabelColor = CrispWhite
                                    )
                                )
                            }
                            items(availableYears) { yr ->
                                FilterChip(
                                    selected = selectedYear == yr,
                                    onClick = { selectedYear = if (selectedYear == yr) null else yr },
                                    label = { Text("$yr") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = GoldChampionship,
                                        selectedLabelColor = NavyDeep
                                    ),
                                    modifier = Modifier.testTag("archive_year_$yr")
                                )
                            }
                        }

                        // Status Filter Row
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                FilterChip(
                                    selected = selectedStatus == null,
                                    onClick = { selectedStatus = null },
                                    label = { Text("Semua Status") }
                                )
                            }
                            items(EventStatus.entries) { st ->
                                FilterChip(
                                    selected = selectedStatus == st,
                                    onClick = { selectedStatus = if (selectedStatus == st) null else st },
                                    label = { Text(st.label) },
                                    modifier = Modifier.testTag("archive_status_${st.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }

            if (filteredEvents.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Archive,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(44.dp)
                            )
                            Text("Tidak ada arsip perlombaan yang cocok.", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "Ubah filter pencarian/tahun/status atau buat perlombaan baru.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(filteredEvents, key = { it.config.id }) { summary ->
                    ArchiveEventCard(
                        summary = summary,
                        isCurrentlyActive = summary.config.id == uiState.competitionConfig.id,
                        onOpenDetail = { onOpenArchiveDetail(summary.config.id) },
                        onActivate = { onActivateEvent(summary.config.id) },
                        modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth()
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ArchiveEventCard(
    summary: EventArchiveSummary,
    isCurrentlyActive: Boolean,
    onOpenDetail: () -> Unit,
    onActivate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = summary.config
    val createdDateFormatted = remember(c.createdAtMillis) {
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(c.createdAtMillis))
    }

    val (statusBg, statusFg) = when (c.status) {
        EventStatus.ACTIVE -> EmeraldSoft to EmeraldSuccess
        EventStatus.DRAFT -> AmberSoft to AmberWarning
        EventStatus.FINISHED -> NavySoft to NavyPrimary
    }

    Card(
        modifier = modifier.testTag("archive_card_${c.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (isCurrentlyActive) 2.dp else 1.dp,
            color = if (isCurrentlyActive) GoldChampionship else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isCurrentlyActive) 4.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompetitionLogoBadge(
                    logoUrl = c.logoUrl,
                    contentDescription = "Logo ${c.name}",
                    modifier = Modifier.size(54.dp)
                )
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatusPill(text = c.status.badgeText, containerColor = statusBg, contentColor = statusFg)
                        if (isCurrentlyActive) {
                            StatusPill(
                                text = "SEDANG DIBUKA",
                                containerColor = GoldSoft,
                                contentColor = NavyDeep,
                                icon = Icons.Default.CheckCircle
                            )
                        }
                        if (c.isArchivedLocked) {
                            StatusPill(
                                text = "TERKUNCI",
                                containerColor = NavyPrimary,
                                contentColor = CrispWhite,
                                icon = Icons.Default.Lock
                            )
                        }
                        StatusPill(
                            text = if (c.isRankingPublished) "Hasil Publik" else "Pratinjau Admin",
                            containerColor = if (c.isRankingPublished) EmeraldSoft else AmberSoft,
                            contentColor = if (c.isRankingPublished) EmeraldSuccess else AmberWarning,
                            icon = if (c.isRankingPublished) Icons.Default.Public else Icons.Default.VisibilityOff
                        )
                    }
                    Text(
                        text = c.name,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (c.theme.isNotBlank()) {
                        Text(
                            text = "Tema: ${c.theme}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ArchiveMetaTag(Icons.Default.CalendarToday, "Lomba: ${c.eventDate}")
                ArchiveMetaTag(Icons.Default.LocationOn, c.location)
                ArchiveMetaTag(Icons.Default.Groups, "${summary.teamCount} Peserta")
                ArchiveMetaTag(Icons.Default.Gavel, "${summary.judgeCount} Juri")
                ArchiveMetaTag(Icons.Default.Archive, "Dibuat: $createdDateFormatted")
            }

            summary.snapshot?.let { snap ->
                Text(
                    text = "Snapshot Juara: ${snap.winnerSummary}",
                    style = MaterialTheme.typography.labelMedium,
                    color = NavyPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenDetail,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary, contentColor = CrispWhite),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("archive_open_detail_${c.id}")
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Detail Arsip")
                }

                if (!isCurrentlyActive) {
                    OutlinedButton(
                        onClick = onActivate,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("archive_activate_${c.id}")
                    ) {
                        Text(if (c.isArchivedLocked) "Lihat Mode Baca" else "Aktifkan Event")
                    }
                }
            }
        }
    }
}

@Composable
private fun ArchiveMetaTag(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
