package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.JudgeStationSummary
import com.example.data.model.UserRole
import com.example.data.repository.LkbbScoringRepository
import com.example.ui.LkbbUiState
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldChampionship
import com.example.ui.theme.MonoTextStyles
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySurface
import java.util.Locale

@Composable
fun FiveJudgesDashboardScreen(
    uiState: LkbbUiState,
    onOpenJudgeScoring: (judgeNumber: Int, teamId: String?) -> Unit,
    onUnlockScoreSheet: (teamId: String, judgeNumber: Int) -> Unit
) {
    val session = uiState.session
    val isAdmin = session?.role == UserRole.ADMIN
    val currentJudgeNum = session?.judgeNumber

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth >= 760.dp

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    border = BorderStroke(1.dp, GoldChampionship.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            StatusPill(
                                text = "PANEL DEWAN 5 JURI",
                                containerColor = GoldChampionship,
                                contentColor = NavyDeep
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = if (isAdmin) {
                                    "Monitoring Real-Time Lima Juri"
                                } else {
                                    "Meja Juri $currentJudgeNum • ${session?.displayName.orEmpty()}"
                                },
                                style = MaterialTheme.typography.headlineSmall,
                                color = CrispWhite
                            )
                            Text(
                                text = if (isAdmin) {
                                    "Pantau progres input nilai Juri 1 s/d Juri 5 dan buka formulir atau koreksi kunci nilai."
                                } else {
                                    "Lihat progres meja Anda dan sinkronisasi kelengkapan penilaian bersama 4 juri lainnya."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = CrispWhite.copy(alpha = 0.8f)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(NavySurface),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = "Dewan Juri",
                                tint = GoldChampionship,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }

            // 5 Judge Station Cards
            item {
                Text(
                    text = "Status Lima Meja Juri (J1 – J5)",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            if (isWide) {
                items(uiState.judgeStations.chunked(2)) { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { station ->
                            JudgeStationCard(
                                station = station,
                                isHighlighted = station.judge.judgeNumber == currentJudgeNum,
                                canOpenForm = isAdmin || station.judge.judgeNumber == currentJudgeNum,
                                onOpenForm = {
                                    onOpenJudgeScoring(
                                        station.judge.judgeNumber,
                                        uiState.selectedTeamIdForScoring
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            } else {
                items(uiState.judgeStations, key = { it.judge.judgeNumber }) { station ->
                    JudgeStationCard(
                        station = station,
                        isHighlighted = station.judge.judgeNumber == currentJudgeNum,
                        canOpenForm = isAdmin || station.judge.judgeNumber == currentJudgeNum,
                        onOpenForm = {
                            onOpenJudgeScoring(
                                station.judge.judgeNumber,
                                uiState.selectedTeamIdForScoring
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Cross-Matrix 5 Judges x Teams
            item {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Matriks Penilaian 5 Juri × Pleton",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "Ketuk sel skor untuk membuka formulir penilaian pleton terkait.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(12.dp)
                    ) {
                        // Header Row
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(NavyPrimary)
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Pleton",
                                style = MaterialTheme.typography.labelMedium,
                                color = CrispWhite,
                                modifier = Modifier.width(175.dp)
                            )
                            (1..5).forEach { j ->
                                Text(
                                    text = "Juri $j",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = GoldChampionship,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.width(86.dp)
                                )
                            }
                        }

                        uiState.teams.forEachIndexed { idx, team ->
                            if (idx > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.width(175.dp)) {
                                    Text(
                                        text = "#${team.orderNumber} ${team.name}",
                                        style = MaterialTheme.typography.labelLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = team.category.displayName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                (1..5).forEach { judgeNo ->
                                    val sheet = uiState.scoreSheets.find {
                                        it.teamId == team.id && it.judgeNumber == judgeNo
                                    }
                                    val score = sheet?.let {
                                        LkbbScoringRepository.calculateWeightedJudgeScore(
                                            it.criterionScores,
                                            uiState.criteria
                                        )
                                    }
                                    val cellBg = when {
                                        sheet?.isLocked == true -> EmeraldSoft
                                        sheet != null -> AmberSoft
                                        else -> CrimsonSoft.copy(alpha = 0.6f)
                                    }
                                    val cellFg = when {
                                        sheet?.isLocked == true -> EmeraldSuccess
                                        sheet != null -> AmberWarning
                                        else -> CrimsonRed
                                    }
                                    val canClick = isAdmin || currentJudgeNum == judgeNo

                                    Box(
                                        modifier = Modifier
                                            .width(86.dp)
                                            .padding(horizontal = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Surface(
                                            onClick = {
                                                if (canClick) {
                                                    onOpenJudgeScoring(judgeNo, team.id)
                                                }
                                            },
                                            enabled = canClick,
                                            color = cellBg,
                                            contentColor = cellFg,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 6.dp),
                                                horizontalArrangement = Arrangement.Center,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = score?.let { String.format(Locale.US, "%.1f", it) } ?: "—",
                                                    style = MonoTextStyles.TableCell,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                if (sheet?.isLocked == true && isAdmin && !uiState.isCurrentEventLockedForEditing) {
                                                    IconButton(
                                                        onClick = { onUnlockScoreSheet(team.id, judgeNo) },
                                                        modifier = Modifier.size(20.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.LockOpen,
                                                            contentDescription = "Buka kunci Juri $judgeNo",
                                                            modifier = Modifier.size(13.dp)
                                                        )
                                                    }
                                                } else if (sheet?.isLocked == true) {
                                                    Spacer(Modifier.width(3.dp))
                                                    Icon(
                                                        imageVector = Icons.Default.Lock,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun JudgeStationCard(
    station: JudgeStationSummary,
    isHighlighted: Boolean,
    canOpenForm: Boolean,
    onOpenForm: () -> Unit,
    modifier: Modifier = Modifier
) {
    val judge = station.judge
    val progress = if (station.totalTeams == 0) 0f else {
        station.completedTeams.toFloat() / station.totalTeams.toFloat()
    }

    Card(
        modifier = modifier.testTag("judge_station_card_${judge.judgeNumber}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (isHighlighted) 2.dp else 1.dp,
            color = if (isHighlighted) GoldChampionship else MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isHighlighted) 4.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (isHighlighted) GoldChampionship else NavyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "J${judge.judgeNumber}",
                            style = MonoTextStyles.TableCell,
                            fontWeight = FontWeight.Bold,
                            color = if (isHighlighted) NavyDeep else CrispWhite
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = judge.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = judge.specialty,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                StatusPill(
                    text = if (judge.isActive) "Aktif" else "Nonaktif",
                    containerColor = if (judge.isActive) EmeraldSoft else CrimsonSoft,
                    contentColor = if (judge.isActive) EmeraldSuccess else CrimsonRed
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Selesai: ${station.completedTeams}/${station.totalTeams} • Draft: ${station.draftTeams}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Rata-rata: ${String.format(Locale.US, "%.1f", station.averageScoreGiven)}",
                    style = MonoTextStyles.TableCell,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            LinearProgressIndicator(
                progress = { progress },
                color = if (station.completedTeams == station.totalTeams && station.totalTeams > 0) EmeraldSuccess else GoldChampionship,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            if (canOpenForm) {
                Button(
                    onClick = onOpenForm,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isHighlighted) CrimsonRed else NavyPrimary,
                        contentColor = CrispWhite
                    ),
                    contentPadding = PaddingValues(vertical = 10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_judge_form_${judge.judgeNumber}")
                ) {
                    Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Buka Formulir Juri ${judge.judgeNumber}")
                }
            }
        }
    }
}
