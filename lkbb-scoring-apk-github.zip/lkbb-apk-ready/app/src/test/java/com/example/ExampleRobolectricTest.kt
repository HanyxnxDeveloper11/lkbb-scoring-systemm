package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.LkbbDatabase
import com.example.data.local.LkbbSeedData
import com.example.data.model.AuditActionType
import com.example.data.model.CompetitionCategory
import com.example.data.model.CreateEventRequest
import com.example.data.model.EventStatus
import com.example.data.model.JudgeScoreSheet
import com.example.data.repository.LkbbScoringRepository
import com.example.util.EventExportManager
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LKBB Scoring", appName)
    }

    @Test
    fun roomDatabase_upgradesCleanlyFromV1ToV3() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val testDbName = "test_v1_v3_upgrade.db"
        val dbFile = context.getDatabasePath(testDbName)
        dbFile.parentFile?.mkdirs()
        if (dbFile.exists()) dbFile.delete()

        val legacyDb = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        legacyDb.execSQL("CREATE TABLE IF NOT EXISTS `competition_config` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `organizer` TEXT NOT NULL, `location` TEXT NOT NULL, `eventDate` TEXT NOT NULL, `maxDurationMinutes` INTEGER NOT NULL, `isScoringLocked` INTEGER NOT NULL, `lastSyncedAtMillis` INTEGER, PRIMARY KEY(`id`))")
        legacyDb.execSQL("CREATE TABLE IF NOT EXISTS `judge_accounts` (`judgeNumber` INTEGER NOT NULL, `name` TEXT NOT NULL, `specialty` TEXT NOT NULL, `email` TEXT NOT NULL, `pinCode` TEXT NOT NULL, `isActive` INTEGER NOT NULL, PRIMARY KEY(`judgeNumber`))")
        legacyDb.execSQL("CREATE TABLE IF NOT EXISTS `scoring_criteria` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `categoryGroup` TEXT NOT NULL, `maxScore` INTEGER NOT NULL, `weightPercent` INTEGER NOT NULL, `description` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        legacyDb.execSQL("CREATE TABLE IF NOT EXISTS `teams` (`id` TEXT NOT NULL, `orderNumber` INTEGER NOT NULL, `name` TEXT NOT NULL, `contingentCode` TEXT NOT NULL, `category` TEXT NOT NULL, `dantonName` TEXT NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`id`))")
        legacyDb.execSQL("CREATE TABLE IF NOT EXISTS `score_sheets` (`id` TEXT NOT NULL, `teamId` TEXT NOT NULL, `judgeNumber` INTEGER NOT NULL, `criterionScoresJson` TEXT NOT NULL, `penaltyPoints` INTEGER NOT NULL, `penaltyNotes` TEXT NOT NULL, `evaluatorNotes` TEXT NOT NULL, `isLocked` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        legacyDb.execSQL("CREATE TABLE IF NOT EXISTS `activity_logs` (`id` TEXT NOT NULL, `actor` TEXT NOT NULL, `message` TEXT NOT NULL, `timestampMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        legacyDb.execSQL("PRAGMA user_version = 1;")
        legacyDb.close()

        val upgradedDb = Room.databaseBuilder(context, LkbbDatabase::class.java, testDbName)
            .addMigrations(LkbbDatabase.MIGRATION_1_2, LkbbDatabase.MIGRATION_2_3)
            .fallbackToDestructiveMigration(dropAllTables = true)
            .build()
        val repo = LkbbScoringRepository(upgradedDb)
        repo.ensureSeeded()

        val dao = upgradedDb.lkbbDao()
        assertTrue(dao.getTeamsByEventOnce(LkbbSeedData.DEFAULT_EVENT_ID).isNotEmpty())
        assertTrue(dao.getPenaltyPresetsByEventOnce(LkbbSeedData.DEFAULT_EVENT_ID).isNotEmpty())
        assertTrue(dao.getAllCompetitionsOnce().size >= 2)
        upgradedDb.close()
        dbFile.delete()
    }

    @Test
    fun roomDatabase_upgradesCleanlyFromV2ToV3PreservingEventData() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val testDbName = "test_v2_v3_upgrade.db"
        val dbFile = context.getDatabasePath(testDbName)
        dbFile.parentFile?.mkdirs()
        if (dbFile.exists()) dbFile.delete()

        val v2Db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        v2Db.execSQL("CREATE TABLE IF NOT EXISTS `competition_config` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `organizer` TEXT NOT NULL, `location` TEXT NOT NULL, `eventDate` TEXT NOT NULL, `maxDurationMinutes` INTEGER NOT NULL, `isScoringLocked` INTEGER NOT NULL, `lastSyncedAtMillis` INTEGER, `logoUrl` TEXT NOT NULL, `bannerUrl` TEXT NOT NULL, `rankingMode` TEXT NOT NULL, `isRankingPublished` INTEGER NOT NULL, `onlyCountLockedInFinal` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        v2Db.execSQL("CREATE TABLE IF NOT EXISTS `judge_accounts` (`judgeNumber` INTEGER NOT NULL, `name` TEXT NOT NULL, `specialty` TEXT NOT NULL, `email` TEXT NOT NULL, `pinCode` TEXT NOT NULL, `isActive` INTEGER NOT NULL, PRIMARY KEY(`judgeNumber`))")
        v2Db.execSQL("CREATE TABLE IF NOT EXISTS `scoring_criteria` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `categoryGroup` TEXT NOT NULL, `maxScore` INTEGER NOT NULL, `weightPercent` INTEGER NOT NULL, `description` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        v2Db.execSQL("CREATE TABLE IF NOT EXISTS `penalty_presets` (`id` TEXT NOT NULL, `label` TEXT NOT NULL, `points` INTEGER NOT NULL, `description` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        v2Db.execSQL("CREATE TABLE IF NOT EXISTS `teams` (`id` TEXT NOT NULL, `orderNumber` INTEGER NOT NULL, `name` TEXT NOT NULL, `contingentCode` TEXT NOT NULL, `category` TEXT NOT NULL, `dantonName` TEXT NOT NULL, `status` TEXT NOT NULL, `squadName` TEXT NOT NULL, PRIMARY KEY(`id`))")
        v2Db.execSQL("CREATE TABLE IF NOT EXISTS `score_sheets` (`id` TEXT NOT NULL, `teamId` TEXT NOT NULL, `judgeNumber` INTEGER NOT NULL, `criterionScoresJson` TEXT NOT NULL, `penaltyPoints` INTEGER NOT NULL, `penaltyNotes` TEXT NOT NULL, `evaluatorNotes` TEXT NOT NULL, `isLocked` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        v2Db.execSQL("CREATE TABLE IF NOT EXISTS `activity_logs` (`id` TEXT NOT NULL, `actor` TEXT NOT NULL, `message` TEXT NOT NULL, `timestampMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        v2Db.execSQL("INSERT INTO `competition_config` VALUES ('lkbb-2026-main', 'LKBB Migrasi Test', 'Panitia Lama', 'GOR Lama', '10 Okt 2026', 10, 0, NULL, '', '', 'LIVE', 1, 1)")
        v2Db.execSQL("INSERT INTO `teams` VALUES ('legacy_t1', 1, 'SMAN Migrasi', 'SMA-1', 'SMA', 'Raka', 'WAITING', 'Regu Rajawali')")
        v2Db.execSQL("INSERT INTO `judge_accounts` VALUES (1, 'Juri Migrasi 1', 'PBB', 'j1@lkbb.id', '1111', 1)")
        v2Db.execSQL("PRAGMA user_version = 2;")
        v2Db.close()

        val upgradedDb = Room.databaseBuilder(context, LkbbDatabase::class.java, testDbName)
            .addMigrations(LkbbDatabase.MIGRATION_1_2, LkbbDatabase.MIGRATION_2_3)
            .build()
        val repo = LkbbScoringRepository(upgradedDb)
        repo.ensureSeeded()

        val dao = upgradedDb.lkbbDao()
        val preservedTeams = dao.getTeamsByEventOnce("lkbb-2026-main")
        assertTrue(preservedTeams.any { it.id == "legacy_t1" && it.name == "SMAN Migrasi" && it.eventId == "lkbb-2026-main" })
        val preservedJudges = dao.getJudgesByEventOnce("lkbb-2026-main")
        assertTrue(preservedJudges.any { it.judgeNumber == 1 && it.name == "Juri Migrasi 1" && it.eventId == "lkbb-2026-main" })
        assertEquals("lkbb-2026-main", dao.getActiveEventIdOnce())

        upgradedDb.close()
        dbFile.delete()
    }

    @Test
    fun multiEventArchive_isolatesData_locksFinalScores_reopensWithReason_andExportsFiles() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LkbbDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = LkbbScoringRepository(db)
        repo.ensureSeeded()

        val mainEventId = LkbbSeedData.DEFAULT_EVENT_ID
        val initialMainTeamsCount = db.lkbbDao().getTeamsByEventOnce(mainEventId).size
        val initialMainSheetsCount = db.lkbbDao().getScoreSheetsByEventOnce(mainEventId).size

        // 1. Create a new event duplicating criteria/penalties/categories/judges from mainEventId (MUST NOT copy teams or scores!)
        val newEventId = repo.createNewEvent(
            request = CreateEventRequest(
                name = "LKBB Nusantara Cup 2027",
                theme = "Bersatu Berprestasi",
                logoUrl = "",
                bannerUrl = "",
                eventDate = "15 Maret 2027",
                year = 2027,
                location = "GOR Soemantri",
                organizer = "Purna Paskibra Nusantara",
                maxDurationMinutes = 10,
                status = EventStatus.ACTIVE,
                enabledCategories = setOf(CompetitionCategory.SMA, CompetitionCategory.UMUM),
                teams = emptyList(),
                judges = LkbbSeedData.defaultJudges,
                criteria = LkbbSeedData.defaultCriteria,
                penaltyPresets = LkbbSeedData.defaultPenaltyPresets,
                sourceEventIdForDuplication = mainEventId,
                activateImmediately = true
            ),
            actor = "Admin Utama"
        )

        assertTrue(newEventId != mainEventId)
        assertEquals(0, db.lkbbDao().getTeamsByEventOnce(newEventId).size)
        assertEquals(0, db.lkbbDao().getScoreSheetsByEventOnce(newEventId).size)
        assertEquals(initialMainTeamsCount, db.lkbbDao().getTeamsByEventOnce(mainEventId).size)
        assertEquals(initialMainSheetsCount, db.lkbbDao().getScoreSheetsByEventOnce(mainEventId).size)

        // 2. Add team & score on new event, then finalize and lock
        val newTeam = com.example.data.model.Team(
            id = "${newEventId}_t1",
            orderNumber = 1,
            name = "SMAN 1 Nusantara",
            squadName = "Regu Elang",
            contingentCode = "SMA-01",
            category = CompetitionCategory.SMA,
            dantonName = "Bima",
            eventId = newEventId
        )
        repo.saveTeam(newTeam)
        val savedOk = repo.saveScoreSheet(
            sheet = JudgeScoreSheet(
                id = "${newTeam.id}_j1",
                teamId = newTeam.id,
                judgeNumber = 1,
                criterionScores = LkbbSeedData.defaultCriteria.associate { it.id to 92 },
                penaltyPoints = 0,
                isLocked = true,
                eventId = newEventId
            ),
            actorLabel = "Juri 1"
        )
        assertTrue(savedOk)

        val locked = repo.finalizeAndLockEvent(newEventId, "Admin Utama")
        assertTrue(locked)

        val lockedBundle = repo.getEventDetailBundle(newEventId)
        assertNotNull(lockedBundle)
        assertEquals(EventStatus.FINISHED, lockedBundle!!.config.status)
        assertTrue(lockedBundle.config.isArchivedLocked)
        assertNotNull(lockedBundle.snapshot)

        // Verify score sheets on locked archive cannot be edited by judge
        val blockedEdit = repo.saveScoreSheet(
            sheet = JudgeScoreSheet(
                id = "${newTeam.id}_j1",
                teamId = newTeam.id,
                judgeNumber = 1,
                criterionScores = LkbbSeedData.defaultCriteria.associate { it.id to 50 },
                isLocked = false,
                eventId = newEventId
            ),
            actorLabel = "Juri 1"
        )
        assertFalse(blockedEdit)

        // 3. Reopen requires non-blank reason and logs AuditActionType.EVENT_REOPEN
        assertFalse(repo.reopenArchivedEvent(newEventId, "Admin Utama", "   "))
        assertTrue(repo.reopenArchivedEvent(newEventId, "Admin Utama", "Koreksi berita acara penalti"))
        val reopenedBundle = repo.getEventDetailBundle(newEventId)!!
        assertFalse(reopenedBundle.config.isArchivedLocked)
        assertTrue(reopenedBundle.auditLogs.any { log ->
            log.actionType == AuditActionType.EVENT_REOPEN && log.reason.contains("Koreksi berita acara")
        })

        // 4. Verify real PDF & Excel CSV & JSON backup generation
        val pdfFile = EventExportManager.generatePdfReport(context, reopenedBundle).getOrThrow()
        assertTrue(pdfFile.exists() && pdfFile.length() > 100)
        val csvFile = EventExportManager.generateExcelCsv(context, reopenedBundle).getOrThrow()
        assertTrue(csvFile.exists() && csvFile.readText().contains("SMAN 1 Nusantara"))

        // 5. Delete event removes only target event and restores active event
        val deleteRes = repo.deleteEventPermanently(newEventId, "Admin Utama")
        assertTrue(deleteRes.isSuccess)
        assertTrue(db.lkbbDao().getTeamsByEventOnce(mainEventId).size == initialMainTeamsCount)

        pdfFile.delete()
        csvFile.delete()
        db.close()
    }

    @Test
    fun appLaunchesAndNavigatesAllScreensWithoutCrash() {
        // 1. Login screen renders cleanly
        composeRule.onNodeWithTag("login_submit_button").performScrollTo().assertIsDisplayed()

        // 2. Quick login as Admin -> Admin Dashboard
        composeRule.onNodeWithTag("quick_login_admin").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            runCatching {
                composeRule.onNodeWithTag("admin_add_team_fab").assertIsDisplayed()
                true
            }.getOrDefault(false)
        }

        // 2b. Navigate to ARSIP PERLOMBAAN -> Create New Event -> Detail Arsip -> Back
        composeRule.onNodeWithTag("topbar_archive_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("archive_create_event_button").assertIsDisplayed()
        composeRule.onNodeWithTag("archive_create_event_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("create_event_name_input").performScrollTo().performTextInput("LKBB Test Arsip 2027")
        composeRule.onNodeWithTag("create_event_submit_button").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            runCatching {
                composeRule.onNodeWithTag("archive_detail_back_button").assertIsDisplayed()
                true
            }.getOrDefault(false)
        }
        composeRule.onNodeWithTag("archive_detail_list").performScrollToNode(hasTestTag("archive_export_pdf_button"))
        composeRule.onNodeWithTag("archive_export_pdf_button").assertIsDisplayed()
        composeRule.onNodeWithTag("archive_detail_list").performScrollToNode(hasTestTag("archive_detail_back_button"))
        composeRule.onNodeWithTag("archive_detail_back_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("bottom_nav_admin").performClick()
        composeRule.waitForIdle()

        // 3. Navigate to 5 Judges Dashboard
        composeRule.onNodeWithTag("bottom_nav_five_judges").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("judge_station_card_1").assertIsDisplayed()

        // 4. Navigate to Scoring Form
        composeRule.onNodeWithTag("bottom_nav_scoring").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("scoring_team_selector").assertIsDisplayed()

        // 5. Navigate to Ranking Dashboard
        composeRule.onNodeWithTag("bottom_nav_ranking").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("ranking_share_button").assertIsDisplayed()

        // 6. Navigate to Competition Settings & check all 5 Admin Settings tabs + dialogs
        composeRule.onNodeWithTag("bottom_nav_settings").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_competition_name").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("settings_tab_criteria").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_add_criterion_button").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_criteria_list").performScrollToNode(hasTestTag("settings_add_penalty_button"))
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_add_penalty_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("dialog_penalty_label").performTextInput("Penalti Tes")
        composeRule.onNodeWithTag("dialog_penalty_save_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_tab_judges").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_edit_judge_1").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Simpan").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_tab_participants").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_add_team_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("dialog_team_name").performTextInput("SMAN 9 Test")
        composeRule.onNodeWithTag("dialog_team_squad").performTextInput("Regu Garuda")
        composeRule.onNodeWithTag("dialog_team_save_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_tab_ranking_db").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_ranking_mode_final").performScrollTo().performClick()
        composeRule.onNodeWithTag("settings_save_ranking_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_criteria_list").performScrollToNode(hasTestTag("settings_reset_demo_button"))
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_view_sql_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Tutup").performClick()
        composeRule.waitForIdle()

        // 7. Logout returns cleanly to Login screen
        composeRule.onNodeWithTag("topbar_logout_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("login_submit_button").performScrollTo().assertIsDisplayed()
    }
}

