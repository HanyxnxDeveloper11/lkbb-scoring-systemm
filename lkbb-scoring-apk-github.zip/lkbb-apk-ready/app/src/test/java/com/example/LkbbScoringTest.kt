package com.example

import com.example.data.local.LkbbSeedData
import com.example.data.model.JudgeScoreSheet
import com.example.data.model.RankingMode
import com.example.data.repository.LkbbScoringRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LkbbScoringTest {

    @Test
    fun weightedScore_perfectScoresEqual100() {
        val criteria = LkbbSeedData.defaultCriteria
        val scores = criteria.associate { it.id to it.maxScore }
        val result = LkbbScoringRepository.calculateWeightedJudgeScore(scores, criteria)
        assertEquals(100.0, result, 0.001)
    }

    @Test
    fun rankings_applyPenaltyAndSortDescending() {
        val criteria = LkbbSeedData.defaultCriteria
        val teams = LkbbSeedData.defaultTeams.take(2)
        val sheets = listOf(
            JudgeScoreSheet(
                id = "t1_j1",
                teamId = teams[0].id,
                judgeNumber = 1,
                criterionScores = criteria.associate { it.id to 90 },
                penaltyPoints = 10,
                isLocked = true
            ),
            JudgeScoreSheet(
                id = "t2_j1",
                teamId = teams[1].id,
                judgeNumber = 1,
                criterionScores = criteria.associate { it.id to 88 },
                penaltyPoints = 0,
                isLocked = true
            )
        )

        val rankings = LkbbScoringRepository.computeRankings(teams, criteria, sheets)
        assertEquals(teams[1].id, rankings[0].team.id)
        assertEquals(88.0, rankings[0].finalScore, 0.001)
        assertEquals(teams[0].id, rankings[1].team.id)
        assertEquals(80.0, rankings[1].finalScore, 0.001)
        assertTrue(rankings[0].rank == 1 && rankings[1].rank == 2)
    }

    @Test
    fun rankings_finalModeExcludesDraftsWhenOnlyCountLockedIsTrue() {
        val criteria = LkbbSeedData.defaultCriteria
        val teams = LkbbSeedData.defaultTeams.take(2)
        val sheets = listOf(
            JudgeScoreSheet(
                id = "t1_j1",
                teamId = teams[0].id,
                judgeNumber = 1,
                criterionScores = criteria.associate { it.id to 95 },
                penaltyPoints = 0,
                isLocked = false // Draft only
            ),
            JudgeScoreSheet(
                id = "t2_j1",
                teamId = teams[1].id,
                judgeNumber = 1,
                criterionScores = criteria.associate { it.id to 85 },
                penaltyPoints = 0,
                isLocked = true // Locked
            )
        )

        val liveRankings = LkbbScoringRepository.computeRankings(
            teams = teams,
            criteria = criteria,
            scoreSheets = sheets,
            rankingMode = RankingMode.LIVE,
            onlyCountLockedInFinal = true
        )
        assertEquals(teams[0].id, liveRankings[0].team.id)
        assertEquals(95.0, liveRankings[0].finalScore, 0.001)

        val finalRankings = LkbbScoringRepository.computeRankings(
            teams = teams,
            criteria = criteria,
            scoreSheets = sheets,
            rankingMode = RankingMode.FINAL,
            onlyCountLockedInFinal = true
        )
        assertEquals(teams[1].id, finalRankings[0].team.id)
        assertEquals(85.0, finalRankings[0].finalScore, 0.001)
        assertEquals(0.0, finalRankings[1].finalScore, 0.001)
        assertEquals("Menunggu Nilai Terkunci", finalRankings[1].predicate)
    }

    @Test
    fun rankings_finalModeIncludesDraftsWhenOnlyCountLockedIsFalse() {
        val criteria = LkbbSeedData.defaultCriteria
        val teams = LkbbSeedData.defaultTeams.take(2)
        val sheets = listOf(
            JudgeScoreSheet(
                id = "t1_j1",
                teamId = teams[0].id,
                judgeNumber = 1,
                criterionScores = criteria.associate { it.id to 92 },
                penaltyPoints = 0,
                isLocked = false
            ),
            JudgeScoreSheet(
                id = "t2_j1",
                teamId = teams[1].id,
                judgeNumber = 1,
                criterionScores = criteria.associate { it.id to 85 },
                penaltyPoints = 0,
                isLocked = true
            )
        )

        val finalRankings = LkbbScoringRepository.computeRankings(
            teams = teams,
            criteria = criteria,
            scoreSheets = sheets,
            rankingMode = RankingMode.FINAL,
            onlyCountLockedInFinal = false
        )
        assertEquals(teams[0].id, finalRankings[0].team.id)
        assertEquals(92.0, finalRankings[0].finalScore, 0.001)
    }
}
